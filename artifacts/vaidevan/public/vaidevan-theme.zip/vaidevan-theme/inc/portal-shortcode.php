<?php
/**
 * [vdv_portal] — Portal do Investidor com CRUD completo
 */
defined('ABSPATH') || exit;

add_shortcode('vdv_portal', 'vdv_portal_shortcode');

/* Logout antes dos headers */
add_action('template_redirect', function () {
    if (!isset($_POST['vdv_logout'])) { return; }
    if (!wp_verify_nonce($_POST['vdv_logout_nonce'] ?? '', 'vdv_logout')) { return; }
    if (function_exists('vdv_portal_clear_token')) { vdv_portal_clear_token(); }
    wp_safe_redirect(wp_get_referer() ?: home_url('/portal/'));
    exit;
});

function vdv_portal_shortcode() {
    ob_start();
    $investor_id = function_exists('vdv_portal_get_investor_id') ? vdv_portal_get_investor_id() : 0;
    $inv = null;
    if ($investor_id) {
        global $wpdb;
        $inv = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM `{$wpdb->prefix}vdv_investors` WHERE id=%d AND ativo=1 LIMIT 1",
            (int) $investor_id
        ));
        if (!$inv) {
            if (function_exists('vdv_portal_clear_token')) { vdv_portal_clear_token(); }
            $inv = null;
        }
    }
    $ajax_url = admin_url('admin-ajax.php');
    $nonce    = wp_create_nonce('vdv_portal_nonce');
    $logo_url = get_template_directory_uri() . '/assets/images/logo-dark.webp';
    ?>

<style id="vdv-portal-css">
#vdvPortal{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;color:#fff;min-height:80vh;display:flex;flex-direction:column;align-items:center;justify-content:center;padding:24px;box-sizing:border-box}
.pvSpin{display:flex;flex-direction:column;align-items:center;gap:14px;min-height:50vh;justify-content:center}
.pvSpin .sp{width:40px;height:40px;border:3px solid rgba(245,230,66,.15);border-top-color:#F5E642;border-radius:50%;animation:pvSpin .7s linear infinite}
@keyframes pvSpin{to{transform:rotate(360deg)}}
.pvSpin p{color:rgba(255,255,255,.4);font-size:.85rem}
.pvLogin{background:#111;border:1px solid rgba(255,255,255,.1);border-radius:14px;padding:40px 36px;width:100%;max-width:400px}
.pvLogin img{width:54px;height:54px;border-radius:50%;margin-bottom:16px;display:block}
.pvLogin h2{font-size:1.5rem;font-weight:800;letter-spacing:-.5px;margin:0 0 4px}
.pvLogin .sub{color:rgba(255,255,255,.45);font-size:.88rem;margin:0 0 22px}
.pvFb{display:none;padding:10px 14px;border-radius:7px;margin-bottom:14px;font-size:.85rem}
.pvFb.ok{display:block;background:rgba(74,222,128,.1);border:1px solid rgba(74,222,128,.25);color:#4ade80}
.pvFb.err{display:block;background:rgba(239,68,68,.1);border:1px solid rgba(239,68,68,.25);color:#f87171}
.pvFg{margin-bottom:14px}
.pvFg label{display:block;font-size:.72rem;font-weight:700;color:rgba(255,255,255,.45);margin-bottom:5px;text-transform:uppercase;letter-spacing:.5px}
.pvFg input,.pvFg select,.pvFg textarea{width:100%;background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.12);border-radius:7px;padding:12px 14px;color:#fff;font-size:.95rem;outline:none;box-sizing:border-box;transition:border-color .2s;font-family:inherit}
.pvFg textarea{resize:vertical;min-height:72px}
.pvFg select option{background:#1a1a1a;color:#fff}
.pvFg input:focus,.pvFg select:focus,.pvFg textarea:focus{border-color:#F5E642}
.pvBtn{display:inline-flex;align-items:center;justify-content:center;gap:8px;background:#F5E642;color:#0A0A0A;font-weight:800;font-size:.92rem;padding:13px 24px;border-radius:7px;border:none;cursor:pointer;width:100%;margin-top:4px;transition:background .2s;font-family:inherit}
.pvBtn:hover{background:#e0cf2a}
.pvBtn:disabled{opacity:.55;cursor:not-allowed}
.pvBtnOut{display:inline-flex;align-items:center;gap:6px;background:transparent;color:rgba(255,255,255,.6);font-size:.82rem;font-weight:600;padding:8px 14px;border-radius:7px;border:1px solid rgba(255,255,255,.18);cursor:pointer;transition:all .2s;font-family:inherit}
.pvBtnOut:hover{border-color:#F5E642;color:#F5E642}
.pvBtnAdd{display:inline-flex;align-items:center;gap:5px;background:rgba(245,230,66,.12);color:#F5E642;font-size:.75rem;font-weight:700;padding:5px 12px;border-radius:6px;border:1px solid rgba(245,230,66,.25);cursor:pointer;font-family:inherit;transition:all .2s;flex-shrink:0}
.pvBtnAdd:hover{background:rgba(245,230,66,.22)}
.pvBtnEdit{background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.12);color:rgba(255,255,255,.6);font-size:.7rem;padding:3px 8px;border-radius:5px;cursor:pointer;font-family:inherit;transition:all .2s}
.pvBtnEdit:hover{border-color:#F5E642;color:#F5E642}
.pvBtnDel{background:rgba(248,113,113,.08);border:1px solid rgba(248,113,113,.18);color:#f87171;font-size:.7rem;padding:3px 8px;border-radius:5px;cursor:pointer;font-family:inherit;transition:all .2s}
.pvBtnDel:hover{background:rgba(248,113,113,.18)}
.pvDash{width:100%;max-width:1100px}
.pvHead{display:flex;align-items:center;justify-content:space-between;margin-bottom:24px;flex-wrap:wrap;gap:12px}
.pvHead h2{font-size:1.4rem;font-weight:800;margin:0 0 3px;letter-spacing:-.5px}
.pvHead p{color:rgba(255,255,255,.38);font-size:.8rem;margin:0}
.pvHead-right{display:flex;align-items:center;gap:8px;flex-wrap:wrap}
.pvKpis{display:grid;grid-template-columns:repeat(auto-fill,minmax(190px,1fr));gap:14px;margin-bottom:20px}
.pvKpi{background:#111;border:1px solid rgba(255,255,255,.08);border-radius:10px;padding:18px 20px}
.pvKpi .lbl{font-size:.68rem;font-weight:700;text-transform:uppercase;letter-spacing:.8px;color:rgba(255,255,255,.38);margin-bottom:8px}
.pvKpi .val{font-size:1.45rem;font-weight:800;letter-spacing:-.5px;line-height:1.1;margin-bottom:4px}
.pvKpi .sub{font-size:.72rem;color:rgba(255,255,255,.32)}
.g{color:#4ade80}.r{color:#f87171}.y{color:#F5E642}
.pvPanel{background:#111;border:1px solid rgba(255,255,255,.08);border-radius:10px;padding:20px;margin-bottom:18px}
.pvPanel-hd{display:flex;align-items:center;justify-content:space-between;margin-bottom:16px;gap:10px}
.pvPanel-hd h3{font-size:.95rem;font-weight:700;margin:0;display:flex;align-items:center;gap:8px}
.pvPanel-hd h3 span{font-size:.72rem;font-weight:400;color:rgba(255,255,255,.32)}
.pvGrid2{display:grid;grid-template-columns:1fr 1fr;gap:18px;margin-bottom:18px}
.pvLeg{display:flex;gap:14px;margin-bottom:10px}
.pvLeg span{font-size:.7rem;font-weight:700;display:flex;align-items:center;gap:4px}
.pvLeg span::before{content:'';width:10px;height:10px;border-radius:2px;display:inline-block}
.legG::before{background:#4ade80}.legR::before{background:#f87171}
.pvChartWrap{overflow-x:auto}
.pvBars{display:flex;align-items:flex-end;gap:5px;height:120px;padding-bottom:4px;min-width:400px}
.pvBarG{display:flex;align-items:flex-end;gap:2px;flex:1;cursor:default}
.pvBarG:hover div{opacity:.7}
.bI{background:#4ade80;border-radius:3px 3px 0 0;min-height:2px}
.bE{background:#f87171;border-radius:3px 3px 0 0;min-height:2px}
.pvLbls{display:flex;gap:5px;min-width:400px}
.pvLbl{flex:1;text-align:center;font-size:.62rem;color:rgba(255,255,255,.32);padding-top:4px}
.pvOp,.pvVeh{display:flex;align-items:center;justify-content:space-between;gap:10px;padding:11px 0;border-bottom:1px solid rgba(255,255,255,.06)}
.pvOp:last-child,.pvVeh:last-child{border:none;padding-bottom:0}
.opName{font-size:.88rem;font-weight:700;margin-bottom:2px}
.opLoc{font-size:.72rem;color:rgba(255,255,255,.36)}
.vPlate{font-size:.75rem;font-weight:700;background:rgba(245,230,66,.1);color:#F5E642;border:1px solid rgba(245,230,66,.2);border-radius:5px;padding:3px 8px;min-width:68px;text-align:center;letter-spacing:1px;flex-shrink:0}
.vMod{font-size:.86rem;font-weight:600;margin-bottom:2px}
.vAno{font-size:.7rem;color:rgba(255,255,255,.36)}
.bdg{font-size:.62rem;font-weight:700;text-transform:uppercase;letter-spacing:.5px;padding:3px 8px;border-radius:100px;flex-shrink:0}
.bok{background:rgba(74,222,128,.12);color:#4ade80;border:1px solid rgba(74,222,128,.22)}
.bps{background:rgba(251,191,36,.12);color:#fbbf24;border:1px solid rgba(251,191,36,.22)}
.bof{background:rgba(248,113,113,.12);color:#f87171;border:1px solid rgba(248,113,113,.22)}
.pvTbl{width:100%;border-collapse:collapse;font-size:.82rem}
.pvTbl th{text-align:left;font-size:.65rem;font-weight:700;text-transform:uppercase;letter-spacing:.5px;color:rgba(255,255,255,.35);padding:7px 10px;border-bottom:1px solid rgba(255,255,255,.07)}
.pvTbl td{padding:9px 10px;border-bottom:1px solid rgba(255,255,255,.05);color:rgba(255,255,255,.8);vertical-align:middle}
.pvTbl tr:last-child td{border:none}
.pvTbl tr:hover td{background:rgba(255,255,255,.02)}
.tdD{color:rgba(255,255,255,.4);font-size:.75rem;white-space:nowrap}
.tdI{color:#4ade80;font-weight:700}.tdE{color:#f87171;font-weight:700}
.tdAct{display:flex;gap:4px;justify-content:flex-end}
.pvPag{display:flex;gap:5px;flex-wrap:wrap;justify-content:center;padding-top:14px;margin-top:6px;border-top:1px solid rgba(255,255,255,.07)}
.pgBtn{background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);color:rgba(255,255,255,.55);font-size:.75rem;padding:5px 10px;border-radius:5px;cursor:pointer;font-family:inherit;transition:all .2s}
.pgBtn:hover,.pgBtn.act{background:#F5E642;border-color:#F5E642;color:#0A0A0A;font-weight:700}
/* MODAL */
.pvModal-bg{display:none;position:fixed;inset:0;background:rgba(0,0,0,.75);z-index:99999;align-items:center;justify-content:center;padding:20px;box-sizing:border-box}
.pvModal-bg.open{display:flex}
.pvModal{background:#151515;border:1px solid rgba(255,255,255,.12);border-radius:14px;padding:28px;width:100%;max-width:520px;max-height:90vh;overflow-y:auto;position:relative;box-shadow:0 24px 80px rgba(0,0,0,.6)}
.pvModal h3{font-size:1.1rem;font-weight:800;margin:0 0 20px;padding-right:32px}
.pvModal-close{position:absolute;top:14px;right:16px;background:none;border:none;color:rgba(255,255,255,.4);font-size:1.4rem;cursor:pointer;padding:4px;line-height:1;transition:color .2s}
.pvModal-close:hover{color:#fff}
.pvModal-fb{display:none;padding:9px 14px;border-radius:6px;margin-bottom:14px;font-size:.83rem}
.pvModal-fb.ok{display:block;background:rgba(74,222,128,.1);border:1px solid rgba(74,222,128,.25);color:#4ade80}
.pvModal-fb.err{display:block;background:rgba(239,68,68,.1);border:1px solid rgba(239,68,68,.25);color:#f87171}
.pvModal .pvBtn{margin-top:8px}
.pvFg-row{display:grid;grid-template-columns:1fr 1fr;gap:12px}
.pvTab{display:flex;gap:0;margin-bottom:20px;border-bottom:2px solid rgba(255,255,255,.08)}
.pvTab-btn{background:none;border:none;color:rgba(255,255,255,.45);font-size:.85rem;font-weight:700;padding:8px 16px;cursor:pointer;font-family:inherit;border-bottom:2px solid transparent;margin-bottom:-2px;transition:all .2s}
.pvTab-btn.active{color:#F5E642;border-bottom-color:#F5E642}
.pvTab-panel{display:none}
.pvTab-panel.active{display:block}
@media(max-width:700px){.pvGrid2{grid-template-columns:1fr}.pvKpis{grid-template-columns:1fr 1fr}.pvFg-row{grid-template-columns:1fr}}
@media(max-width:420px){.pvKpis{grid-template-columns:1fr}.pvLogin{padding:26px 18px}}
</style>

<div id="vdvPortal">

<?php if ($inv): ?>
<!-- DASHBOARD -->
<div class="pvSpin" id="pvSpinner"><div class="sp"></div><p>Carregando dashboard…</p></div>
<div class="pvDash" id="pvDash" style="display:none">
    <div class="pvHead">
        <div>
            <h2>Olá, <?= esc_html($inv->nome) ?></h2>
            <p id="pvDateTime"><?= date_i18n('d/m/Y H:i') ?></p>
        </div>
        <div class="pvHead-right">
            <button class="pvBtnOut" id="pvPerfil">✎ Meu Perfil</button>
            <form method="post" style="display:inline">
                <?php wp_nonce_field('vdv_logout', 'vdv_logout_nonce'); ?>
                <input type="hidden" name="vdv_logout" value="1">
                <button type="submit" class="pvBtnOut" id="pvLogout">Sair</button>
            </form>
        </div>
    </div>

    <!-- KPIs -->
    <div class="pvKpis">
        <div class="pvKpi"><div class="lbl">Receita Total</div><div class="val g" id="pvR">—</div><div class="sub">12 meses</div></div>
        <div class="pvKpi"><div class="lbl">Despesas</div><div class="val r" id="pvD">—</div><div class="sub">12 meses</div></div>
        <div class="pvKpi"><div class="lbl">Lucro Líquido</div><div class="val y" id="pvL">—</div><div class="sub" id="pvV">—</div></div>
        <div class="pvKpi"><div class="lbl">Participação</div><div class="val"><?= number_format((float)$inv->participacao_pct, 2, ',', '.') ?>%</div><div class="sub" id="pvRend">—</div></div>
        <div class="pvKpi"><div class="lbl">Veículos Ativos</div><div class="val" id="pvVA">—</div><div class="sub" id="pvVT">—</div></div>
    </div>

    <!-- Chart -->
    <div class="pvPanel">
        <div class="pvPanel-hd"><h3>Receita vs Despesa <span>12 meses</span></h3></div>
        <div id="pvChart"><div class="pvSpin" style="min-height:100px"><div class="sp"></div></div></div>
    </div>

    <!-- Ops + Frota -->
    <div class="pvGrid2">
        <div class="pvPanel">
            <div class="pvPanel-hd">
                <h3>Operações</h3>
                <button class="pvBtnAdd" id="pvAddOp">+ Adicionar</button>
            </div>
            <div id="pvOps"><div class="pvSpin" style="min-height:60px"><div class="sp"></div></div></div>
        </div>
        <div class="pvPanel">
            <div class="pvPanel-hd">
                <h3>Frota</h3>
                <button class="pvBtnAdd" id="pvAddVeh">+ Adicionar</button>
            </div>
            <div id="pvVehs"><div class="pvSpin" style="min-height:60px"><div class="sp"></div></div></div>
        </div>
    </div>

    <!-- Movimentos financeiros -->
    <div class="pvPanel">
        <div class="pvPanel-hd">
            <h3>Movimentos Financeiros <span id="pvMC">…</span></h3>
            <button class="pvBtnAdd" id="pvAddMov">+ Adicionar</button>
        </div>
        <div id="pvTbl"><div class="pvSpin" style="min-height:80px"><div class="sp"></div></div></div>
    </div>
</div>

<?php else: ?>
<!-- LOGIN -->
<div class="pvLogin">
    <img src="<?= esc_url($logo_url) ?>" alt="VaideVan">
    <h2>Portal do Investidor</h2>
    <p class="sub">Acesse sua área exclusiva</p>
    <div id="pvFb" class="pvFb" role="alert" aria-live="polite"></div>
    <div class="pvFg"><label for="pvEmail">E-mail</label><input type="email" id="pvEmail" autocomplete="email" placeholder="seu@email.com"></div>
    <div class="pvFg"><label for="pvSenha">Senha</label><input type="password" id="pvSenha" autocomplete="current-password" placeholder="••••••••"></div>
    <button class="pvBtn" id="pvLoginBtn">Entrar no Portal</button>
    <p style="margin-top:16px;font-size:.72rem;color:rgba(255,255,255,.25);text-align:center">Acesso exclusivo para investidores credenciados.</p>
</div>
<?php endif; ?>

</div><!-- /vdvPortal -->

<!-- ===== MODAIS ===== -->

<!-- Modal Movimento -->
<div class="pvModal-bg" id="pvModalMov">
    <div class="pvModal">
        <button class="pvModal-close" data-close="pvModalMov">&times;</button>
        <h3 id="pvModalMovTitle">Novo Movimento</h3>
        <div class="pvModal-fb" id="pvModalMovFb"></div>
        <input type="hidden" id="pvMovId" value="">
        <div class="pvFg"><label>Tipo *</label>
            <select id="pvMovTipo"><option value="receita">Receita</option><option value="despesa">Despesa</option></select>
        </div>
        <div class="pvFg"><label>Operação *</label><select id="pvMovOp"></select></div>
        <div class="pvFg"><label>Categoria *</label>
            <input type="text" id="pvMovCat" placeholder="ex: Fretamento corporativo" list="pvCatList">
            <datalist id="pvCatList">
                <option value="Fretamento corporativo"><option value="Aluguel van executiva">
                <option value="Transfer aeroporto"><option value="Eventos e congressos">
                <option value="Salarios e encargos"><option value="Combustivel">
                <option value="Manutencao frota"><option value="Seguro frota">
                <option value="Despesas administrativas"><option value="Impostos e taxas">
            </datalist>
        </div>
        <div class="pvFg"><label>Descrição *</label><input type="text" id="pvMovDesc" placeholder="Descrição detalhada"></div>
        <div class="pvFg-row">
            <div class="pvFg"><label>Valor (R$) *</label><input type="number" id="pvMovValor" step="0.01" min="0" placeholder="0,00"></div>
            <div class="pvFg"><label>Data *</label><input type="date" id="pvMovData"></div>
        </div>
        <div class="pvFg"><label>Referência</label><input type="text" id="pvMovRef" placeholder="ex: jan2024 (opcional)"></div>
        <button class="pvBtn" id="pvSaveMov">Salvar Movimento</button>
    </div>
</div>

<!-- Modal Veículo -->
<div class="pvModal-bg" id="pvModalVeh">
    <div class="pvModal">
        <button class="pvModal-close" data-close="pvModalVeh">&times;</button>
        <h3 id="pvModalVehTitle">Novo Veículo</h3>
        <div class="pvModal-fb" id="pvModalVehFb"></div>
        <input type="hidden" id="pvVehId" value="">
        <div class="pvFg-row">
            <div class="pvFg"><label>Placa *</label><input type="text" id="pvVehPlaca" placeholder="ABC-1234" maxlength="8" style="text-transform:uppercase"></div>
            <div class="pvFg"><label>Ano *</label><input type="number" id="pvVehAno" min="2000" max="2030" placeholder="2024"></div>
        </div>
        <div class="pvFg"><label>Modelo *</label><input type="text" id="pvVehModelo" placeholder="ex: Mercedes-Benz Sprinter 415 CDI"></div>
        <div class="pvFg-row">
            <div class="pvFg"><label>Capacidade (lugares) *</label><input type="number" id="pvVehCap" min="1" max="30" placeholder="15"></div>
            <div class="pvFg"><label>KM Atual</label><input type="number" id="pvVehKm" min="0" placeholder="0"></div>
        </div>
        <div class="pvFg-row">
            <div class="pvFg"><label>Status *</label>
                <select id="pvVehStatus"><option value="ativo">Ativo</option><option value="manutencao">Manutenção</option><option value="inativo">Inativo</option></select>
            </div>
            <div class="pvFg"><label>Operação</label><select id="pvVehOp"><option value="">Sem operação</option></select></div>
        </div>
        <div class="pvFg"><label>Chassi</label><input type="text" id="pvVehChassi" placeholder="Número do chassi (opcional)"></div>
        <button class="pvBtn" id="pvSaveVeh">Salvar Veículo</button>
    </div>
</div>

<!-- Modal Operação -->
<div class="pvModal-bg" id="pvModalOp">
    <div class="pvModal">
        <button class="pvModal-close" data-close="pvModalOp">&times;</button>
        <h3 id="pvModalOpTitle">Nova Operação</h3>
        <div class="pvModal-fb" id="pvModalOpFb"></div>
        <input type="hidden" id="pvOpId" value="">
        <div class="pvFg"><label>Nome da Operação *</label><input type="text" id="pvOpNome" placeholder="ex: SP Norte e Grande SP"></div>
        <div class="pvFg-row">
            <div class="pvFg"><label>Cidades</label><input type="number" id="pvOpCidades" min="0" placeholder="0"></div>
            <div class="pvFg"><label>Estados</label><input type="number" id="pvOpEstados" min="0" placeholder="1"></div>
        </div>
        <div class="pvFg-row">
            <div class="pvFg"><label>Status *</label>
                <select id="pvOpStatus"><option value="ativo">Ativo</option><option value="pausa">Pausa</option><option value="encerrado">Encerrado</option></select>
            </div>
            <div class="pvFg"><label>Iniciado em</label><input type="date" id="pvOpInicio"></div>
        </div>
        <div class="pvFg"><label>Descrição</label><textarea id="pvOpDesc" placeholder="Descrição opcional da operação"></textarea></div>
        <button class="pvBtn" id="pvSaveOp">Salvar Operação</button>
    </div>
</div>

<!-- Modal Perfil -->
<div class="pvModal-bg" id="pvModalPerfil">
    <div class="pvModal">
        <button class="pvModal-close" data-close="pvModalPerfil">&times;</button>
        <h3>Meu Perfil</h3>
        <div class="pvModal-fb" id="pvModalPerfilFb"></div>
        <div class="pvTab">
            <button class="pvTab-btn active" data-tab="perfil-dados">Dados</button>
            <button class="pvTab-btn" data-tab="perfil-senha">Senha</button>
        </div>
        <div class="pvTab-panel active" id="perfil-dados">
            <div class="pvFg"><label>Nome</label><input type="text" id="pvPNome" placeholder="Seu nome"></div>
            <div class="pvFg"><label>E-mail</label><input type="email" id="pvPEmail" placeholder="seu@email.com"></div>
            <button class="pvBtn" id="pvSavePerfil">Salvar Dados</button>
        </div>
        <div class="pvTab-panel" id="perfil-senha">
            <div class="pvFg"><label>Senha Atual *</label><input type="password" id="pvPSenhaAtual" placeholder="Sua senha atual"></div>
            <div class="pvFg"><label>Nova Senha *</label><input type="password" id="pvPSenhaNova" placeholder="Mínimo 6 caracteres"></div>
            <div class="pvFg"><label>Confirmar Nova Senha *</label><input type="password" id="pvPSenhaConf" placeholder="Repita a nova senha"></div>
            <button class="pvBtn" id="pvSaveSenha">Alterar Senha</button>
        </div>
    </div>
</div>

<!-- Confirmação de exclusão -->
<div class="pvModal-bg" id="pvModalConfirm">
    <div class="pvModal" style="max-width:380px;text-align:center">
        <h3 style="padding-right:0">Confirmar exclusão</h3>
        <p style="color:rgba(255,255,255,.5);font-size:.88rem;margin-bottom:24px">Esta ação não pode ser desfeita. Deseja continuar?</p>
        <div style="display:flex;gap:10px">
            <button class="pvBtnOut" id="pvConfirmNo" style="flex:1;justify-content:center">Cancelar</button>
            <button class="pvBtn" id="pvConfirmYes" style="background:#f87171;flex:1">Excluir</button>
        </div>
    </div>
</div>

<script id="vdv-portal-js">
(function(){
'use strict';
var AJAX='<?= esc_js($ajax_url) ?>';
var NON='<?= esc_js($nonce) ?>';
var PG=1,PER=10,MOVS=[],OPS=[],VEHS=[],INV={};
var pendingDelete={action:null,id:null};

/* ---- Micro utils ---- */
function brl(v){return'R$ '+Number(v).toLocaleString('pt-BR',{minimumFractionDigits:2,maximumFractionDigits:2});}
function esc(s){return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');}
function $(id){return document.getElementById(id);}
function txt(id,v){var e=$(id);if(e)e.textContent=v;}
function htm(id,v){var e=$(id);if(e)e.innerHTML=v;}
function val(id,v){var e=$(id);if(e){if(v!==undefined)e.value=v;else return e.value;}return'';}
function fb(id,msg,isErr){var e=$(id);if(!e)return;e.className='pvModal-fb '+(isErr?'err':'ok');e.textContent=msg;}
function openModal(id){var m=$(id);if(m)m.classList.add('open');}
function closeModal(id){var m=$(id);if(m)m.classList.remove('open');}

/* Close on background click / close btn */
document.addEventListener('click',function(e){
  if(e.target.classList.contains('pvModal-bg'))closeModal(e.target.id);
  if(e.target.dataset.close)closeModal(e.target.dataset.close);
});
document.addEventListener('keydown',function(e){
  if(e.key==='Escape')document.querySelectorAll('.pvModal-bg.open').forEach(function(m){m.classList.remove('open');});
});

/* ---- AJAX helper ---- */
function post(action,data,cb){
  var fd=new FormData();fd.append('action',action);fd.append('nonce',NON);
  if(data)Object.keys(data).forEach(function(k){fd.append(k,data[k]);});
  fetch(AJAX,{method:'POST',body:fd,credentials:'same-origin'})
    .then(function(r){return r.json();}).then(cb)
    .catch(function(){cb({success:false,data:{message:'Erro de conexão.'}});});
}

/* ---- LOGIN ---- */
var lBtn=$('pvLoginBtn');
if(lBtn){
  var fbEl=$('pvFb'),em=$('pvEmail'),pw=$('pvSenha');
  function doLogin(){
    if(!em||!pw||!em.value||!pw.value){if(fbEl){fbEl.className='pvFb err';fbEl.textContent='Preencha todos os campos.';}return;}
    lBtn.disabled=true;lBtn.textContent='Aguarde…';
    post('vdv_portal_login',{email:em.value,senha:pw.value},function(r){
      if(r.success){window.location.reload();}
      else{if(fbEl){fbEl.className='pvFb err';fbEl.textContent=(r.data&&r.data.message)||'Credenciais inválidas.';}lBtn.disabled=false;lBtn.textContent='Entrar no Portal';}
    });
  }
  lBtn.addEventListener('click',doLogin);
  [em,pw].forEach(function(i){if(i)i.addEventListener('keydown',function(e){if(e.key==='Enter')doLogin();});});
}

/* ---- DASHBOARD ---- */
var dash=$('pvDash');
if(dash){
  /* Logout */
  var loutBtn=$('pvLogout');
  if(loutBtn&&loutBtn.form){
    loutBtn.form.addEventListener('submit',function(e){
      e.preventDefault();
      post('vdv_portal_logout',{},function(){window.location.reload();});
    });
  }

  /* Carrega dados iniciais */
  post('vdv_portal_check',{},function(r){
    if(!r.success||!r.data||!r.data.logado){window.location.reload();return;}
    renderAll(r.data);
    $('pvSpinner').style.display='none';
    dash.style.display='';
  });

  /* Reload dados */
  function reload(cb){
    post('vdv_portal_check',{},function(r){
      if(r.success&&r.data&&r.data.logado){renderAll(r.data);if(cb)cb();}
    });
  }

  /* ======== RENDER COMPLETO ======== */
  function renderAll(d){
    INV=d.investidor||{};
    OPS=d.operacoes||[];
    VEHS=d.veiculos||[];
    MOVS=d.movimentos||[];
    var kpis=d.kpis||{};
    var mn=d.mensal||[];

    txt('pvR',brl(kpis.receita_total||0));
    txt('pvD',brl(kpis.despesa_total||0));
    txt('pvL',brl(kpis.lucro||0));
    if(kpis.var_pct!=null){
      var s=kpis.var_pct>=0?'+':'',c=kpis.var_pct>=0?'#4ade80':'#f87171';
      htm('pvV','<span style="color:'+c+'">'+s+Number(kpis.var_pct).toFixed(1)+'% vs mês ant.</span>');
    }
    txt('pvRend','Rendimento: '+brl((kpis.lucro||0)*((INV.participacao_pct||0)/100)));
    var ativos=VEHS.filter(function(v){return v.status==='ativo';}).length;
    txt('pvVA',ativos);txt('pvVT','de '+VEHS.length+' no total');

    /* Chart */
    var mx=0;mn.forEach(function(m){mx=Math.max(mx,+m.receita,+m.despesa);});
    var ms=['Jan','Fev','Mar','Abr','Mai','Jun','Jul','Ago','Set','Out','Nov','Dez'];
    var bars='',lbls='';
    mn.forEach(function(m){
      var hi=mx>0?Math.round((+m.receita/mx)*110):0,he=mx>0?Math.round((+m.despesa/mx)*110):0;
      var i=+m.mes-1;
      bars+='<div class="pvBarG" title="'+ms[i]+': Rec '+brl(m.receita)+' / Desp '+brl(m.despesa)+'"><div class="bI" style="height:'+hi+'px"></div><div class="bE" style="height:'+he+'px"></div></div>';
      lbls+='<div class="pvLbl">'+ms[i]+'</div>';
    });
    htm('pvChart','<div class="pvLeg"><span class="legG">Receita</span><span class="legR">Despesa</span></div>'
      +'<div class="pvChartWrap"><div class="pvBars">'+bars+'</div><div class="pvLbls">'+lbls+'</div></div>');

    /* Ops */
    renderOps();
    /* Frota */
    renderVehs();
    /* Movimentos */
    PG=1;renderTbl();
    /* Preenche selects de operação nos modais */
    populateOpSelects();
  }

  /* ======== OPS ======== */
  function renderOps(){
    htm('pvOps',OPS.length?OPS.map(function(o){
      var c=o.status==='ativo'?'bok':o.status==='pausa'?'bps':'bof';
      return'<div class="pvOp">'
        +'<div style="flex:1"><div class="opName">'+esc(o.nome)+'</div><div class="opLoc">'+o.cidades+' cidades &bull; '+o.estados+' estado(s)</div></div>'
        +'<div style="display:flex;align-items:center;gap:6px">'
        +'<span class="bdg '+c+'">'+esc(o.status)+'</span>'
        +'<button class="pvBtnEdit" data-edit-op="'+o.id+'">Editar</button>'
        +'<button class="pvBtnDel" data-del-op="'+o.id+'">✕</button>'
        +'</div></div>';
    }).join(''):'<p style="color:rgba(255,255,255,.35);font-size:.85rem">Nenhuma operação.</p>');
  }

  /* ======== VEHS ======== */
  function renderVehs(){
    htm('pvVehs',VEHS.length?VEHS.map(function(v){
      var c=v.status==='ativo'?'bok':v.status==='manutencao'?'bps':'bof';
      return'<div class="pvVeh">'
        +'<span class="vPlate">'+esc(v.placa)+'</span>'
        +'<div style="flex:1;margin:0 8px"><div class="vMod">'+esc(v.modelo)+'</div><div class="vAno">Ano '+v.ano+' &bull; '+v.capacidade+' pass.</div></div>'
        +'<div style="display:flex;align-items:center;gap:6px">'
        +'<span class="bdg '+c+'">'+esc(v.status)+'</span>'
        +'<button class="pvBtnEdit" data-edit-veh="'+v.id+'">Editar</button>'
        +'<button class="pvBtnDel" data-del-veh="'+v.id+'">✕</button>'
        +'</div></div>';
    }).join(''):'<p style="color:rgba(255,255,255,.35);font-size:.85rem">Nenhum veículo.</p>');
  }

  /* ======== TABELA MOVIMENTOS ======== */
  function renderTbl(){
    txt('pvMC',MOVS.length+' registros');
    if(!MOVS.length){htm('pvTbl','<p style="color:rgba(255,255,255,.35);font-size:.85rem">Nenhuma movimentação.</p>');return;}
    var s=(PG-1)*PER,sl=MOVS.slice(s,s+PER);
    var rows=sl.map(function(m){
      var inc=m.tipo==='receita';
      return'<tr>'
        +'<td class="tdD">'+esc(m.data_formatada)+'</td>'
        +'<td>'+esc(m.descricao)+'</td>'
        +'<td>'+esc(m.operacao_nome)+'</td>'
        +'<td class="'+(inc?'tdI':'tdE')+'">'+(inc?'+':'-')+brl(Math.abs(m.valor))+'</td>'
        +'<td><div class="tdAct">'
        +'<button class="pvBtnEdit" data-edit-mov="'+m.id+'">Editar</button>'
        +'<button class="pvBtnDel" data-del-mov="'+m.id+'">✕</button>'
        +'</div></td>'
        +'</tr>';
    }).join('');
    var pgs=Math.ceil(MOVS.length/PER),pag='';
    if(pgs>1){pag='<div class="pvPag">';for(var i=1;i<=pgs;i++)pag+='<button class="pgBtn'+(i===PG?' act':'')+'" data-p="'+i+'">'+i+'</button>';pag+='</div>';}
    htm('pvTbl','<div style="overflow-x:auto"><table class="pvTbl"><thead><tr><th>Data</th><th>Descrição</th><th>Operação</th><th>Valor</th><th></th></tr></thead><tbody>'+rows+'</tbody></table></div>'+pag);
  }

  /* Paginação */
  document.addEventListener('click',function(e){
    if(e.target.classList.contains('pgBtn')){PG=parseInt(e.target.dataset.p,10);renderTbl();}
  });

  /* ======== POPULATE SELECTS ======== */
  function populateOpSelects(){
    ['pvMovOp','pvVehOp'].forEach(function(sid){
      var sel=$(sid);if(!sel)return;
      var cur=sel.value;
      sel.innerHTML=(sid==='pvVehOp'?'<option value="">Sem operação</option>':'');
      OPS.forEach(function(o){
        var opt=document.createElement('option');
        opt.value=o.id;opt.textContent=o.nome;
        sel.appendChild(opt);
      });
      if(cur)sel.value=cur;
    });
  }

  /* ======== DELEGATED CLICKS ======== */
  document.addEventListener('click',function(e){
    var t=e.target;

    /* -- Adicionar Operação -- */
    if(t.id==='pvAddOp'){
      val('pvOpId','');val('pvOpNome','');val('pvOpCidades','');val('pvOpEstados','');
      val('pvOpStatus','ativo');val('pvOpInicio','');val('pvOpDesc','');
      $('pvModalOpTitle').textContent='Nova Operação';
      $('pvModalOpFb').className='pvModal-fb';
      openModal('pvModalOp');
    }
    /* -- Editar Operação -- */
    if(t.dataset.editOp){
      var opId=t.dataset.editOp;
      var op=OPS.find(function(o){return String(o.id)===String(opId);});
      if(!op)return;
      val('pvOpId',op.id);val('pvOpNome',op.nome);val('pvOpCidades',op.cidades);
      val('pvOpEstados',op.estados);val('pvOpStatus',op.status);
      val('pvOpInicio',op.iniciado_em||'');val('pvOpDesc',op.descricao||'');
      $('pvModalOpTitle').textContent='Editar Operação';
      $('pvModalOpFb').className='pvModal-fb';
      openModal('pvModalOp');
    }
    /* -- Deletar Operação -- */
    if(t.dataset.delOp){
      pendingDelete={action:'vdv_portal_delete_operation',id:t.dataset.delOp};
      openModal('pvModalConfirm');
    }

    /* -- Adicionar Veículo -- */
    if(t.id==='pvAddVeh'){
      val('pvVehId','');val('pvVehPlaca','');val('pvVehModelo','');val('pvVehAno','');
      val('pvVehCap','');val('pvVehKm','0');val('pvVehStatus','ativo');val('pvVehOp','');val('pvVehChassi','');
      $('pvModalVehTitle').textContent='Novo Veículo';
      $('pvModalVehFb').className='pvModal-fb';
      openModal('pvModalVeh');
    }
    /* -- Editar Veículo -- */
    if(t.dataset.editVeh){
      var vId=t.dataset.editVeh;
      var veh=VEHS.find(function(v){return String(v.id)===String(vId);});
      if(!veh)return;
      val('pvVehId',veh.id);val('pvVehPlaca',veh.placa);val('pvVehModelo',veh.modelo);
      val('pvVehAno',veh.ano);val('pvVehCap',veh.capacidade);val('pvVehKm',veh.km_atual||0);
      val('pvVehStatus',veh.status);val('pvVehOp',veh.operacao_id||'');val('pvVehChassi',veh.chassi||'');
      $('pvModalVehTitle').textContent='Editar Veículo';
      $('pvModalVehFb').className='pvModal-fb';
      openModal('pvModalVeh');
    }
    /* -- Deletar Veículo -- */
    if(t.dataset.delVeh){
      pendingDelete={action:'vdv_portal_delete_vehicle',id:t.dataset.delVeh};
      openModal('pvModalConfirm');
    }

    /* -- Adicionar Movimento -- */
    if(t.id==='pvAddMov'){
      val('pvMovId','');val('pvMovTipo','receita');val('pvMovOp','');val('pvMovCat','');
      val('pvMovDesc','');val('pvMovValor','');val('pvMovData',new Date().toISOString().slice(0,10));val('pvMovRef','');
      $('pvModalMovTitle').textContent='Novo Movimento';
      $('pvModalMovFb').className='pvModal-fb';
      openModal('pvModalMov');
    }
    /* -- Editar Movimento -- */
    if(t.dataset.editMov){
      var mId=t.dataset.editMov;
      var mov=MOVS.find(function(m){return String(m.id)===String(mId);});
      if(!mov)return;
      val('pvMovId',mov.id);val('pvMovTipo',mov.tipo);val('pvMovOp',mov.operacao_id);
      val('pvMovCat',mov.categoria);val('pvMovDesc',mov.descricao);
      val('pvMovValor',Math.abs(mov.valor));val('pvMovData',mov.data_mov);val('pvMovRef',mov.referencia||'');
      $('pvModalMovTitle').textContent='Editar Movimento';
      $('pvModalMovFb').className='pvModal-fb';
      openModal('pvModalMov');
    }
    /* -- Deletar Movimento -- */
    if(t.dataset.delMov){
      pendingDelete={action:'vdv_portal_delete_movement',id:t.dataset.delMov};
      openModal('pvModalConfirm');
    }

    /* -- Confirmar exclusão -- */
    if(t.id==='pvConfirmYes'&&pendingDelete.action){
      t.disabled=true;t.textContent='Excluindo…';
      post(pendingDelete.action,{id:pendingDelete.id},function(r){
        t.disabled=false;t.textContent='Excluir';
        closeModal('pvModalConfirm');
        if(r.success){reload();}
        else{alert((r.data&&r.data.message)||'Erro ao excluir.');}
        pendingDelete={action:null,id:null};
      });
    }
    if(t.id==='pvConfirmNo'){closeModal('pvModalConfirm');}
  });

  /* ======== SALVAR MOVIMENTO ======== */
  var savMovBtn=$('pvSaveMov');
  if(savMovBtn)savMovBtn.addEventListener('click',function(){
    var id=val('pvMovId'),tipo=val('pvMovTipo'),opId=val('pvMovOp'),cat=val('pvMovCat');
    var desc=val('pvMovDesc'),valor=val('pvMovValor'),data=val('pvMovData');
    if(!tipo||!cat||!desc||!valor||!data){fb('pvModalMovFb','Preencha os campos obrigatórios.',true);return;}
    savMovBtn.disabled=true;savMovBtn.textContent='Salvando…';
    post(id?'vdv_portal_update_movement':'vdv_portal_add_movement',
      {id:id,tipo:tipo,operacao_id:opId,categoria:cat,descricao:desc,valor:valor,data_mov:data,referencia:val('pvMovRef')},
      function(r){
        savMovBtn.disabled=false;savMovBtn.textContent='Salvar Movimento';
        if(r.success){closeModal('pvModalMov');reload();}
        else{fb('pvModalMovFb',(r.data&&r.data.message)||'Erro ao salvar.',true);}
      });
  });

  /* ======== SALVAR VEÍCULO ======== */
  var savVehBtn=$('pvSaveVeh');
  if(savVehBtn)savVehBtn.addEventListener('click',function(){
    var id=val('pvVehId'),placa=val('pvVehPlaca').toUpperCase(),modelo=val('pvVehModelo');
    var ano=val('pvVehAno'),cap=val('pvVehCap'),status=val('pvVehStatus');
    if(!placa||!modelo||!ano||!cap){fb('pvModalVehFb','Preencha os campos obrigatórios.',true);return;}
    savVehBtn.disabled=true;savVehBtn.textContent='Salvando…';
    post(id?'vdv_portal_update_vehicle':'vdv_portal_add_vehicle',
      {id:id,placa:placa,modelo:modelo,ano:ano,capacidade:cap,status:status,
       operacao_id:val('pvVehOp'),km_atual:val('pvVehKm'),chassi:val('pvVehChassi')},
      function(r){
        savVehBtn.disabled=false;savVehBtn.textContent='Salvar Veículo';
        if(r.success){closeModal('pvModalVeh');reload();}
        else{fb('pvModalVehFb',(r.data&&r.data.message)||'Erro ao salvar.',true);}
      });
  });

  /* ======== SALVAR OPERAÇÃO ======== */
  var savOpBtn=$('pvSaveOp');
  if(savOpBtn)savOpBtn.addEventListener('click',function(){
    var id=val('pvOpId'),nome=val('pvOpNome'),status=val('pvOpStatus');
    if(!nome){fb('pvModalOpFb','Informe o nome da operação.',true);return;}
    savOpBtn.disabled=true;savOpBtn.textContent='Salvando…';
    post(id?'vdv_portal_update_operation':'vdv_portal_add_operation',
      {id:id,nome:nome,cidades:val('pvOpCidades'),estados:val('pvOpEstados'),status:status,
       iniciado_em:val('pvOpInicio'),descricao:val('pvOpDesc')},
      function(r){
        savOpBtn.disabled=false;savOpBtn.textContent='Salvar Operação';
        if(r.success){closeModal('pvModalOp');reload();}
        else{fb('pvModalOpFb',(r.data&&r.data.message)||'Erro ao salvar.',true);}
      });
  });

  /* ======== PERFIL ======== */
  var perfilBtn=$('pvPerfil');
  if(perfilBtn)perfilBtn.addEventListener('click',function(){
    val('pvPNome',INV.nome||'');val('pvPEmail',INV.email||'');
    val('pvPSenhaAtual','');val('pvPSenhaNova','');val('pvPSenhaConf','');
    $('pvModalPerfilFb').className='pvModal-fb';
    openModal('pvModalPerfil');
  });

  /* Tab switching no perfil */
  document.querySelectorAll('.pvTab-btn').forEach(function(btn){
    btn.addEventListener('click',function(){
      var panel=btn.dataset.tab;
      document.querySelectorAll('.pvTab-btn').forEach(function(b){b.classList.remove('active');});
      document.querySelectorAll('.pvTab-panel').forEach(function(p){p.classList.remove('active');});
      btn.classList.add('active');
      var p=$(panel);if(p)p.classList.add('active');
    });
  });

  var savPerfilBtn=$('pvSavePerfil');
  if(savPerfilBtn)savPerfilBtn.addEventListener('click',function(){
    var nome=val('pvPNome'),email=val('pvPEmail');
    if(!nome||!email){fb('pvModalPerfilFb','Preencha nome e e-mail.',true);return;}
    savPerfilBtn.disabled=true;savPerfilBtn.textContent='Salvando…';
    post('vdv_portal_update_profile',{nome:nome,email:email},function(r){
      savPerfilBtn.disabled=false;savPerfilBtn.textContent='Salvar Dados';
      if(r.success){fb('pvModalPerfilFb','Dados atualizados!',false);INV.nome=nome;INV.email=email;}
      else{fb('pvModalPerfilFb',(r.data&&r.data.message)||'Erro ao salvar.',true);}
    });
  });

  var savSenhaBtn=$('pvSaveSenha');
  if(savSenhaBtn)savSenhaBtn.addEventListener('click',function(){
    var at=val('pvPSenhaAtual'),nv=val('pvPSenhaNova'),cf=val('pvPSenhaConf');
    if(!at||!nv||!cf){fb('pvModalPerfilFb','Preencha todos os campos.',true);return;}
    if(nv.length<6){fb('pvModalPerfilFb','A nova senha deve ter pelo menos 6 caracteres.',true);return;}
    if(nv!==cf){fb('pvModalPerfilFb','As senhas não conferem.',true);return;}
    savSenhaBtn.disabled=true;savSenhaBtn.textContent='Salvando…';
    post('vdv_portal_change_password',{senha_atual:at,senha_nova:nv},function(r){
      savSenhaBtn.disabled=false;savSenhaBtn.textContent='Alterar Senha';
      if(r.success){fb('pvModalPerfilFb','Senha alterada com sucesso!',false);val('pvPSenhaAtual','');val('pvPSenhaNova','');val('pvPSenhaConf','');}
      else{fb('pvModalPerfilFb',(r.data&&r.data.message)||'Erro ao alterar.',true);}
    });
  });
}
})();
</script>

    <?php
    return ob_get_clean();
}
