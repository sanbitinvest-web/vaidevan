<!DOCTYPE html>
<html <?php language_attributes(); ?> prefix="og: https://ogp.me/ns#">
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=5">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="sr-only" href="#main-content">Ir para o conteúdo principal</a>

<!-- TRUST STRIP — autoridade máxima -->
<div id="trust-strip" role="complementary" aria-label="Credenciais VaideVan">
  <div class="trust-strip-inner">
    <span class="trust-item"><span class="trust-icon" aria-hidden="true">🏆</span><span data-i18n="trust.inpi">Marca Registrada INPI</span></span>
    <span class="trust-sep" aria-hidden="true">·</span>
    <span class="trust-item"><span class="trust-icon" aria-hidden="true">⭐</span><span data-i18n="trust.google">Avaliação 5.0 Google</span></span>
    <span class="trust-sep" aria-hidden="true">·</span>
    <span class="trust-item"><span class="trust-icon" aria-hidden="true">🌎</span><span data-i18n="trust.intl">Atendimento Internacional</span></span>
    <span class="trust-sep" aria-hidden="true">·</span>
    <span class="trust-item"><span class="trust-icon" aria-hidden="true">📅</span><span data-i18n="trust.years">20+ Anos de Mercado</span></span>
  </div>
</div>

<header id="site-header" role="banner">
    <div class="container header-inner">
        <a href="<?= esc_url(home_url('/')) ?>" class="site-logo" aria-label="VaideVan — Início">
            <picture>
                <source srcset="<?= esc_url(get_template_directory_uri()) ?>/assets/images/logo-dark.webp" type="image/webp">
                <img src="<?= esc_url(get_template_directory_uri()) ?>/assets/images/logo-dark.jpg"
                     alt="VaideVan — Transporte Executivo"
                     width="56" height="56" loading="eager" fetchpriority="high"
                     style="object-fit:contain;background:transparent">
            </picture>
        </a>

        <nav class="main-nav" role="navigation" aria-label="Navegação principal">
            <a href="<?= esc_url(home_url('/')) ?>#inicio" data-i18n="nav.inicio">Início</a>
            <a href="<?= esc_url(home_url('/')) ?>#servicos" data-i18n="nav.servicos">Serviços</a>
            <a href="<?= esc_url(home_url('/customizacao/')) ?>" data-i18n="nav.customizacao">Transformação 3D</a>
            <a href="<?= esc_url(home_url('/')) ?>#seja-investidor" data-i18n="nav.investidor">Seja Investidor</a>
            <a href="<?= esc_url(home_url('/')) ?>#nossa-historia" data-i18n="nav.historia">Nossa História</a>
            <a href="<?= esc_url(home_url('/')) ?>#faq" data-i18n="nav.faq">FAQ</a>
            <a href="<?= esc_url(home_url('/blog/')) ?>" data-i18n="nav.blog">Blog</a>
        </nav>

        <div class="header-actions">
            <!-- Seletor de idioma -->
            <div class="lang-switcher" role="navigation" aria-label="Idioma / Language">
                <button class="lang-btn lang-btn--active" data-lang="pt" onclick="vdvSetLang('pt')" aria-pressed="true" title="Português (Brasil)">🇧🇷 PT</button>
                <button class="lang-btn" data-lang="en" onclick="vdvSetLang('en')" aria-pressed="false" title="English">🇺🇸 EN</button>
                <button class="lang-btn" data-lang="es" onclick="vdvSetLang('es')" aria-pressed="false" title="Español">🇪🇸 ES</button>
                <button class="lang-btn" data-lang="zh" onclick="vdvSetLang('zh')" aria-pressed="false" title="中文 (简体)">🇨🇳 中</button>
            </div>
            <a href="<?= esc_url(get_option('vdv_portal_url', 'https://portal.vaidevan.com')) ?>" class="btn-portal-h" target="_blank" rel="noopener" data-i18n="btn.portal">Portal do Investidor</a>
            <button class="btn-quote-h" id="openQuoteModal" onclick="document.getElementById('quoteModal').classList.add('open')">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true"><path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07A19.5 19.5 0 013.07 10.8a19.79 19.79 0 01-3.07-8.67A2 2 0 012 0h3a2 2 0 012 1.72 12.84 12.84 0 00.7 2.81 2 2 0 01-.45 2.11L6.09 7.91a16 16 0 006 6l1.27-1.27a2 2 0 012.11-.45 12.84 12.84 0 002.81.7A2 2 0 0122 14h-.08v2.92z"/></svg>
                <span data-i18n="btn.quote">Solicitar Orçamento</span>
            </button>
            <button class="menu-toggle" id="menuTog" aria-expanded="false" aria-controls="mobileMenu" aria-label="Abrir menu">
                <span></span><span></span><span></span>
            </button>
        </div>
    </div>
</header>

<nav id="mobileMenu" class="mobile-menu" role="navigation" aria-label="Menu mobile" aria-hidden="true">
    <a href="<?= esc_url(home_url('/')) ?>#inicio" onclick="closeMobileMenu()" data-i18n="nav.inicio">Início</a>
    <a href="<?= esc_url(home_url('/')) ?>#servicos" onclick="closeMobileMenu()" data-i18n="nav.servicos">Serviços</a>
    <a href="<?= esc_url(home_url('/customizacao/')) ?>" onclick="closeMobileMenu()" style="color:var(--primary);font-weight:800">🚐 <span data-i18n="nav.customizacao">Transformação 3D</span></a>
    <a href="<?= esc_url(home_url('/')) ?>#seja-investidor" onclick="closeMobileMenu()" data-i18n="nav.investidor">Seja Investidor</a>
    <a href="<?= esc_url(home_url('/')) ?>#nossa-historia" onclick="closeMobileMenu()" data-i18n="nav.historia">Nossa História</a>
    <a href="<?= esc_url(home_url('/blog/')) ?>" data-i18n="nav.blog">Blog</a>
    <!-- Lang switcher mobile -->
    <div class="lang-switcher lang-switcher--mobile" role="navigation" aria-label="Idioma">
        <button class="lang-btn lang-btn--active" data-lang="pt" onclick="vdvSetLang('pt');closeMobileMenu()" aria-pressed="true">🇧🇷 PT</button>
        <button class="lang-btn" data-lang="en" onclick="vdvSetLang('en');closeMobileMenu()" aria-pressed="false">🇺🇸 EN</button>
        <button class="lang-btn" data-lang="es" onclick="vdvSetLang('es');closeMobileMenu()" aria-pressed="false">🇪🇸 ES</button>
        <button class="lang-btn" data-lang="zh" onclick="vdvSetLang('zh');closeMobileMenu()" aria-pressed="false">🇨🇳 中</button>
    </div>
    <a href="<?= esc_url(get_option('vdv_portal_url', 'https://portal.vaidevan.com')) ?>" class="btn-portal-h" style="width:100%;justify-content:center;height:44px;display:flex;align-items:center" target="_blank" rel="noopener" onclick="closeMobileMenu()" data-i18n="btn.portal">Portal do Investidor</a>
    <button class="btn-quote-h" style="width:100%;justify-content:center;height:44px" onclick="closeMobileMenu();document.getElementById('quoteModal').classList.add('open')">
        <span data-i18n="btn.quote">Solicitar Orçamento</span>
    </button>
</nav>

<main id="main-content" role="main" tabindex="-1">
