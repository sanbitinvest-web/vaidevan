<?php
/**
 * Template Name: Customização / Transformação 3D
 * Template Post Type: page
 */
defined('ABSPATH') || exit;
get_header();
$tdir = esc_url(get_template_directory_uri());
$WA   = 'https://wa.me/5511999294694?text=Ol%C3%A1!%20Gostaria%20de%20informa%C3%A7%C3%B5es%20sobre%20customiza%C3%A7%C3%A3o%20de%20van%20executiva%20VaideVan.';

$models = [
  [
    'id'      => 'curta',
    'badge'   => '🏆 Mais Vendida',
    'brand'   => 'Mercedes-Benz',
    'name'    => 'Sprinter Curta Teto Alto',
    'year'    => '2025 / 2026',
    'specs'   => ['CDI 415 / 416 / 417', 'Teto Alto H2 — 1,98m interno', 'Até 15 passageiros', 'Wheelbase curto — ágil na cidade'],
    'color'   => '#00A19A',
    'img'     => '/assets/images/vans/exterior-sprinter417.png',
    'desc'    => 'A queridinha das frotas urbanas. Teto alto permite movimentação interna confortável. Ideal para transfer aeroporto, fretamento diário e circuitos na cidade.',
  ],
  [
    'id'      => 'longa',
    'badge'   => '⭐ Premium',
    'brand'   => 'Mercedes-Benz',
    'name'    => 'Sprinter Longa',
    'year'    => '2025 / 2026',
    'specs'   => ['CDI 516 / 517 / 519', 'Teto Alto H2 — 2,10m interno', 'Até 19 passageiros', 'Wheelbase longo — máximo conforto'],
    'color'   => '#F5E642',
    'img'     => '/assets/images/vans/exterior-sprinter517.png',
    'desc'    => 'Para grupos maiores sem abrir mão do conforto executivo. Espaço interno generoso, ideal para fretamento corporativo, excursões e eventos.',
  ],
  [
    'id'      => 'extralonga',
    'badge'   => '🚀 Novo 2026',
    'brand'   => 'Mercedes-Benz',
    'name'    => 'Sprinter Extra Longa',
    'year'    => '2026',
    'specs'   => ['CDI 519 / 523 XL', 'Teto Panorâmico / Duplo Teto', 'Até 23 passageiros', 'Maior volume de carga + pax'],
    'color'   => '#C8A84B',
    'img'     => '/assets/images/vans/exterior-master.png',
    'desc'    => 'A versão extra longa 2026 representa o máximo em capacidade e sofisticação. Projeto sob encomenda com customização total do interior.',
  ],
];

$tiers = [
  ['Essencial',  '#888',    'R$ 18.000', 'Couro sintético, LED, piso vinílico, rack interno'],
  ['Executive',  '#00A19A', 'R$ 28.000', 'Couro legítimo, LED dourado, JBL, mesa central'],
  ['JetVan',     '#1C69D4', 'R$ 45.000', 'Estilo jato privado, LED azul, poltronas reclináveis 180°'],
  ['LimoVan',    '#C8A84B', 'R$ 65.000', 'Frente a frente gold, frigobar, cortinas blackout'],
  ['SpaceLimo',  '#9B59B6', 'R$ 95.000', 'Tela 4K, Dolby Atmos, LED roxo, bar completo'],
];
?>

<style>
/* ---- HERO ---- */
.ct-hero{position:relative;min-height:60vh;display:flex;align-items:center;padding:120px 1rem 72px;
  background:linear-gradient(135deg,rgba(0,0,0,.92) 0%,rgba(0,0,0,.75) 60%,rgba(10,9,0,.88) 100%),
  url('<?= $tdir ?>/assets/images/hero-vans.jpg') center/cover no-repeat}
.ct-hero-inner{max-width:800px;margin:0 auto;text-align:center}
.ct-hero-tag{display:inline-flex;align-items:center;gap:8px;border:1px solid rgba(245,230,66,.5);
  border-radius:9999px;padding:6px 20px;font-size:.75rem;font-weight:700;letter-spacing:.15em;
  color:var(--primary);text-transform:uppercase;margin-bottom:24px}
.ct-hero-h1{font-size:clamp(2.2rem,5vw,3.75rem);font-weight:900;line-height:1.08;margin-bottom:20px;
  font-family:var(--fh),Arial,sans-serif;letter-spacing:.03em}
.ct-hero-h1 span{color:var(--primary)}
.ct-hero-sub{font-size:1.1rem;color:rgba(255,255,255,.7);max-width:560px;margin:0 auto 32px}
.ct-hero-btns{display:flex;gap:12px;justify-content:center;flex-wrap:wrap}

/* ---- MODELS ---- */
.ct-models{padding:80px 0;background:var(--bg)}
.ct-models-header{text-align:center;margin-bottom:56px}

.model-cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:28px;
  max-width:1200px;margin:0 auto;padding:0 1rem}

.model-card{background:var(--card);border-radius:20px;overflow:hidden;border:1px solid rgba(255,255,255,.07);
  transition:transform .3s,box-shadow .3s;position:relative}
.model-card:hover{transform:translateY(-8px);box-shadow:0 24px 48px rgba(0,0,0,.4)}

/* 3D perspective viewport */
.model-3d-wrap{position:relative;height:220px;overflow:hidden;background:#0d0d0d;
  perspective:800px}
.model-3d-stage{width:100%;height:100%;display:flex;align-items:center;justify-content:center;
  transform-style:preserve-3d;transition:transform .6s ease}
.model-card:hover .model-3d-stage{transform:rotateY(-6deg) rotateX(3deg) scale(1.04)}
.model-3d-img{width:90%;max-height:200px;object-fit:contain;filter:drop-shadow(0 12px 24px rgba(0,0,0,.6));
  transform:translateZ(20px)}
.model-3d-glow{position:absolute;bottom:0;left:50%;transform:translateX(-50%);
  width:70%;height:40px;border-radius:50%;filter:blur(18px);opacity:.5}

.model-badge{position:absolute;top:16px;left:16px;font-size:.7rem;font-weight:800;
  padding:4px 12px;border-radius:9999px;letter-spacing:.08em;background:rgba(0,0,0,.7);
  backdrop-filter:blur(8px);border:1px solid rgba(255,255,255,.15)}

.model-body{padding:24px}
.model-brand{font-size:.7rem;font-weight:700;text-transform:uppercase;letter-spacing:.12em;
  color:rgba(255,255,255,.4);margin-bottom:4px}
.model-name{font-size:1.35rem;font-weight:800;margin-bottom:4px;font-family:var(--fd)}
.model-year{font-size:.75rem;font-weight:600;color:rgba(255,255,255,.4);margin-bottom:16px}
.model-desc{font-size:.85rem;color:rgba(255,255,255,.65);line-height:1.6;margin-bottom:20px}
.model-specs{display:flex;flex-direction:column;gap:6px;margin-bottom:24px}
.model-spec{display:flex;align-items:center;gap:8px;font-size:.8rem;color:rgba(255,255,255,.7)}
.model-spec::before{content:'';width:6px;height:6px;border-radius:50%;background:currentColor;
  flex-shrink:0}
.model-cta{display:flex;align-items:center;justify-content:center;gap:8px;width:100%;
  padding:12px 0;border-radius:10px;font-weight:700;font-size:.875rem;text-decoration:none;
  transition:all .25s;background:rgba(255,255,255,.07);color:#fff}
.model-cta:hover{color:#000}

/* ---- TIERS ---- */
.ct-tiers{padding:80px 0;background:var(--card2)}
.tiers-header{text-align:center;margin-bottom:48px}
.tiers-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:20px;
  max-width:1100px;margin:0 auto;padding:0 1rem}
.tier-card{background:var(--card);border-radius:16px;padding:28px 20px;text-align:center;
  border:1px solid rgba(255,255,255,.07);transition:transform .3s,border-color .3s}
.tier-card:hover{transform:translateY(-6px)}
.tier-num{font-size:2rem;font-weight:900;font-family:var(--fh);margin-bottom:4px}
.tier-name{font-size:1rem;font-weight:800;margin-bottom:8px}
.tier-price{font-size:.85rem;font-weight:700;color:rgba(255,255,255,.5);margin-bottom:12px}
.tier-feats{font-size:.78rem;color:rgba(255,255,255,.6);line-height:1.7}
.tier-btn{display:block;margin-top:16px;padding:10px 0;border-radius:8px;font-weight:700;
  font-size:.8rem;text-decoration:none;transition:all .25s;color:#000}

/* ---- BLINDAGEM ---- */
.ct-armor{padding:64px 0;background:linear-gradient(135deg,#0D0D0D 0%,#111 100%)}
.armor-box{max-width:900px;margin:0 auto;padding:0 1rem;display:grid;
  grid-template-columns:1fr 1fr;gap:40px;align-items:center}
.armor-title{font-size:clamp(1.75rem,3vw,2.25rem);font-weight:900;margin-bottom:16px}
.armor-title span{color:var(--primary)}
.armor-list{list-style:none;padding:0;margin:0 0 24px}
.armor-list li{padding:8px 0;border-bottom:1px solid rgba(255,255,255,.06);
  font-size:.875rem;color:rgba(255,255,255,.75);display:flex;gap:10px;align-items:center}
.armor-list li::before{content:'✓';color:var(--primary);font-weight:900}
.armor-levels{display:grid;grid-template-columns:1fr 1fr;gap:12px}
.armor-level{background:rgba(200,168,75,.1);border:1px solid rgba(200,168,75,.3);
  border-radius:10px;padding:14px 16px;text-align:center}
.armor-level-code{font-size:1.1rem;font-weight:900;color:#C8A84B}
.armor-level-desc{font-size:.72rem;color:rgba(255,255,255,.5);margin-top:2px}

/* ---- CTA FINAL ---- */
.ct-final-cta{padding:72px 1rem;text-align:center;background:var(--bg)}
.ct-final-cta h2{font-size:clamp(1.75rem,4vw,2.75rem);font-weight:900;margin-bottom:16px}
.ct-final-cta p{color:rgba(255,255,255,.6);margin-bottom:32px;font-size:1rem;max-width:520px;margin-left:auto;margin-right:auto}

/* ---- RESPONSIVE ---- */
@media(max-width:640px){
  .armor-box{grid-template-columns:1fr}
  .ct-hero{padding:100px 1rem 56px}
  .model-cards{grid-template-columns:1fr}
}
</style>

<!-- HERO -->
<section class="ct-hero" aria-label="Customização de Vans Executivas">
  <div class="ct-hero-inner">
    <div class="ct-hero-tag">✦ Transformação &amp; Customização 3D</div>
    <h1 class="ct-hero-h1">Mercedes Sprinter<br><span>Customizada do Jeito</span> que Você Imaginou</h1>
    <p class="ct-hero-sub">Da versão Curta Teto Alto até a Extra Longa 2026 — projetos completos de upfitting executivo, com ou sem blindagem. São Paulo e todo Brasil.</p>
    <div class="ct-hero-btns">
      <a href="<?= esc_url($WA) ?>" target="_blank" rel="noopener" class="btn-primary-lg" style="height:52px;padding:0 36px;font-size:1rem">
        💬 Solicitar Projeto Personalizado
      </a>
      <a href="#modelos" class="btn-secondary" style="height:52px;padding:0 28px;font-size:1rem">
        Ver Modelos ↓
      </a>
    </div>
  </div>
</section>

<!-- MODELOS 3D -->
<section id="modelos" class="ct-models" aria-label="Modelos Mercedes-Benz Sprinter 2025/2026">
  <div class="container">
    <div class="ct-models-header">
      <span class="section-tag">Modelos Disponíveis</span>
      <h2 class="section-h2">Sprinter 2025 / 2026 — <span class="accent">Três Carrocerias</span></h2>
      <p class="section-body" style="max-width:560px;margin:0 auto">Escolha a carroceria ideal para o seu projeto. Todos os modelos disponíveis para customização completa de interior e exterior.</p>
    </div>
    <div class="model-cards">
      <?php foreach($models as $m): ?>
      <article class="model-card vv-reveal-up" aria-label="<?= esc_attr($m['name']) ?>">
        <div class="model-3d-wrap">
          <div class="model-3d-stage">
            <img class="model-3d-img"
                 src="<?= esc_url($tdir . $m['img']) ?>"
                 alt="<?= esc_attr($m['name'] . ' ' . $m['year']) ?>"
                 width="400" height="200" loading="lazy" decoding="async">
            <div class="model-3d-glow" style="background:<?= esc_attr($m['color']) ?>"></div>
          </div>
          <div class="model-badge" style="color:<?= esc_attr($m['color']) ?>"><?= esc_html($m['badge']) ?></div>
        </div>
        <div class="model-body">
          <p class="model-brand"><?= esc_html($m['brand']) ?></p>
          <h3 class="model-name" style="color:<?= esc_attr($m['color']) ?>"><?= esc_html($m['name']) ?></h3>
          <p class="model-year">Modelo <?= esc_html($m['year']) ?></p>
          <p class="model-desc"><?= esc_html($m['desc']) ?></p>
          <div class="model-specs">
            <?php foreach($m['specs'] as $s): ?>
            <div class="model-spec" style="color:<?= esc_attr($m['color']) ?>"><?= esc_html($s) ?></div>
            <?php endforeach; ?>
          </div>
          <a href="<?= esc_url('https://wa.me/5511999294694?text=Ol%C3%A1!%20Quero%20customizar%20a%20' . rawurlencode($m['name'])) ?>"
             target="_blank" rel="noopener"
             class="model-cta" style="background:<?= esc_attr($m['color']) ?>22;border:1px solid <?= esc_attr($m['color']) ?>44;color:<?= esc_attr($m['color']) ?>">
            💬 Personalizar esta Sprinter
          </a>
        </div>
      </article>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- NÍVEIS DE CUSTOMIZAÇÃO -->
<section class="ct-tiers" aria-label="Níveis de Customização Executiva">
  <div class="container">
    <div class="tiers-header">
      <span class="section-tag">Projetos de Interior</span>
      <h2 class="section-h2">5 Níveis de <span class="accent">Transformação Executiva</span></h2>
      <p class="section-body" style="max-width:520px;margin:0 auto">Do upfit básico ao projeto mais sofisticado — cada nível foi desenvolvido para um perfil de uso específico.</p>
    </div>
    <div class="tiers-grid">
      <?php foreach($tiers as $i => [$name, $clr, $price, $desc]): ?>
      <div class="tier-card vv-reveal-up" style="transition-delay:<?= $i*.08 ?>s;border-color:<?= $clr ?>33">
        <div class="tier-num" style="color:<?= $clr ?>">0<?= $i+1 ?></div>
        <div class="tier-name"><?= esc_html($name) ?></div>
        <div class="tier-price"><?= esc_html($price) ?></div>
        <div class="tier-feats"><?= esc_html($desc) ?></div>
        <a href="<?= esc_url('https://wa.me/5511999294694?text=Ol%C3%A1!%20Tenho%20interesse%20no%20pacote%20' . rawurlencode($name)) ?>"
           target="_blank" rel="noopener"
           class="tier-btn" style="background:<?= $clr ?>;color:<?= ($clr === '#F5E642' ? '#000' : '#fff') ?>">
          Solicitar <?= esc_html($name) ?>
        </a>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- BLINDAGEM -->
<section class="ct-armor" aria-label="Blindagem Executiva VaideVan">
  <div class="armor-box">
    <div>
      <span class="section-tag">Opcional Premium</span>
      <h2 class="armor-title">Blindagem<br><span>Executiva</span> incluída</h2>
      <ul class="armor-list">
        <li>Blindagem certificada pelo INMETRO</li>
        <li>Vidros blindados sem alteração visual</li>
        <li>Integração total com projeto de interior</li>
        <li>Homologação Denatran inclusa</li>
        <li>Disponível para todos os modelos Sprinter</li>
        <li>Prazo: 60 a 90 dias a partir da aprovação</li>
      </ul>
      <a href="<?= esc_url('https://wa.me/5511999294694?text=Ol%C3%A1!%20Quero%20informa%C3%A7%C3%B5es%20sobre%20blindagem%20executiva.') ?>"
         target="_blank" rel="noopener" class="btn-primary-lg" style="height:48px;padding:0 28px;font-size:.9rem">
        🛡 Consultar Blindagem
      </a>
    </div>
    <div>
      <p style="font-size:.75rem;font-weight:700;text-transform:uppercase;letter-spacing:.1em;color:rgba(255,255,255,.4);margin-bottom:20px">Níveis disponíveis</p>
      <div class="armor-levels">
        <div class="armor-level"><div class="armor-level-code">Nível III-A</div><div class="armor-level-desc">Pistolas e submetralhadoras</div></div>
        <div class="armor-level"><div class="armor-level-code">Nível III</div><div class="armor-level-desc">Rifles de assalto até 7,62mm</div></div>
        <div class="armor-level"><div class="armor-level-code">Nível IV</div><div class="armor-level-desc">Rifles de alta potência .30-06</div></div>
        <div class="armor-level"><div class="armor-level-code">Anti-Bomb</div><div class="armor-level-desc">Piso e assoalho reforçados</div></div>
      </div>
    </div>
  </div>
</section>

<!-- CTA FINAL -->
<section class="ct-final-cta">
  <span class="section-tag">Fale com um Especialista</span>
  <h2>Pronto para <span class="accent">Transformar</span> sua Sprinter?</h2>
  <p>Envie as especificações do seu projeto. Nossa equipe retorna em até 2 horas com proposta personalizada.</p>
  <div style="display:flex;gap:12px;justify-content:center;flex-wrap:wrap">
    <a href="<?= esc_url($WA) ?>" target="_blank" rel="noopener" class="btn-primary-lg" style="height:52px;padding:0 40px;font-size:1rem">
      💬 Iniciar Projeto no WhatsApp
    </a>
    <a href="<?= esc_url(home_url('/')) ?>#contato" class="btn-secondary" style="height:52px;padding:0 28px;font-size:1rem">
      📧 Enviar Briefing por E-mail
    </a>
  </div>
  <p style="margin-top:24px;font-size:.8rem;color:rgba(255,255,255,.3)">
    +5511 99929-4694 &nbsp;·&nbsp; São Paulo, SP &nbsp;·&nbsp; 20 anos de experiência &nbsp;·&nbsp; 12 estados
  </p>
</section>

<?php get_footer(); ?>
