<?php
defined('ABSPATH') || exit;
get_header();
$tdir    = esc_url(get_template_directory_uri());
$logo_webp = $tdir . '/assets/images/logo-dark.webp'; /* WebP moderno — melhor score PageSpeed */
$logo      = $tdir . '/assets/images/logo-dark.jpg';  /* Fallback JPG para browsers antigos */
$WA      = 'https://wa.me/5511999294694?text=Ol%C3%A1!%20Gostaria%20de%20solicitar%20um%20or%C3%A7amento%20de%20transporte.';
$WA_NOW  = 'https://wa.me/5511999294694?text=Ol%C3%A1!%20Gostaria%20de%20um%20or%C3%A7amento%20agora.';
$WA_INV  = 'https://wa.me/5511999294694?text=Ol%C3%A1!%20Tenho%20interesse%20em%20ser%20investidor%20da%20VaideVan.';
?>
<!-- HERO -->
<section id="inicio" aria-label="Início">
  <div class="hero-grid-overlay" aria-hidden="true"></div>
  <div class="hero-glow" aria-hidden="true"></div>
  <div class="hero-inner">
    <div class="hero-copy">
      <div class="hero-logo-wrap">
        <picture>
          <source srcset="<?= $logo_webp ?>" type="image/webp">
          <img src="<?= $logo ?>" alt="VaideVan — Aluguel de Vans Executivas com Motorista" class="hero-logo" width="160" height="160" loading="eager" fetchpriority="high">
        </picture>
      </div>
      <div class="hero-badge"><span class="hero-badge-dot" aria-hidden="true"></span><span data-i18n="hero.badge">Marca Registrada · 20+ Anos no Mercado</span></div>
      <h1 class="hero-h1">
        <span class="line1" data-i18n="hero.line1">Aluguel de Vans Executivas</span>
        <span class="line2" data-i18n="hero.line2">com Motorista — VaideVan</span>
      </h1>
      <p class="hero-sub" data-i18n-html="hero.sub.html">Mercedes Sprinter em <strong>Faria Lima, Itaim Bibi, Jardins, Berrini</strong> e toda SP. <strong>12 estados</strong> &middot; <strong>49+ cidades</strong> &middot; fretamento B2B 24h.</p>
      <ul class="hero-bullets">
        <li><span class="hero-bullet-icon" aria-hidden="true">⚡</span> <span data-i18n="hero.bullet1">Resposta e orçamento em até 2 horas</span></li>
        <li><span class="hero-bullet-icon" aria-hidden="true">🛡</span> <span data-i18n="hero.bullet2">20+ anos de mercado · frota própria homologada</span></li>
        <li><span class="hero-bullet-icon" aria-hidden="true">📍</span> <span data-i18n="hero.bullet3">Presente em São Paulo e 12 estados do Brasil</span></li>
      </ul>
      <div class="hero-ctas">
        <a href="<?= $WA_NOW ?>" target="_blank" rel="noopener noreferrer" class="btn-wpp">
          <svg viewBox="0 0 24 24" width="16" height="16" aria-hidden="true"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" fill="currentColor"/></svg>
          <span data-i18n="hero.cta.wpp">Falar no WhatsApp agora</span>
        </a>
        <a href="#seja-investidor" class="btn-investor"><span data-i18n="hero.cta.investor">Seja Investidor</span> <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/><polyline points="17 6 23 6 23 12"/></svg></a>
      </div>
    </div>
    <div class="hero-form-wrap">
      <div class="hero-form-glow" aria-hidden="true"></div>
      <div class="hero-form-card">
        <div class="form-card-header">
          <div><p class="form-card-label" data-i18n="form.label">Orçamento Gratuito</p><h2 class="form-card-title" data-i18n="form.title">Solicite agora, sem compromisso</h2></div>
          <div class="form-badge-2h"><svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg><span data-i18n="form.badge">Resposta em 2h</span></div>
        </div>
        <div id="heroFormSuccess" class="form-success" style="display:none">
          <div class="form-success-icon" aria-hidden="true">✓</div>
          <h3 data-i18n="form.success.h3">Recebemos seu pedido!</h3>
          <p data-i18n="form.success.p">Nossa equipe entra em contato em até 2 horas com uma proposta personalizada.</p>
          <a href="<?= $WA_NOW ?>" target="_blank" rel="noopener noreferrer" class="btn-wpp" style="font-size:.875rem;margin-top:16px" data-i18n="form.success.cta">Confirmar pelo WhatsApp</a>
        </div>
        <form id="heroForm" novalidate>
          <?php wp_nonce_field('vdv_orcamento','vdv_nonce'); ?>
          <p class="chips-label" data-i18n="form.chips.label">Selecione o serviço</p>
          <div class="chips-grid" id="chipsGrid">
            <button type="button" class="chip active" data-val="Transfer aeroporto">✈ Aeroporto</button>
            <button type="button" class="chip" data-val="Fretamento corporativo">💼 Corporativo</button>
            <button type="button" class="chip" data-val="Van para eventos">📅 Eventos</button>
            <button type="button" class="chip" data-val="Excursão">🚐 Excursão</button>
          </div>
          <input type="hidden" id="heroService" name="service" value="Transfer aeroporto">
          <script>
          (function(){
            var g=document.getElementById('chipsGrid');
            if(!g)return;
            g.addEventListener('click',function(e){
              var btn=e.target.closest('.chip');
              if(!btn)return;
              e.preventDefault();
              g.querySelectorAll('.chip').forEach(function(c){c.classList.remove('active');});
              btn.classList.add('active');
              var h=document.getElementById('heroService');
              if(h)h.value=btn.getAttribute('data-val')||btn.textContent.trim();
            });
          })();
          </script>
          <div class="form-fields">
            <div class="form-row">
              <div><label class="field-label" for="heroNome" data-i18n="form.name">Nome *</label><input class="field-input" type="text" id="heroNome" name="nome" required placeholder="João Silva" autocomplete="name"></div>
              <div><label class="field-label" for="heroTel" data-i18n="form.wpp">WhatsApp *</label><input class="field-input" type="tel" id="heroTel" name="telefone" required placeholder="(11) 99999-0000" autocomplete="tel"></div>
            </div>
            <div><label class="field-label" for="heroMsg" data-i18n="form.need">Sua necessidade *</label><textarea class="field-textarea" id="heroMsg" name="mensagem" required rows="3" placeholder="Rota, data, nº de passageiros, empresa..."></textarea></div>
          </div>
          <button type="submit" class="btn-submit"><svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg><span data-i18n="form.submit">Solicitar Orçamento Grátis</span></button>
          <p class="form-disclaimer" data-i18n="form.disclaimer">Sem compromisso · Resposta em até 2h · 20+ anos de mercado</p>
        </form>
      </div>
    </div>
  </div>
  <div class="scroll-indicator" aria-hidden="true">▼</div>
</section>

<!-- STATS -->
<section id="stats-bar" aria-label="Números VaideVan">
  <div class="container">
    <div class="stats-grid">
      <div class="stat-item"><span class="stat-value" data-target="20" data-suffix="+ Anos">20+ Anos</span><span class="stat-label" data-i18n="stats.years.label">de mercado</span></div>
      <div class="stat-item"><span class="stat-value" data-target="12" data-suffix=" Estados">12 Estados</span><span class="stat-label" data-i18n="stats.states.label">de atuação</span></div>
      <div class="stat-item"><span class="stat-value" data-target="49" data-suffix="+ Cidades">49+ Cidades</span><span class="stat-label" data-i18n="stats.cities.label">atendidas</span></div>
      <div class="stat-item"><span class="stat-value" data-target="100" data-suffix="%">100%</span><span class="stat-label" data-i18n="stats.satisfaction.label">de satisfação</span></div>
    </div>
  </div>
</section>

<!-- PARCEIROS -->
<section id="partners" aria-label="Parceiros e Clientes">
  <p class="partners-label" data-i18n="partners.label">Confiado por líderes do mercado brasileiro</p>
  <div class="marquee-outer">
    <div class="marquee-fade-l" aria-hidden="true"></div>
    <div class="marquee-fade-r" aria-hidden="true"></div>
    <div class="marquee-track" aria-hidden="true">
      <?php $r1=[['Petrobras','#009B3A'],['Embraer','#003087'],['Itaú','#EC7000'],['Bradesco','#CC092F'],['Vale','#005CA9'],['Ambev','#FFCC00'],['Globo','#E3032E'],['Vivo','#6D2C8A'],['BTG Pactual','#00A09B'],['WEG','#005B8E'],['Natura','#A3883A'],['Localiza','#00A651']];$r1=array_merge($r1,$r1);foreach($r1 as[$n,$c]):?><div class="brand-chip" style="border:1px solid <?=$c?>22;background:<?=$c?>0D;color:<?=$c?>;opacity:.75"><?=esc_html($n)?></div><?php endforeach;?>
    </div>
    <div class="marquee-track-r" aria-hidden="true">
      <?php $r2=[['Santander','#EC0000'],['XP Investimentos','#FF8C00'],['JBS','#E8342A'],['Magazine Luiza','#0086FF'],['Totvs','#F7901E'],['Claro','#DA291C'],['Banco do Brasil','#F9E200'],['Renner','#E4002B'],['Tim Brasil','#00338D'],['Hypera','#00205B'],['Hapvida','#004A8F'],['Suzano','#006633']];$r2=array_merge($r2,$r2);foreach($r2 as[$n,$c]):?><div class="brand-chip" style="border:1px solid <?=$c?>22;background:<?=$c?>0D;color:<?=$c?>;opacity:.75"><?=esc_html($n)?></div><?php endforeach;?>
    </div>
  </div>
</section>

<!-- HISTÓRIA -->
<section id="nossa-historia" aria-label="Nossa História VaideVan">
  <div class="container">
    <div class="history-grid">
      <div class="vv-reveal-left">
        <span class="section-tag" data-i18n="history.tag">Nossa História</span>
        <h2 class="section-h2" data-i18n-html="history.h2.html">VaideVan: Referência em<br><span class="accent">Aluguel de Vans Executivas</span><br>há mais de 20 anos</h2>
        <p class="section-body" data-i18n="history.p1">A VaideVan nasceu da necessidade de um aluguel de van executiva de alta qualidade, acessível e confiável. Com marca registrada e DNA de inovação, construímos a maior operação de locação de vans executivas do país.</p>
        <p class="section-body" data-i18n="history.p2">Hoje, somos referência nacional no setor de locação de veículos executivos, atendendo empresas, eventos corporativos, aeroportos e excursões — sempre com frotas modernas e motoristas treinados.</p>
        <ul class="check-list">
          <li>Marca registrada no INPI</li>
          <li>Frotas Mercedes-Benz Sprinter exclusivas</li>
          <li>Motoristas certificados e uniformizados</li>
          <li>Tecnologia de rastreamento em tempo real</li>
          <li>Seguros e coberturas completas</li>
        </ul>
      </div>
      <div class="vv-reveal-right" style="position:relative">
        <div class="img-card">
          <img src="<?= $tdir ?>/assets/images/hero-vans.jpg"
               alt="VaideVan — Frota de vans Mercedes Sprinter executivas na Av. Paulista, São Paulo"
               width="1400" height="764" loading="lazy" decoding="async">
          <div class="img-card-badge">
            <p style="color:var(--primary);font-weight:900;font-size:1.1rem;margin:0">vaidevan.com</p>
            <p style="color:rgba(255,255,255,.7);font-size:.8rem;margin:4px 0 0">A marca que move executivos por todo o Brasil</p>
          </div>
        </div>
        <div class="award-float">
          <span style="font-size:1.5rem" aria-hidden="true">🏆</span>
          <p>Marca</p>
          <p>Registrada</p>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- SEJA INVESTIDOR -->
<section id="seja-investidor" aria-label="Oportunidade de investimento VaideVan" style="position:relative;overflow:hidden;background:var(--card);padding:72px 0">
  <div style="position:absolute;inset:0;background:radial-gradient(ellipse 50% 60% at 80% 50%,rgba(245,230,66,.06),transparent);pointer-events:none" aria-hidden="true"></div>
  <div class="container" style="position:relative;z-index:1">
    <div style="text-align:center;margin-bottom:64px">
      <span class="section-tag" data-i18n="investor.tag">Oportunidade de Negócio</span>
      <h2 class="section-h2" data-i18n-html="investor.h2.html">Invista na VaideVan —<br><span class="accent">Líder em Locação de Vans Executivas</span></h2>
      <p class="section-body" style="max-width:780px;margin:0 auto" data-i18n="investor.p">O mercado de aluguel de vans executivas cresce acelerado no Brasil. A VaideVan oferece um modelo de locação comprovado, com retorno sólido e suporte completo para parceiros investidores.</p>
    </div>
    <div class="inv-cards">
      <?php
      $cards=[
        ['+18% ao ano','📈','Setor de Locação de Vans em Expansão','O mercado de aluguel de vans executivas cresce 18% ao ano no Brasil. A VaideVan está na vanguarda com operações consolidadas em 12 estados.'],
        ['20 anos de lucro','🏢','Modelo de Locação Comprovado','20 anos de locação de vans executivas lucrativas, processos documentados e equipe experiente. Você entra em um negócio já validado pelo mercado.'],
        ['100% gerenciado','👥','Suporte Completo ao Investidor','Da captação ao operacional da frota, nossa equipe cuida de tudo. Você investe na locação e nós gerenciamos com total transparência.'],
      ];
      foreach($cards as$i=>[$hl,$icon,$t,$d]):?>
      <article class="inv-card vv-reveal-up" style="transition-delay:<?=$i*.15?>s">
        <div class="inv-card-icon" aria-hidden="true"><?=$icon?></div>
        <div class="inv-highlight"><?=esc_html($hl)?></div>
        <h3><?=esc_html($t)?></h3>
        <p><?=esc_html($d)?></p>
      </article>
      <?php endforeach;?>
    </div>
    <div class="inv-cta-box vv-reveal-up">
      <h3 data-i18n-html="investor.cta.h3.html">Pronto para investir em aluguel de vans com a <span style="color:var(--primary)">VaideVan</span>?</h3>
      <p data-i18n="investor.cta.p">Entre em contato com nosso time e descubra as oportunidades de aluguel de vans executivas disponíveis em sua cidade.</p>
      <div class="inv-cta-btns">
        <a href="<?=$WA_INV?>" target="_blank" rel="noopener noreferrer" class="btn-primary-lg" data-testid="investor-cta-button" data-i18n="investor.cta.btn">Quero Ser Investidor →</a>
        <button class="btn-outline-lg-partner" onclick="document.getElementById('partnerModal').classList.add('open')" type="button">
          <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><line x1="19" y1="8" x2="19" y2="14"/><line x1="22" y1="11" x2="16" y2="11"/></svg>
          <span data-i18n="investor.cta.partner">Seja Nosso Parceiro</span>
        </button>
      </div>
      <p class="inv-cta-note" data-i18n="investor.cta.note">Investidor · Cliente Corporativo · Revendedor · Motorista Parceiro</p>
    </div>
  </div>
</section>

<!-- SERVIÇOS -->
<section id="servicos" aria-label="Serviços VaideVan">
  <div class="container">
    <div class="services-header">
      <span class="section-tag" data-i18n="services.tag">O que oferecemos</span>
      <h2 class="section-h2" data-i18n-html="services.h2.html">Aluguel de Van Executiva:<br><span class="accent">Nossos Serviços</span></h2>
      <p data-i18n="services.p">Soluções completas de locação de vans executivas para cada necessidade — com a qualidade e pontualidade da VaideVan.</p>
    </div>
    <div class="services-grid">
      <?php
      $svcs=[
        ['✈','Aluguel de Van para Aeroporto','Transfer executivo para Guarulhos (GRU), Congonhas (CGH) e Viracopos (VCP). Busca nos hotéis e bairros corporativos de SP.'],
        ['💼','Locação de Van Corporativa B2B','Van com motorista para reuniões, transfer de executivos e equipes. Atendemos Faria Lima, Itaim Bibi, Berrini, Vila Olímpia e Brooklin.'],
        ['📅','Aluguel de Van para Eventos','Locação de van para casamentos, shows, feiras, convenções e eventos corporativos em SP. Morumbi, Jardins, Anhembi e mais.'],
        ['🚐','Fretamento de Van Executiva','Mercedes Sprinter à disposição para fretamentos mensais, diários e avulsos. Contrato com nota fiscal para empresas.'],
        ['📍','Van para Excursões em Grupo','Aluguel de van para passeios, turismo e viagens de lazer em grupo saindo de São Paulo e interior.'],
        ['🗺','Van para Viagens Interestaduais','Locação de van com motorista para o interior de SP, Campinas, Ribeirão Preto, Rio de Janeiro, Curitiba e todo o Brasil.'],
      ];
      foreach($svcs as$i=>[$icon,$title,$desc]):?>
      <article class="service-card vv-reveal-up" style="transition-delay:<?=$i*.08?>s">
        <div class="service-icon" aria-hidden="true"><?=$icon?></div>
        <h3><?=esc_html($title)?></h3>
        <p><?=esc_html($desc)?></p>
      </article>
      <?php endforeach;?>
    </div>
  </div>
</section>

<!-- B2B LOGÍSTICA -->
<section id="b2b-logistica" aria-label="Soluções B2B para redução de custos logísticos">
  <div class="b2b-log-glow" aria-hidden="true"></div>
  <div class="container" style="position:relative;z-index:1">
    <div class="b2b-log-inner">
      <div class="b2b-log-left">
        <div class="b2b-log-tag">
          <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true"><rect x="1" y="3" width="15" height="13" rx="2"/><path d="M16 8h4l3 4v4h-7V8z"/><circle cx="5.5" cy="18.5" r="2.5"/><circle cx="18.5" cy="18.5" r="2.5"/></svg>
          <span data-i18n="b2b.tag">B2B &amp; Logística Corporativa</span>
        </div>
        <h2 class="b2b-log-h2" data-i18n-html="b2b.h2.html">Reduza os Custos da<br><span class="accent">Sua Logística</span> com a VaideVan</h2>
        <p class="b2b-log-sub" data-i18n-html="b2b.sub.html">Empresas que migram o transporte executivo para contratos VaideVan reduzem em até <strong style="color:var(--primary)">35%</strong> os custos com frotas próprias, manutenção, seguro e motoristas CLT.</p>
        <div class="b2b-log-metrics">
          <div class="b2b-metric">
            <span class="b2b-metric-val" data-i18n="b2b.metric1.val">−35%</span>
            <span class="b2b-metric-label" data-i18n="b2b.metric1.label">em custos de frota</span>
          </div>
          <div class="b2b-metric">
            <span class="b2b-metric-val" data-i18n="b2b.metric2.val">Zero</span>
            <span class="b2b-metric-label" data-i18n="b2b.metric2.label">encargos trabalhistas</span>
          </div>
          <div class="b2b-metric">
            <span class="b2b-metric-val" data-i18n="b2b.metric3.val">100%</span>
            <span class="b2b-metric-label" data-i18n="b2b.metric3.label">dedutível como despesa</span>
          </div>
        </div>
      </div>
      <div class="b2b-log-right">
        <div class="b2b-log-card">
          <p class="b2b-log-card-title" data-i18n="b2b.card.title">💡 O que sua empresa elimina ao contratar a VaideVan:</p>
          <ul class="b2b-log-list">
            <li><span class="b2b-check" aria-hidden="true">✓</span>Custo de aquisição e depreciação do veículo</li>
            <li><span class="b2b-check" aria-hidden="true">✓</span>IPVA, seguro obrigatório e seguro total</li>
            <li><span class="b2b-check" aria-hidden="true">✓</span>Manutenção preventiva e corretiva</li>
            <li><span class="b2b-check" aria-hidden="true">✓</span>Salário, 13°, FGTS e encargos do motorista</li>
            <li><span class="b2b-check" aria-hidden="true">✓</span>Gestão de multas e documentação</li>
            <li><span class="b2b-check" aria-hidden="true">✓</span>Imobilização de capital em frota parada</li>
          </ul>
          <div class="b2b-log-cta">
            <a href="<?= $WA_NOW ?>" target="_blank" rel="noopener noreferrer" class="btn-b2b-cta">
              <svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" fill="currentColor"/></svg>
              <span data-i18n="b2b.cta">Fale com nossos consultores agora!</span>
            </a>
            <p class="b2b-log-note" data-i18n="b2b.note">Análise gratuita da logística da sua empresa · Sem compromisso · Resposta em 2h</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- FROTA -->
<section id="frota" aria-label="Frota Executiva VaideVan">
  <div class="radial-glow" style="background:radial-gradient(ellipse 70% 50% at 20% 50%,rgba(245,230,66,.04),transparent)" aria-hidden="true"></div>
  <div class="container" style="position:relative;z-index:10">
    <div class="fleet-header">
      <span class="section-tag" data-i18n="fleet.tag">Frota Executiva</span>
      <h2 class="section-h2" data-i18n-html="fleet.h2.html">Todos os Modelos e Marcas<br><span class="accent">para Locação Corporativa</span></h2>
      <p data-i18n="fleet.p">A VaideVan opera com as principais marcas do mercado. Locação e comercialização de veículos executivos — da van compacta ao ônibus, incluindo blindados e veículos de passeio.</p>
    </div>
    <div class="fleet-grid">
      <?php
      $fleet=[
        ['Mercedes-Benz','Sprinter','até 15 passageiros','Van Executiva Premium','Mais alugada','#00A19A',['Ar-condicionado','Rastreamento GPS','Motorista uniformizado','Wi-Fi a bordo']],
        ['Mercedes-Benz','Vito / V-Class','até 8 passageiros','Minivan Executiva','Transfer VIP','#00A19A',['Bancos em couro','Ar-condicionado','Rastreamento GPS','Transfer aeroporto']],
        ['BMW / Mercedes','Veículo de Passeio','1 a 4 passageiros','Sedã Executivo','Passeio Executivo','#1C69D4',['BMW 320i / Classe C / Corolla','Transfer discreto','Motorista dedicado','Venda e locação']],
        ['Mercedes / BMW','Blindado','1 a 5 passageiros','Transfer Blindado VIP','Segurança Máxima','#C8A84B',['Nível IIIA / III-A','C300 / E300 / BMW 5 Séries','Motorista especializado','Venda e locação']],
        ['Mercedes / Volare','Microônibus','até 28 passageiros','Microônibus Executivo','Grupos Médios','#E2001A',['Sprinter 515 / Volare W9','Ar-condicionado','Longa distância','Fretamento grupos']],
        ['Marcopolo / Busscar','Ônibus Executivo','até 50 passageiros','Ônibus de Fretamento','Grandes Grupos','#F7901E',['Poltronas reclináveis','Ar-condicionado','WC a bordo','Fretamento e excursões']],
      ];
      foreach($fleet as$i=>[$brand,$model,$cap,$type,$tag,$clr,$feats]):?>
      <article class="fleet-card vv-reveal-up" style="transition-delay:<?=$i*.10?>s">
        <div class="fleet-tag" style="background:<?=$clr?>22;color:<?=$clr?>"><?=esc_html($tag)?></div>
        <p class="fleet-brand"><?=esc_html($brand)?></p>
        <h3 class="fleet-model" style="color:<?=$clr?>"><?=esc_html($model)?></h3>
        <p class="fleet-type"><?=esc_html($type)?></p>
        <div class="fleet-cap">👥 <?=esc_html($cap)?></div>
        <ul class="fleet-features"><?php foreach($feats as$f):?><li><?=esc_html($f)?></li><?php endforeach;?></ul>
      </article>
      <?php endforeach;?>
    </div>
    <div class="b2b-box">
      <div class="b2b-grid">
        <div>
          <span class="section-tag">Soluções B2B</span>
          <h3 class="section-h2" style="font-size:clamp(1.75rem,3vw,2.25rem)">Locação de Frotas Executivas para<br><span class="accent">Empresas e Contratos Corporativos</span></h3>
          <p class="section-body">A VaideVan é a parceira ideal para empresas que precisam de transporte executivo recorrente. Oferecemos contratos B2B com faturamento, NF, SLA e gestor de frota dedicado.</p>
          <ul class="b2b-check-list">
            <li>Contratos mensais e anuais com nota fiscal</li>
            <li>Frota dedicada com motorista fixo por empresa</li>
            <li>Relatórios de uso e gestão de frotas</li>
            <li>SLA garantido com suporte prioritário 24h</li>
            <li>Desconto progressivo por volume de viagens</li>
            <li>Integração com sistema de gestão corporativo</li>
          </ul>
          <button class="btn-primary-lg" onclick="document.getElementById('quoteModal').classList.add('open')" style="height:48px;font-size:1rem;padding:0 32px;margin-top:8px">💼 Solicitar Proposta B2B</button>
        </div>
        <div>
          <p style="font-size:.7rem;font-weight:700;text-transform:uppercase;letter-spacing:.15em;color:rgba(255,255,255,.4);margin-bottom:20px">Segmentos atendidos</p>
          <div class="b2b-segments">
            <?php
            $segs=['🏢 Multinacionais e grandes empresas','💼 Escritórios e consultorias','✈ Agências de turismo e receptivos','📅 Produtoras de eventos','🏥 Hospitais e clínicas','🏗 Construtoras e incorporadoras','⭐ Redes hoteleiras','🎓 Universidades e colégios'];
            foreach($segs as$s):?><div class="b2b-segment"><?=esc_html($s)?></div><?php endforeach;?>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- DIFERENCIAIS -->
<section id="diferenciais" aria-label="Por que escolher a VaideVan" style="padding:72px 0;background:var(--primary)">
  <div class="container">
    <h2 class="sr-only">Por que a VaideVan é a Melhor Opção de Aluguel de Van Executiva</h2>
    <div class="diferenciais-grid">
      <div class="dif-card vv-reveal-up">
        <span class="dif-icon" aria-hidden="true">🛡</span>
        <h3>Aluguel 100% Seguro</h3>
        <p>Motoristas certificados e veículos rastreados em tempo real</p>
      </div>
      <div class="dif-card vv-reveal-up" style="transition-delay:.10s">
        <span class="dif-icon" aria-hidden="true">⏱</span>
        <h3>Pontualidade Garantida</h3>
        <p>Locação disponível 24h, 7 dias por semana</p>
      </div>
      <div class="dif-card vv-reveal-up" style="transition-delay:.20s">
        <span class="dif-icon" aria-hidden="true">⭐</span>
        <h3>Avaliação 5.0 no Google</h3>
        <p>Aprovado por milhares de clientes em todo o Brasil</p>
      </div>
      <div class="dif-card vv-reveal-up" style="transition-delay:.30s">
        <span class="dif-icon" aria-hidden="true">🏆</span>
        <h3>Marca Registrada no INPI</h3>
        <p>Autoridade e credibilidade em locação de vans</p>
      </div>
    </div>
  </div>
</section>

<!-- ATUAÇÃO NACIONAL -->
<section id="atuacao-nacional" aria-label="Locação de vans em todo o Brasil" style="padding:72px 0;background:var(--card)">
  <div class="container">
    <div style="text-align:center;margin-bottom:56px">
      <span class="section-tag" data-i18n="national.tag">Presença Nacional</span>
      <h2 class="section-h2" data-i18n-html="national.h2.html">Locação de Vans Executivas:<br><span class="accent">De SP para Todo o Brasil</span></h2>
      <p class="section-body" style="max-width:580px;margin:0 auto" data-i18n="national.p">Aluguel de van executiva com motorista em 12 estados brasileiros e mais de 49 cidades — sempre com o mesmo padrão VaideVan.</p>
    </div>
    <div class="states-grid">
      <?php
      $estados=['São Paulo','Rio de Janeiro','Minas Gerais','Paraná','Santa Catarina','Rio Grande do Sul','Bahia','Goiás','Mato Grosso','Mato Grosso do Sul','Espírito Santo','Ceará'];
      foreach($estados as$i=>$e):?>
      <div class="state-card vv-reveal-scale" style="transition-delay:<?=$i*.05?>s">
        <span style="color:var(--primary)" aria-hidden="true">📍</span>
        <span style="font-weight:700;font-size:.875rem"><?=esc_html($e)?></span>
      </div>
      <?php endforeach;?>
    </div>
  </div>
</section>

<!-- BAIRROS NOBRES SP -->
<section id="bairros" aria-label="Van executiva nos bairros nobres de São Paulo" style="padding:72px 0">
  <div class="container">
    <div style="text-align:center;margin-bottom:56px">
      <span class="section-tag">Cobertura Premium em SP</span>
      <h2 class="section-h2">Van Executiva nos <span class="accent">Bairros Nobres de São Paulo</span><br>Atendimento 24h</h2>
      <p class="section-body" style="max-width:760px;margin:0 auto">Do centro financeiro da Faria Lima ao alto padrão dos Jardins — van executiva Mercedes Sprinter com motorista onde sua empresa precisa. Transfer discreto, pontual e com nota fiscal.</p>
    </div>
    <div class="bairros-grid">
      <?php
      $bairros=[
        ['Faria Lima','Centro financeiro'],['Itaim Bibi','Hub executivo'],
        ['Berrini','Sedes corporativas'],['Vila Olímpia','Tech & criativo'],
        ['Jardins','Distrito de luxo'],['Pinheiros','Agências & startups'],
        ['Brooklin','Multinacionais'],['Moema','Residencial premium'],
        ['Higienópolis','Alto padrão'],['Morumbi','Eventos & condomínios'],
        ['Paulista','Bancos & seguros'],['Alphaville','Complexos empresariais'],
        ['Perdizes','Residencial nobre'],['Granja Viana','Condomínios fechados'],
        ['Santo André / ABC','Polo industrial'],['Tatuapé','Zona Leste corporativa'],
      ];
      foreach($bairros as$i=>[$b,$t]):?>
      <div class="bairro-card vv-reveal-up" style="transition-delay:<?=$i*.04?>s">
        <p class="bairro-name"><?=esc_html($b)?></p>
        <p class="bairro-tipo"><?=esc_html($t)?></p>
      </div>
      <?php endforeach;?>
    </div>
    <div class="b2b-callout-box" style="margin-top:48px">
      <div style="flex:1;min-width:0">
        <h3>Contrato Corporativo de Van Executiva para Empresas em SP</h3>
        <p>Fretamento mensal ou avulso com <strong>nota fiscal</strong>, SLA de pontualidade, motorista dedicado e rastreamento em tempo real.</p>
        <ul class="b2b-callout-checks" style="margin-top:16px">
          <li>Contrato mensal com NF — sem burocracia</li>
          <li>Gestor de conta dedicado para sua empresa</li>
          <li>Van Mercedes Sprinter — conforto executivo premium</li>
          <li>Rastreamento e relatórios para o RH</li>
        </ul>
      </div>
      <div style="flex-shrink:0;text-align:center">
        <button class="btn-primary-lg" onclick="document.getElementById('quoteModal').classList.add('open')" style="white-space:nowrap">Solicitar Proposta Comercial B2B →</button>
        <p style="color:rgba(255,255,255,.3);font-size:.75rem;margin-top:12px">Resposta em até 2h — sem compromisso</p>
      </div>
    </div>
  </div>
</section>

<!-- BLOG PREVIEW -->
<?php
$blog_posts = new WP_Query(['post_type'=>'post','post_status'=>'publish','posts_per_page'=>3,'orderby'=>'date','order'=>'DESC']);
if ($blog_posts->have_posts()):
?>
<section id="blog-preview" aria-label="Blog VaideVan — Dicas de Transporte Executivo" style="background:var(--d);padding:64px 0">
  <div class="container">
    <div class="section-header vv-reveal-up" style="text-align:center;margin-bottom:48px">
      <span class="section-tag">Blog</span>
      <h2 class="section-h2">Dicas e Guias de<br><span class="accent">Transporte Executivo</span></h2>
      <p class="section-body" style="max-width:540px;margin:0 auto">Artigos exclusivos sobre van executiva, fretamento B2B e transfer corporativo em São Paulo e Brasil.</p>
    </div>
    <div class="posts-grid vv-reveal-up">
      <?php while ($blog_posts->have_posts()): $blog_posts->the_post();
        $thumb = get_the_post_thumbnail_url(null,'vdv-card')
               ?: get_post_meta(get_the_ID(), '_soro_post_image', true)
               ?: 'https://images.unsplash.com/photo-1449965408869-eaa3f722e40d?w=560&h=320&fit=crop&q=80';
        $cat   = get_the_category(); $cname = $cat ? esc_html($cat[0]->name) : 'Blog';
        $words = str_word_count(strip_tags(get_the_content())); $mins = max(1,(int)round($words/200));
      ?>
      <div class="post-card">
        <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>">
          <div class="post-thumb">
            <img src="<?=esc_url($thumb)?>" alt="<?php the_title_attribute(); ?>" width="560" height="320" loading="lazy" decoding="async">
            <div class="post-thumb-overlay"></div>
            <span class="post-cat-sm"><?=$cname?></span>
          </div>
          <div class="post-body">
            <h3><?php the_title(); ?></h3>
            <p class="excerpt-sm"><?php echo wp_trim_words(get_the_excerpt(),18,'...'); ?></p>
            <div class="post-card-meta">
              <span><?php echo get_the_date('d M Y'); ?></span>
              <span style="color:var(--primary)"><?=$mins?> min · Ler →</span>
            </div>
          </div>
        </a>
      </div>
      <?php endwhile; wp_reset_postdata(); ?>
    </div>
    <div style="text-align:center;margin-top:36px">
      <a href="<?=esc_url(home_url('/blog/'))?>" class="btn-outline-lg">Ver todos os artigos →</a>
    </div>
  </div>
</section>
<?php endif; ?>

<!-- FAQ -->
<section id="faq" aria-label="Perguntas Frequentes sobre van executiva">
  <div class="container">
    <div class="faq-header">
      <span class="section-tag" data-i18n="faq.tag">Dúvidas</span>
      <h2 class="section-h2" data-i18n-html="faq.h2.html">Perguntas Frequentes sobre<br><span class="accent">Aluguel de Van Executiva</span></h2>
      <p>Tire suas dúvidas sobre locação de vans executivas VaideVan — transfer, fretamento corporativo e bairros nobres de SP.</p>
    </div>
    <div class="faq-list" role="list">
      <?php
      $faqs=[
        ['A VaideVan oferece contrato mensal de van executiva para empresas em SP?','Sim. A VaideVan oferece contrato mensal de fretamento corporativo com emissão de nota fiscal, SLA de pontualidade e motorista dedicado. Atendemos empresas nos principais bairros corporativos de São Paulo: Faria Lima, Itaim Bibi, Berrini, Vila Olímpia, Brooklin, Paulista e Alphaville.'],
        ['A VaideVan faz transfer executivo no Itaim Bibi, Jardins e Faria Lima?','Sim. Atendemos todos os bairros nobres e corporativos de São Paulo 24 horas por dia, 7 dias por semana: Faria Lima, Itaim Bibi, Berrini, Jardins, Higienópolis, Moema, Morumbi, Pinheiros, Vila Olímpia, Brooklin, Perdizes, Alphaville e mais.'],
        ['Como funciona o transfer de van para aeroporto GRU, CGH e VCP?','A VaideVan faz busca no seu endereço em São Paulo — hotel, escritório ou residência nos bairros nobres — e leva diretamente aos aeroportos Guarulhos (GRU), Congonhas (CGH) e Viracopos (VCP). Monitoramos o voo em tempo real.'],
        ['Em quais estados a VaideVan oferece aluguel de van executiva?','A VaideVan oferece locação de vans executivas em 12 estados brasileiros: São Paulo, Rio de Janeiro, Minas Gerais, Paraná, Santa Catarina, Rio Grande do Sul, Bahia, Goiás, Mato Grosso, Mato Grosso do Sul, Espírito Santo e Ceará — em mais de 49 cidades.'],
        ['Quais serviços de locação de van executiva a VaideVan oferece?','Oferecemos: aluguel de van para aeroporto, fretamento corporativo B2B com contrato mensal, locação de van para eventos corporativos e sociais, van para excursões em grupo e locação de van para viagens interestaduais — sempre com Mercedes-Benz Sprinter.'],
        ['Como solicitar orçamento para aluguel de van com motorista em SP?','Solicite seu orçamento de locação de van executiva pelo WhatsApp: +55 11 99929-4694. Atendimento 24 horas por dia, 7 dias por semana. Retorno em menos de 1 hora.'],
        ['A VaideVan possui qual modelo de van para locação?','A VaideVan opera com frota exclusiva de Mercedes-Benz Sprinter — a van executiva premium do mercado, com ar-condicionado, conforto para até 15 passageiros e rastreamento em tempo real. Marca registrada no INPI com 20+ anos de operação.'],
      ];
      foreach($faqs as$i=>[$q,$a]):?>
      <div class="faq-item" role="listitem">
        <button class="faq-q" aria-expanded="false" aria-controls="faq-a-<?=$i?>"><span><?=esc_html($q)?></span><span class="faq-chevron" aria-hidden="true">▼</span></button>
        <div class="faq-a" id="faq-a-<?=$i?>" role="region"><?=esc_html($a)?></div>
      </div>
      <?php endforeach;?>
    </div>
  </div>
</section>

<!-- CTA FINAL -->
<section id="cta-final" aria-label="Reserve sua van executiva">
  <div class="radial-glow" style="background:radial-gradient(ellipse 70% 60% at 50% 50%,rgba(245,230,66,.08),transparent)" aria-hidden="true"></div>
  <div class="container">
    <div class="cta-final-inner vv-reveal-up">
      <h2 data-i18n-html="cta.h2.html">Reserve sua Van Executiva<br><span style="color:var(--primary)">com a VaideVan Agora</span></h2>
      <p data-i18n="cta.p">Aluguel de van com motorista em São Paulo e todo o Brasil. O serviço de locação mais seguro, confortável e pontual do mercado.</p>
      <div class="cta-btns">
        <a href="<?=$WA?>" target="_blank" rel="noopener noreferrer" class="btn-primary-lg" data-testid="final-cta-button" data-i18n="cta.wpp">Falar no WhatsApp →</a>
        <a href="#seja-investidor" class="btn-outline-lg" data-i18n="cta.investor">Seja Investidor</a>
      </div>
    </div>
  </div>
</section>

<!-- CONTATO -->
<section id="contato" aria-label="Contato VaideVan">
  <div class="container">
    <div class="contact-grid">
      <div class="contact-info">
        <span class="section-tag" data-i18n="contact.tag">Fale Conosco</span>
        <h2 class="section-h2" data-i18n-html="contact.h2.html">Solicite um<br><span class="accent">orçamento gratuito</span></h2>
        <p data-i18n="contact.p">Preencha o formulário e nossa equipe retorna em até 2 horas com uma proposta personalizada para a sua necessidade.</p>
        <div class="contact-points">
          <div class="contact-point"><div class="contact-point-dot" aria-hidden="true"></div><div class="contact-point-text"><strong>Resposta garantida</strong><span>Em até 2 horas em dias úteis</span></div></div>
          <div class="contact-point"><div class="contact-point-dot" aria-hidden="true"></div><div class="contact-point-text"><strong>Orçamento sem compromisso</strong><span>Proposta detalhada e transparente</span></div></div>
          <div class="contact-point"><div class="contact-point-dot" aria-hidden="true"></div><div class="contact-point-text"><strong>Atendimento 24h</strong><span>WhatsApp +55 11 99929-4694</span></div></div>
        </div>
      </div>
      <div class="contact-form-card">
        <form class="contact-form" id="contactForm" novalidate>
          <?php wp_nonce_field('vdv_contato','vdv_nonce'); ?>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px">
            <div><label for="cNome">Nome *</label><input type="text" id="cNome" name="nome" required placeholder="João Silva" autocomplete="name"></div>
            <div><label for="cEmail">Email *</label><input type="email" id="cEmail" name="email" required placeholder="joao@empresa.com" autocomplete="email"></div>
          </div>
          <div><label for="cTel">WhatsApp / Telefone</label><input type="tel" id="cTel" name="telefone" placeholder="(11) 99999-0000" autocomplete="tel"></div>
          <div><label for="cTipo">Tipo de Serviço</label>
            <select id="cTipo" name="tipo"><option value="">Selecione o serviço...</option><option>Transfer aeroporto</option><option>Fretamento corporativo</option><option>Van para eventos</option><option>Excursão / passeio</option><option>Contrato mensal B2B</option></select>
          </div>
          <div><label for="cMsg">Mensagem *</label><textarea id="cMsg" name="mensagem" rows="4" required placeholder="Descreva sua necessidade: rota, data, número de passageiros, empresa..."></textarea></div>
          <button type="submit" class="btn-submit" style="border-radius:12px">Enviar Mensagem</button>
          <div id="contactMsg" style="display:none;margin-top:12px;padding:12px;border-radius:8px;font-size:.875rem;text-align:center"></div>
        </form>
      </div>
    </div>
  </div>
</section>

<!-- COMO CHEGAR -->
<section id="como-chegar" aria-label="Localização VaideVan São Paulo" style="padding:80px 0 0">
  <div class="container">
    <div class="como-chegar-header vv-reveal-up">
      <span class="section-tag">Onde Estamos</span>
      <h2 class="section-h2">Nossa <span class="accent">Localização</span></h2>
      <p style="color:rgba(255,255,255,.6);max-width:560px;margin:0 auto">
        Atendemos em todo o Brasil com base em <strong style="color:#fff">São Paulo – SP</strong>.<br>
        Transfer aeroporto, fretamento corporativo e locação de van com motorista.
      </p>
    </div>
  </div>
  <div class="map-wrapper vv-reveal-up" style="transition-delay:.15s">
    <div class="map-address-bar">
      <span class="map-pin-icon" aria-hidden="true">📍</span>
      <span>VaideVan — Aluguel de Vans Executivas &amp; Transfer · São Paulo, SP</span>
      <a href="https://maps.app.goo.gl/G3obfUeaZVhca95r9" target="_blank" rel="noopener noreferrer" class="map-open-link">
        Abrir no Maps ↗
      </a>
    </div>
    <div class="map-frame-wrapper">
      <iframe
        src="https://maps.google.com/maps?q=-23.5879386,-46.6784789&z=15&output=embed"
        width="100%"
        height="420"
        style="border:0;display:block"
        allowfullscreen=""
        loading="lazy"
        referrerpolicy="no-referrer-when-downgrade"
        title="VaideVan — Localização no Google Maps"
        aria-label="Mapa de localização da VaideVan em São Paulo">
      </iframe>
    </div>
  </div>
</section>

<?php get_footer(); ?>

