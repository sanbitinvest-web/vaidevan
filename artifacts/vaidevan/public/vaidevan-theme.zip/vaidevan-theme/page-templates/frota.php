<?php
/**
 * Template Name: Frota
 */
get_header();
?>
<section class="page-hero">
    <div class="container">
        <nav aria-label="Breadcrumb">
            <ol style="display:flex;gap:8px;font-size:.78rem;color:rgba(255,255,255,.38);justify-content:center;margin-bottom:18px;list-style:none">
                <li><a href="<?= esc_url(home_url('/')) ?>" style="color:var(--y)">Inicio</a></li>
                <li aria-hidden>/</li><li aria-current="page">Frota</li>
            </ol>
        </nav>
        <h1>Frota de Vans Executivas Mercedes-Benz Sprinter</h1>
        <p>Veiculos novos, higienizados e com manutencao rigorosa para garantir conforto e seguranca em cada viagem.</p>
    </div>
</section>

<section class="section-pad" style="background:var(--k)">
    <div class="container">
        <div class="frota-intro">
            <div class="fade-up">
                <span class="sec-label">Por que Mercedes-Benz Sprinter</span>
                <h2>O Padrao Ouro do Transporte Executivo</h2>
                <p>A Mercedes-Benz Sprinter e a escolha preferida de empresas que exigem conforto, seguranca e confiabilidade no transporte executivo. Com teto alto, espaco generoso e suspensao de qualidade, proporciona uma experiencia premium.</p>
                <p>Toda a nossa frota passa por inspeção tecnica trimestral, higienizacao completa antes de cada viagem e seguro total com cobertura em todo o territorio nacional.</p>
                <div style="display:flex;gap:20px;margin-top:22px;flex-wrap:wrap">
                    <div style="text-align:center">
                        <div style="font-size:1.8rem;font-weight:900;color:var(--y)">100%</div>
                        <div style="font-size:.74rem;color:rgba(255,255,255,.4);margin-top:3px">Mercedes-Benz</div>
                    </div>
                    <div style="text-align:center">
                        <div style="font-size:1.8rem;font-weight:900;color:var(--y)">2021+</div>
                        <div style="font-size:.74rem;color:rgba(255,255,255,.4);margin-top:3px">Ano dos veiculos</div>
                    </div>
                    <div style="text-align:center">
                        <div style="font-size:1.8rem;font-weight:900;color:var(--y)">0</div>
                        <div style="font-size:.74rem;color:rgba(255,255,255,.4);margin-top:3px">Acidentes graves</div>
                    </div>
                </div>
            </div>
            <div class="frota-img fade-up" style="--d:.12s">
                <div class="placeholder" aria-label="Frota VaideVan Mercedes-Benz Sprinter">🚐</div>
            </div>
        </div>
    </div>
</section>

<section class="section-pad" style="background:var(--d)">
    <div class="container">
        <div class="sec-head fade-up">
            <span class="sec-label">Modelos Disponiveis</span>
            <h2>Escolha o Modelo Ideal para sua Necessidade</h2>
        </div>
        <?php
        $modelos = [
            ['🚐','Mercedes-Benz Sprinter 415 CDI','Executive','A van executiva mais versatil da VaideVan. Ideal para grupos de ate 15 pessoas, com configuracao de poltronas executivas, teto alto e amplo espaco para bagagem.',
                ['15 passageiros','Poltronas executivas reclinaveis','Ar-condicionado duplo','Wi-Fi opcional','Tomadas 12V/USB','Manutencao trimestral','Seguro total','GPS rastreamento em tempo real'],'2022/2024'],
            ['🚐','Mercedes-Benz Sprinter 516 CDI','Executive','A versao de maior capacidade da nossa frota. Com 19 lugares executivos, e a escolha certa para grupos maiores, fretamentos e eventos corporativos que exigem mais espaco.',
                ['19 passageiros','Poltronas executivas','Ar-condicionado de alta capacidade','Luminarias individuais LED','Wi-Fi optional','Porta-malas ampliado','Cobertura de seguro total','GPS e rastreamento'],'2022/2024'],
            ['🛡️','Mercedes-Benz Sprinter Blindada','Security','Para quem nao abre mao da maxima seguranca. Blindagem nivel III-A certificada, vidros laminados, estrutura reforcada e motorista treinado em direcao defensiva e seguranca pessoal.',
                ['15 passageiros','Blindagem nivel III-A certificada','Vidros laminados antibalas','Motorista treinado em escolta','Rastreamento sigiloso em tempo real','Operacao 24h e fins de semana','Discrição total garantida','Relatorio de operacao'],'2022/2024'],
        ];
        foreach ($modelos as $i => [$ico, $nome, $tipo, $desc, $specs, $ano]): ?>
        <div style="display:grid;grid-template-columns:<?= $i % 2 === 0 ? '1fr 1.2fr' : '1.2fr 1fr' ?>;gap:48px;align-items:center;margin-bottom:72px;<?= $i === count($modelos)-1 ? 'margin-bottom:0' : '' ?>">
            <?php if ($i % 2 === 1): ?>
            <div class="fade-up">
                <div style="background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.07);border-radius:14px;height:280px;display:flex;align-items:center;justify-content:center;font-size:5rem" aria-label="<?= esc_attr($nome) ?>"><?= $ico ?></div>
            </div>
            <?php endif; ?>
            <div class="fade-up" style="--d:<?= $i % 2 === 0 ? '.12s' : '0s' ?>">
                <div style="display:inline-flex;gap:8px;margin-bottom:14px">
                    <span class="spec-tag"><?= esc_html($tipo) ?></span>
                    <span class="spec-tag"><?= esc_html($ano) ?></span>
                </div>
                <h2 style="font-size:clamp(1.5rem,2.8vw,2rem);font-weight:800;letter-spacing:-.8px;margin-bottom:12px"><?= esc_html($nome) ?></h2>
                <p style="color:rgba(255,255,255,.6);line-height:1.7;margin-bottom:18px"><?= esc_html($desc) ?></p>
                <div style="display:grid;grid-template-columns:1fr 1fr;gap:6px;margin-bottom:22px">
                    <?php foreach ($specs as $s): ?>
                    <div style="display:flex;align-items:center;gap:7px;font-size:.83rem;color:rgba(255,255,255,.7)">
                        <span style="color:var(--y);font-weight:700">&#10003;</span><?= esc_html($s) ?>
                    </div>
                    <?php endforeach; ?>
                </div>
                <a href="https://wa.me/5511999294694?text=Gostaria%20de%20alugar%20a%20<?= urlencode($nome) ?>"
                   class="btn-y" target="_blank" rel="noopener noreferrer" style="display:inline-flex">
                   Solicitar Esta Van
                </a>
            </div>
            <?php if ($i % 2 === 0): ?>
            <div class="fade-up" style="--d:.12s">
                <div style="background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.07);border-radius:14px;height:280px;display:flex;align-items:center;justify-content:center;font-size:5rem" aria-label="<?= esc_attr($nome) ?>"><?= $ico ?></div>
            </div>
            <?php endif; ?>
        </div>
        <?php endforeach; ?>
    </div>
</section>

<section class="section-pad" style="background:var(--k)">
    <div class="container">
        <div class="sec-head fade-up">
            <span class="sec-label">Acessorios e Opcionais</span>
            <h2>Personalize sua Van</h2>
            <p>Alguns opcionais podem ser adicionados conforme a necessidade do contrato.</p>
        </div>
        <div class="dif-grid">
            <?php foreach ([['Wi-Fi a Bordo','Conecao internet de alta velocidade durante toda a viagem.'],['Envelopamento Personalizado','Vans com logo ou identidade da sua empresa para eventos.'],['Frigobar','Bebidas geladas e petiscos disponíveis durante o trajeto.'],['Divisoria Executiva','Compartimento separado para privacidade total do passageiro VIP.'],['Sonorizacao Premium','Sistema de audio de alta qualidade para apresentacoes e reunioes.'],['Tela e Projetor','Para apresentacoes e treinamentos durante o deslocamento.']] as $i => [$t, $d]): ?>
            <div class="dif-item fade-up" style="--d:<?= $i * 0.06 ?>s">
                <div class="dif-n" aria-hidden>+</div>
                <div class="dif-t"><h4><?= esc_html($t) ?></h4><p><?= esc_html($d) ?></p></div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<section class="cta-band">
    <div class="container">
        <h2>Reserve Sua Van Agora</h2>
        <p>Disponibilidade imediata para a maioria dos destinos em Sao Paulo e interior.</p>
        <a href="https://wa.me/5511999294694" class="btn-k" target="_blank" rel="noopener noreferrer">Verificar Disponibilidade</a>
    </div>
</section>

<?php get_footer(); ?>
