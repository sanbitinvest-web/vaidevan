</main>

<footer id="site-footer" role="contentinfo">
  <div class="container">
    <div class="footer-grid">

      <div class="footer-brand">
        <picture>
          <source srcset="<?= esc_url(get_template_directory_uri()) ?>/assets/images/logo-dark.webp" type="image/webp">
          <img src="<?= esc_url(get_template_directory_uri()) ?>/assets/images/logo-dark.jpg"
               alt="VaideVan — Aluguel de Vans Executivas com Motorista em São Paulo"
               width="80" height="80" loading="lazy" decoding="async">
        </picture>
        <p data-i18n="footer.about">O maior serviço de locação de vans executivas do Brasil. Marca registrada, frota Mercedes-Benz Sprinter, motoristas treinados e 20+ anos de mercado.</p>
        <div style="margin-top:20px;display:flex;flex-direction:column;gap:8px">
          <a href="https://maps.app.goo.gl/jBEHwBJxC631QFQr8" target="_blank" rel="noopener noreferrer" style="font-size:.8125rem;color:rgba(255,255,255,.5);transition:color .25s ease" onmouseover="this.style.color='#F5E642'" onmouseout="this.style.color='rgba(255,255,255,.5)'">📍 Av. JK, 2041 — Itaim Bibi, São Paulo</a>
          <a href="https://wa.me/5511999294694" target="_blank" rel="noopener noreferrer"
             style="font-size:.8125rem;color:rgba(255,255,255,.5);transition:color .25s ease"
             onmouseover="this.style.color='#F5E642'" onmouseout="this.style.color='rgba(255,255,255,.5)'">
            📱 +55 11 99929-4694
          </a>
          <a href="mailto:contato@vaidevan.com"
             style="font-size:.8125rem;color:rgba(255,255,255,.5);transition:color .25s ease"
             onmouseover="this.style.color='#F5E642'" onmouseout="this.style.color='rgba(255,255,255,.5)'">
            ✉ contato@vaidevan.com
          </a>
        </div>
        <!-- Lang badges no footer -->
        <div class="footer-lang-badges" aria-label="Idiomas disponíveis">
          <span title="Português">🇧🇷</span>
          <span title="English">🇺🇸</span>
          <span title="Español">🇪🇸</span>
          <span title="中文">🇨🇳</span>
        </div>
      </div>

      <div class="footer-col">
        <h4 data-i18n="footer.services">Serviços</h4>
        <ul>
          <li><a href="<?= esc_url(home_url('/')) ?>#servicos">Aluguel de Van para Aeroporto</a></li>
          <li><a href="<?= esc_url(home_url('/')) ?>#servicos">Locação Corporativa B2B</a></li>
          <li><a href="<?= esc_url(home_url('/')) ?>#servicos">Van para Eventos</a></li>
          <li><a href="<?= esc_url(home_url('/')) ?>#servicos">Fretamento Executivo</a></li>
          <li><a href="<?= esc_url(home_url('/')) ?>#servicos">Excursões em Grupo</a></li>
          <li><a href="<?= esc_url(home_url('/')) ?>#servicos">Viagens Interestaduais</a></li>
        </ul>
      </div>

      <div class="footer-col">
        <h4 data-i18n="footer.company">Empresa</h4>
        <ul>
          <li><a href="<?= esc_url(home_url('/')) ?>#nossa-historia">Nossa História</a></li>
          <li><a href="<?= esc_url(home_url('/')) ?>#seja-investidor">Seja Investidor</a></li>
          <li><a href="<?= esc_url(home_url('/')) ?>#frota">Nossa Frota</a></li>
          <li><a href="<?= esc_url(home_url('/blog/')) ?>">Blog</a></li>
          <li><a href="<?= esc_url(home_url('/')) ?>#faq">FAQ</a></li>
          <li><a href="<?= esc_url(get_option('vdv_portal_url', 'https://portal.vaidevan.com')) ?>" class="portal-link" target="_blank" rel="noopener">Portal do Investidor</a></li>
        </ul>
        <h4 style="margin-top:24px" data-i18n="footer.sp">Atende em SP</h4>
        <ul>
          <li>Faria Lima &bull; Itaim Bibi</li>
          <li>Jardins &bull; Berrini</li>
          <li>Vila Olímpia &bull; Brooklin</li>
          <li>Guarulhos &bull; Alphaville</li>
        </ul>
      </div>

    </div>
  </div>
  <div class="container">
    <div class="footer-bottom">
      <p>© <?= date('Y') ?> VaideVan Transporte Executivo Ltda. Marca registrada no INPI. Todos os direitos reservados.</p>
      <p>Feito com ☕ em São Paulo, Brasil — <a href="https://vaidevan.com" style="color:var(--primary)">vaidevan.com</a></p>
    </div>
  </div>
</footer>

<!-- WhatsApp Flutuante -->
<a href="https://wa.me/5511999294694?text=Ol%C3%A1!%20Gostaria%20de%20solicitar%20um%20or%C3%A7amento%20de%20transporte." target="_blank" rel="noopener noreferrer" class="wpp-float" aria-label="Falar pelo WhatsApp">
  <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
</a>

<!-- Quote Modal -->
<div class="vdv-modal-overlay" id="quoteModal" role="dialog" aria-modal="true" aria-label="Solicitar orçamento">
  <div class="vdv-modal">
    <button class="vdv-modal-close" onclick="document.getElementById('quoteModal').classList.remove('open')" aria-label="Fechar">&times;</button>
    <h2 data-i18n="modal.quote.title">Solicitar Orçamento</h2>
    <p style="color:rgba(255,255,255,.5);font-size:.875rem;margin-bottom:24px" data-i18n="modal.quote.sub">Preencha e retornamos em até 2 horas.</p>
    <div id="modalSuccess" style="display:none;text-align:center;padding:32px 0">
      <div style="font-size:2.5rem;margin-bottom:12px">✓</div>
      <h3>Orçamento solicitado!</h3>
      <p style="color:rgba(255,255,255,.5);margin-top:8px">Nossa equipe entra em contato em breve.</p>
    </div>
    <form id="quoteForm" novalidate>
      <?php wp_nonce_field('vdv_orcamento','vdv_modal_nonce'); ?>
      <div style="margin-bottom:16px"><label class="field-label" for="mNome" data-i18n="form.name">Nome *</label><input class="field-input" type="text" id="mNome" name="nome" required placeholder="João Silva" autocomplete="name" style="width:100%"></div>
      <div style="margin-bottom:16px"><label class="field-label" for="mTel" data-i18n="form.wpp">WhatsApp *</label><input class="field-input" type="tel" id="mTel" name="telefone" required placeholder="(11) 99999-0000" autocomplete="tel" style="width:100%"></div>
      <div style="margin-bottom:16px"><label class="field-label" for="mTipo">Serviço</label>
        <select class="field-input" id="mTipo" name="tipo" style="width:100%"><option value="">Selecione...</option><option>Transfer aeroporto</option><option>Fretamento corporativo</option><option>Van para eventos</option><option>Excursão / passeio</option><option>Contrato mensal B2B</option></select>
      </div>
      <div style="margin-bottom:16px"><label class="field-label" for="mMsg" data-i18n="form.need">Necessidade</label><textarea class="field-textarea" id="mMsg" name="mensagem" rows="3" placeholder="Rota, data, passageiros..." style="width:100%"></textarea></div>
      <button type="submit" class="btn-submit" data-i18n="modal.quote.submit">Solicitar Orçamento Grátis</button>
    </form>
  </div>
</div>

<!-- Partner Modal -->
<div class="vdv-modal-overlay" id="partnerModal" role="dialog" aria-modal="true" aria-label="Seja nosso parceiro">
  <div class="vdv-modal">
    <button class="vdv-modal-close" onclick="document.getElementById('partnerModal').classList.remove('open')" aria-label="Fechar">&times;</button>
    <h2 data-i18n="modal.partner.title">Seja Nosso Parceiro</h2>
    <p style="color:rgba(255,255,255,.5);font-size:.875rem;margin-bottom:24px" data-i18n="modal.partner.sub">Investidor, cliente corporativo, revendedor ou motorista parceiro — nossa equipe entra em contato em até 24h.</p>
    <div id="partnerSuccess" style="display:none;text-align:center;padding:32px 0">
      <div style="font-size:2.5rem;margin-bottom:12px;color:var(--primary)">✓</div>
      <h3>Cadastro recebido!</h3>
      <p style="color:rgba(255,255,255,.5);margin-top:8px">Nossa equipe entrará em contato em breve.</p>
    </div>
    <form id="partnerForm" novalidate>
      <?php wp_nonce_field('vdv_parceiro','vdv_partner_nonce'); ?>
      <div style="margin-bottom:16px"><label class="field-label" for="pNome">Nome completo *</label><input class="field-input" type="text" id="pNome" name="nome" required placeholder="João Silva" autocomplete="name" style="width:100%"></div>
      <div style="margin-bottom:16px"><label class="field-label" for="pEmail">E-mail *</label><input class="field-input" type="email" id="pEmail" name="email" required placeholder="joao@empresa.com.br" autocomplete="email" style="width:100%"></div>
      <div style="margin-bottom:16px"><label class="field-label" for="pTel">WhatsApp *</label><input class="field-input" type="tel" id="pTel" name="telefone" required placeholder="(11) 99999-0000" autocomplete="tel" style="width:100%"></div>
      <div style="margin-bottom:16px"><label class="field-label" for="pTipo">Tipo de parceria *</label>
        <select class="field-input" id="pTipo" name="tipo" required style="width:100%">
          <option value="">Selecione...</option>
          <option value="investidor">Investidor</option>
          <option value="corporativo">Cliente Corporativo</option>
          <option value="revendedor">Revendedor</option>
          <option value="motorista">Motorista Parceiro</option>
          <option value="outro">Outro</option>
        </select>
      </div>
      <div style="margin-bottom:16px"><label class="field-label" for="pMsg">Conte um pouco sobre você</label><textarea class="field-input" id="pMsg" name="mensagem" rows="3" placeholder="Descreva brevemente seu interesse..." style="width:100%;resize:vertical"></textarea></div>
      <button type="submit" class="btn-submit" id="partnerSubmitBtn" data-i18n="modal.partner.submit">Enviar Cadastro</button>
    </form>
  </div>
</div>

<?php wp_footer(); ?>
</body>
</html>
