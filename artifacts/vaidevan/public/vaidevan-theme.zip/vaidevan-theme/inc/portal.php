<?php
/**
 * Portal do Investidor — Banco de Dados + AJAX
 * VaideVan Transporte Executivo
 */
defined('ABSPATH') || exit;

/* ----------------------------------------------------------------
   1. CRIACAO DAS TABELAS + SEED
   ---------------------------------------------------------------- */
function vdv_create_tables() {
    global $wpdb;
    $charset = $wpdb->get_charset_collate();

    /* Investidores */
    $wpdb->query("CREATE TABLE IF NOT EXISTS `{$wpdb->prefix}vdv_investors` (
        id              INT UNSIGNED NOT NULL AUTO_INCREMENT,
        nome            VARCHAR(160) NOT NULL,
        email           VARCHAR(160) NOT NULL,
        senha_hash      VARCHAR(255) NOT NULL,
        participacao_pct DECIMAL(5,2) NOT NULL DEFAULT 0.00,
        capital_aportado DECIMAL(14,2) NOT NULL DEFAULT 0.00,
        data_entrada    DATE DEFAULT NULL,
        ativo           TINYINT(1) NOT NULL DEFAULT 1,
        criado_em       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY email (email)
    ) $charset;");

    /* Operacoes */
    $wpdb->query("CREATE TABLE IF NOT EXISTS `{$wpdb->prefix}vdv_operations` (
        id              INT UNSIGNED NOT NULL AUTO_INCREMENT,
        nome            VARCHAR(160) NOT NULL,
        cidades         SMALLINT UNSIGNED NOT NULL DEFAULT 0,
        estados         TINYINT UNSIGNED NOT NULL DEFAULT 0,
        status          ENUM('ativo','pausa','encerrado') NOT NULL DEFAULT 'ativo',
        descricao       TEXT DEFAULT NULL,
        iniciado_em     DATE DEFAULT NULL,
        criado_em       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id)
    ) $charset;");

    /* Veiculos */
    $wpdb->query("CREATE TABLE IF NOT EXISTS `{$wpdb->prefix}vdv_vehicles` (
        id              INT UNSIGNED NOT NULL AUTO_INCREMENT,
        placa           VARCHAR(8) NOT NULL,
        modelo          VARCHAR(120) NOT NULL,
        ano             SMALLINT UNSIGNED NOT NULL DEFAULT 0,
        capacidade      TINYINT UNSIGNED NOT NULL DEFAULT 0,
        status          ENUM('ativo','manutencao','inativo') NOT NULL DEFAULT 'ativo',
        operacao_id     INT UNSIGNED DEFAULT NULL,
        km_atual        INT UNSIGNED NOT NULL DEFAULT 0,
        chassi          VARCHAR(30) DEFAULT NULL,
        criado_em       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY placa (placa)
    ) $charset;");

    /* Financeiro */
    $wpdb->query("CREATE TABLE IF NOT EXISTS `{$wpdb->prefix}vdv_financials` (
        id              INT UNSIGNED NOT NULL AUTO_INCREMENT,
        operacao_id     INT UNSIGNED NOT NULL,
        tipo            ENUM('receita','despesa') NOT NULL,
        categoria       VARCHAR(80) NOT NULL,
        descricao       VARCHAR(220) NOT NULL,
        valor           DECIMAL(12,2) NOT NULL,
        data_mov        DATE NOT NULL,
        referencia      VARCHAR(40) DEFAULT NULL,
        criado_em       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY idx_tipo (tipo),
        KEY idx_data (data_mov),
        KEY idx_op (operacao_id)
    ) $charset;");

    /* Seed */
    vdv_seed_data();
}

function vdv_seed_data() {
    global $wpdb;
    $pfx = $wpdb->prefix;

    /* --- Investidor demo --- */
    $exists = $wpdb->get_var("SELECT COUNT(*) FROM `{$pfx}vdv_investors`");
    if (!$exists) {
        $wpdb->insert("{$pfx}vdv_investors", [
            'nome'            => 'Joao Silva',
            'email'           => 'investidor@vaidevan.com',
            'senha_hash'      => password_hash('vaidevan123', PASSWORD_DEFAULT),
            'participacao_pct'=> 12.50,
            'capital_aportado'=> 250000.00,
            'data_entrada'    => '2022-03-01',
            'ativo'           => 1,
        ]);
        $wpdb->insert("{$pfx}vdv_investors", [
            'nome'            => 'Maria Oliveira',
            'email'           => 'maria@vaidevan.com',
            'senha_hash'      => password_hash('maria2024', PASSWORD_DEFAULT),
            'participacao_pct'=> 8.00,
            'capital_aportado'=> 160000.00,
            'data_entrada'    => '2023-01-15',
            'ativo'           => 1,
        ]);
        $wpdb->insert("{$pfx}vdv_investors", [
            'nome'            => 'Carlos Mendes',
            'email'           => 'carlos@vaidevan.com',
            'senha_hash'      => password_hash('carlos2024', PASSWORD_DEFAULT),
            'participacao_pct'=> 15.00,
            'capital_aportado'=> 300000.00,
            'data_entrada'    => '2021-09-01',
            'ativo'           => 1,
        ]);
    }

    /* --- Operacoes --- */
    $op_exists = $wpdb->get_var("SELECT COUNT(*) FROM `{$pfx}vdv_operations`");
    if (!$op_exists) {
        $wpdb->insert("{$pfx}vdv_operations", [
            'nome'        => 'SP Norte e Grande SP',
            'cidades'     => 28,
            'estados'     => 1,
            'status'      => 'ativo',
            'descricao'   => 'Atendimento corporativo na regiao norte de SP e Grande SP',
            'iniciado_em' => '2020-01-01',
        ]);
        $op1 = $wpdb->insert_id;

        $wpdb->insert("{$pfx}vdv_operations", [
            'nome'        => 'Interior Paulista',
            'cidades'     => 21,
            'estados'     => 1,
            'status'      => 'ativo',
            'descricao'   => 'Campinas, Sorocaba, Ribeirao Preto e interior',
            'iniciado_em' => '2020-06-01',
        ]);
        $op2 = $wpdb->insert_id;

        $wpdb->insert("{$pfx}vdv_operations", [
            'nome'        => 'Litoral e Serra',
            'cidades'     => 12,
            'estados'     => 2,
            'status'      => 'pausa',
            'descricao'   => 'Santos, Guaruja, Serra Gaucha — operacao temporariamente pausada',
            'iniciado_em' => '2021-03-01',
        ]);

        /* --- Veiculos --- */
        $veh_exists = $wpdb->get_var("SELECT COUNT(*) FROM `{$pfx}vdv_vehicles`");
        if (!$veh_exists) {
            $vehs = [
                ['ABC-1D34','Mercedes-Benz Sprinter 415 CDI',2022,15,'ativo',$op1,127400,'9BM910362NB456789'],
                ['DEF-5E78','Mercedes-Benz Sprinter 415 CDI',2023,15,'ativo',$op1,84200,'9BM910362PB123456'],
                ['GHI-9F12','Mercedes-Benz Sprinter 516 CDI',2022,19,'ativo',$op2,112700,'9BM910361NB789012'],
                ['JKL-3G56','Mercedes-Benz Sprinter 415 CDI',2024,15,'ativo',$op2,31500,'9BM910362RB234567'],
                ['MNO-7H90','Mercedes-Benz Sprinter 516 CDI',2023,19,'manutencao',$op2,97800,'9BM910361PB345678'],
                ['PQR-1I23','Mercedes-Benz Sprinter 415 CDI',2021,15,'ativo',$op1,168300,'9BM910362MB567890'],
            ];
            foreach ($vehs as $v) {
                $wpdb->insert("{$pfx}vdv_vehicles", [
                    'placa'      => $v[0],
                    'modelo'     => $v[1],
                    'ano'        => $v[2],
                    'capacidade' => $v[3],
                    'status'     => $v[4],
                    'operacao_id'=> $v[5],
                    'km_atual'   => $v[6],
                    'chassi'     => $v[7],
                ]);
            }
        }

        /* --- Financeiro: 12 meses de dados reais --- */
        $fin_exists = $wpdb->get_var("SELECT COUNT(*) FROM `{$pfx}vdv_financials`");
        if (!$fin_exists) {
            $fin = vdv_get_financial_seed($op1, $op2);
            foreach ($fin as $f) {
                $wpdb->insert("{$pfx}vdv_financials", $f);
            }
        }
    }
}

function vdv_get_financial_seed($op1, $op2) {
    $rows = [];
    /* 12 meses — Janeiro 2024 a Dezembro 2024 */
    $meses = [
        ['2024-01', 38400, 16200, 'jan2024'],
        ['2024-02', 35800, 15100, 'fev2024'],
        ['2024-03', 42300, 17800, 'mar2024'],
        ['2024-04', 39700, 16400, 'abr2024'],
        ['2024-05', 44600, 18600, 'mai2024'],
        ['2024-06', 41200, 17200, 'jun2024'],
        ['2024-07', 46800, 19400, 'jul2024'],
        ['2024-08', 43900, 18100, 'ago2024'],
        ['2024-09', 48200, 20200, 'set2024'],
        ['2024-10', 51400, 21800, 'out2024'],
        ['2024-11', 54700, 23100, 'nov2024'],
        ['2024-12', 62300, 26400, 'dez2024'],
    ];

    $rec_cats = [
        'Fretamento corporativo'        => 0.38,
        'Aluguel van executiva'         => 0.29,
        'Transfer aeroporto'            => 0.18,
        'Eventos e congressos'          => 0.10,
        'Turismo e lazer'               => 0.05,
    ];
    $desp_cats = [
        'Salarios e encargos'           => 0.45,
        'Combustivel'                   => 0.22,
        'Manutencao frota'              => 0.12,
        'Seguro frota'                  => 0.08,
        'Despesas administrativas'      => 0.07,
        'Impostos e taxas'              => 0.06,
    ];

    foreach ($meses as [$ref_ym, $tot_rec, $tot_desp, $ref]) {
        $ops = [$op1, $op2];
        $op_split = [0.58, 0.42];
        foreach ($ops as $idx => $opid) {
            $rop = round($tot_rec * $op_split[$idx]);
            $dop = round($tot_desp * $op_split[$idx]);
            $day = 1;
            foreach ($rec_cats as $cat => $pct) {
                $v = round($rop * $pct, 2);
                $rows[] = [
                    'operacao_id' => $opid,
                    'tipo'        => 'receita',
                    'categoria'   => $cat,
                    'descricao'   => $cat . ' — ' . ($idx === 0 ? 'Operacao SP Norte' : 'Operacao Interior'),
                    'valor'       => $v,
                    'data_mov'    => $ref_ym . '-' . str_pad($day++, 2, '0', STR_PAD_LEFT),
                    'referencia'  => $ref,
                ];
            }
            $day = 3;
            foreach ($desp_cats as $cat => $pct) {
                $v = round($dop * $pct, 2);
                $rows[] = [
                    'operacao_id' => $opid,
                    'tipo'        => 'despesa',
                    'categoria'   => $cat,
                    'descricao'   => $cat . ' — ' . ($idx === 0 ? 'Operacao SP Norte' : 'Operacao Interior'),
                    'valor'       => $v,
                    'data_mov'    => $ref_ym . '-' . str_pad($day++, 2, '0', STR_PAD_LEFT),
                    'referencia'  => $ref,
                ];
            }
        }
    }
    return $rows;
}

/* ----------------------------------------------------------------
   2. SESSAO + AJAX HANDLERS
   Usa WordPress transients + cookie HTTP-only (sem session_start)
   Compativel com LiteSpeed e qualquer hosting compartilhado
   ---------------------------------------------------------------- */
define('VDV_COOKIE', 'vdv_portal_token');
define('VDV_TTL',    28800); /* 8 horas */

function vdv_portal_get_investor_id() {
    $token = isset($_COOKIE[VDV_COOKIE]) ? sanitize_text_field($_COOKIE[VDV_COOKIE]) : '';
    if (!$token) { return 0; }
    $id = (int) get_transient('vdv_pt_' . $token);
    return $id > 0 ? $id : 0;
}

function vdv_portal_set_token($investor_id) {
    $token = wp_generate_password(48, false);
    set_transient('vdv_pt_' . $token, (int) $investor_id, VDV_TTL);
    setcookie(VDV_COOKIE, $token, [
        'expires'  => time() + VDV_TTL,
        'path'     => COOKIEPATH ?: '/',
        'domain'   => COOKIE_DOMAIN ?: '',
        'secure'   => is_ssl(),
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    return $token;
}

function vdv_portal_clear_token() {
    $token = isset($_COOKIE[VDV_COOKIE]) ? sanitize_text_field($_COOKIE[VDV_COOKIE]) : '';
    if ($token) {
        delete_transient('vdv_pt_' . $token);
    }
    setcookie(VDV_COOKIE, '', time() - 3600, COOKIEPATH ?: '/', COOKIE_DOMAIN ?: '');
}

/* ----------------------------------------------------------------
   2. AJAX HANDLERS
   ---------------------------------------------------------------- */
add_action('wp_ajax_nopriv_vdv_portal_login', 'vdv_ajax_login');
add_action('wp_ajax_vdv_portal_login',        'vdv_ajax_login');
function vdv_ajax_login() {
    check_ajax_referer('vdv_portal_nonce', 'nonce');
    $email = sanitize_email(wp_unslash($_POST['email'] ?? ''));
    $senha = wp_unslash($_POST['senha'] ?? '');

    if (!$email || !$senha) {
        wp_send_json_error(['message' => 'Preencha todos os campos.']);
    }

    global $wpdb;
    $inv = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM `{$wpdb->prefix}vdv_investors` WHERE email=%s AND ativo=1 LIMIT 1",
        $email
    ));

    if (!$inv || !password_verify($senha, $inv->senha_hash)) {
        wp_send_json_error(['message' => 'E-mail ou senha incorretos.']);
    }

    vdv_portal_set_token((int) $inv->id);
    wp_send_json_success(vdv_get_dashboard_data($inv));
}

add_action('wp_ajax_nopriv_vdv_portal_logout', 'vdv_ajax_logout');
add_action('wp_ajax_vdv_portal_logout',        'vdv_ajax_logout');
function vdv_ajax_logout() {
    vdv_portal_clear_token();
    wp_send_json_success(['ok' => true]);
}

add_action('wp_ajax_nopriv_vdv_portal_check', 'vdv_ajax_check');
add_action('wp_ajax_vdv_portal_check',        'vdv_ajax_check');
function vdv_ajax_check() {
    check_ajax_referer('vdv_portal_nonce', 'nonce');
    $id = vdv_portal_get_investor_id();
    if (!$id) {
        wp_send_json_success(['logado' => false]);
    }
    global $wpdb;
    $inv = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM `{$wpdb->prefix}vdv_investors` WHERE id=%d AND ativo=1 LIMIT 1", $id
    ));
    if (!$inv) {
        vdv_portal_clear_token();
        wp_send_json_success(['logado' => false]);
    }
    /* Renovar TTL do token */
    $token = isset($_COOKIE[VDV_COOKIE]) ? sanitize_text_field($_COOKIE[VDV_COOKIE]) : '';
    if ($token) {
        set_transient('vdv_pt_' . $token, $id, VDV_TTL);
    }
    $data = vdv_get_dashboard_data($inv);
    $data['logado'] = true;
    wp_send_json_success($data);
}

/* ----------------------------------------------------------------
   3. DADOS DO DASHBOARD
   ---------------------------------------------------------------- */
function vdv_get_dashboard_data($inv) {
    global $wpdb;
    $pfx = $wpdb->prefix;

    /* Operacoes */
    $ops = $wpdb->get_results("SELECT * FROM `{$pfx}vdv_operations` ORDER BY status ASC, nome ASC");

    /* Veiculos */
    $vehs = $wpdb->get_results("SELECT * FROM `{$pfx}vdv_vehicles` ORDER BY status ASC, placa ASC");

    /* Movimentos — todos para tabela */
    $movs = $wpdb->get_results("
        SELECT f.*, o.nome as operacao_nome,
               DATE_FORMAT(f.data_mov,'%d/%m/%Y') as data_formatada
        FROM `{$pfx}vdv_financials` f
        LEFT JOIN `{$pfx}vdv_operations` o ON o.id = f.operacao_id
        ORDER BY f.data_mov DESC
    ");

    /* KPIs — ano de 2024 */
    $kpis_raw = $wpdb->get_row("
        SELECT
            SUM(CASE WHEN tipo='receita' THEN valor ELSE 0 END) AS receita_total,
            SUM(CASE WHEN tipo='despesa' THEN valor ELSE 0 END) AS despesa_total
        FROM `{$pfx}vdv_financials`
        WHERE YEAR(data_mov) = 2024
    ");
    $rec  = (float)($kpis_raw->receita_total ?? 0);
    $desp = (float)($kpis_raw->despesa_total ?? 0);
    $lucro = $rec - $desp;

    /* Var % — comparar Nov vs Out 2024 */
    $meses_compare = $wpdb->get_results("
        SELECT
            MONTH(data_mov) AS mes,
            SUM(CASE WHEN tipo='receita' THEN valor ELSE 0 END) -
            SUM(CASE WHEN tipo='despesa' THEN valor ELSE 0 END) AS lucro_mes
        FROM `{$pfx}vdv_financials`
        WHERE YEAR(data_mov)=2024 AND MONTH(data_mov) IN (11,12)
        GROUP BY MONTH(data_mov)
        ORDER BY mes ASC
    ");
    $var_pct = null;
    if (count($meses_compare) === 2) {
        $ant = (float) $meses_compare[0]->lucro_mes;
        $atu = (float) $meses_compare[1]->lucro_mes;
        $var_pct = $ant != 0 ? round((($atu - $ant) / abs($ant)) * 100, 1) : null;
    }

    /* Mensal para chart */
    $mensal = $wpdb->get_results("
        SELECT
            MONTH(data_mov) AS mes,
            SUM(CASE WHEN tipo='receita' THEN valor ELSE 0 END) AS receita,
            SUM(CASE WHEN tipo='despesa' THEN valor ELSE 0 END) AS despesa
        FROM `{$pfx}vdv_financials`
        WHERE YEAR(data_mov)=2024
        GROUP BY MONTH(data_mov)
        ORDER BY MONTH(data_mov) ASC
    ");

    return [
        'investidor' => [
            'nome'             => $inv->nome,
            'email'            => $inv->email,
            'participacao_pct' => (float) $inv->participacao_pct,
            'capital_aportado' => (float) $inv->capital_aportado,
            'data_entrada'     => $inv->data_entrada,
        ],
        'operacoes'  => $ops,
        'veiculos'   => $vehs,
        'movimentos' => $movs,
        'mensal'     => $mensal,
        'kpis'       => [
            'receita_total' => $rec,
            'despesa_total' => $desp,
            'lucro'         => $lucro,
            'var_pct'       => $var_pct,
        ],
    ];
}

/* Sessao gerenciada via transients — nao precisa de session_start() */

/* ----------------------------------------------------------------
   4. CRUD — MOVIMENTOS FINANCEIROS
   ---------------------------------------------------------------- */
add_action('wp_ajax_nopriv_vdv_portal_add_movement', 'vdv_ajax_add_movement');
add_action('wp_ajax_vdv_portal_add_movement',        'vdv_ajax_add_movement');
function vdv_ajax_add_movement() {
    check_ajax_referer('vdv_portal_nonce', 'nonce');
    $id = vdv_portal_get_investor_id();
    if (!$id) { wp_send_json_error(['message' => 'Sessão expirada.']); }

    global $wpdb;
    $tipo     = in_array($_POST['tipo'] ?? '', ['receita','despesa']) ? $_POST['tipo'] : '';
    $cat      = sanitize_text_field(wp_unslash($_POST['categoria']   ?? ''));
    $desc     = sanitize_text_field(wp_unslash($_POST['descricao']   ?? ''));
    $valor    = (float) str_replace(',', '.', wp_unslash($_POST['valor'] ?? '0'));
    $data_mov = sanitize_text_field(wp_unslash($_POST['data_mov']    ?? ''));
    $op_id    = (int) ($_POST['operacao_id'] ?? 0);
    $ref      = sanitize_text_field(wp_unslash($_POST['referencia']  ?? ''));

    if (!$tipo || !$cat || !$desc || $valor <= 0 || !$data_mov) {
        wp_send_json_error(['message' => 'Preencha os campos obrigatórios.']);
    }

    $wpdb->insert("{$wpdb->prefix}vdv_financials", [
        'operacao_id' => $op_id ?: 1,
        'tipo'        => $tipo,
        'categoria'   => $cat,
        'descricao'   => $desc,
        'valor'       => $valor,
        'data_mov'    => $data_mov,
        'referencia'  => $ref ?: null,
    ]);
    wp_send_json_success(['id' => $wpdb->insert_id]);
}

add_action('wp_ajax_nopriv_vdv_portal_update_movement', 'vdv_ajax_update_movement');
add_action('wp_ajax_vdv_portal_update_movement',        'vdv_ajax_update_movement');
function vdv_ajax_update_movement() {
    check_ajax_referer('vdv_portal_nonce', 'nonce');
    if (!vdv_portal_get_investor_id()) { wp_send_json_error(['message' => 'Sessão expirada.']); }

    global $wpdb;
    $mov_id   = (int) ($_POST['id'] ?? 0);
    if (!$mov_id) { wp_send_json_error(['message' => 'ID inválido.']); }

    $tipo     = in_array($_POST['tipo'] ?? '', ['receita','despesa']) ? $_POST['tipo'] : '';
    $cat      = sanitize_text_field(wp_unslash($_POST['categoria']   ?? ''));
    $desc     = sanitize_text_field(wp_unslash($_POST['descricao']   ?? ''));
    $valor    = (float) str_replace(',', '.', wp_unslash($_POST['valor'] ?? '0'));
    $data_mov = sanitize_text_field(wp_unslash($_POST['data_mov']    ?? ''));
    $op_id    = (int) ($_POST['operacao_id'] ?? 0);
    $ref      = sanitize_text_field(wp_unslash($_POST['referencia']  ?? ''));

    if (!$tipo || !$cat || !$desc || $valor <= 0 || !$data_mov) {
        wp_send_json_error(['message' => 'Preencha os campos obrigatórios.']);
    }

    $wpdb->update("{$wpdb->prefix}vdv_financials", [
        'operacao_id' => $op_id ?: 1,
        'tipo'        => $tipo,
        'categoria'   => $cat,
        'descricao'   => $desc,
        'valor'       => $valor,
        'data_mov'    => $data_mov,
        'referencia'  => $ref ?: null,
    ], ['id' => $mov_id]);
    wp_send_json_success(['ok' => true]);
}

add_action('wp_ajax_nopriv_vdv_portal_delete_movement', 'vdv_ajax_delete_movement');
add_action('wp_ajax_vdv_portal_delete_movement',        'vdv_ajax_delete_movement');
function vdv_ajax_delete_movement() {
    check_ajax_referer('vdv_portal_nonce', 'nonce');
    if (!vdv_portal_get_investor_id()) { wp_send_json_error(['message' => 'Sessão expirada.']); }
    global $wpdb;
    $mov_id = (int) ($_POST['id'] ?? 0);
    if (!$mov_id) { wp_send_json_error(['message' => 'ID inválido.']); }
    $wpdb->delete("{$wpdb->prefix}vdv_financials", ['id' => $mov_id]);
    wp_send_json_success(['ok' => true]);
}

/* ----------------------------------------------------------------
   5. CRUD — VEÍCULOS
   ---------------------------------------------------------------- */
add_action('wp_ajax_nopriv_vdv_portal_add_vehicle', 'vdv_ajax_add_vehicle');
add_action('wp_ajax_vdv_portal_add_vehicle',        'vdv_ajax_add_vehicle');
function vdv_ajax_add_vehicle() {
    check_ajax_referer('vdv_portal_nonce', 'nonce');
    if (!vdv_portal_get_investor_id()) { wp_send_json_error(['message' => 'Sessão expirada.']); }
    global $wpdb;

    $placa    = strtoupper(sanitize_text_field(wp_unslash($_POST['placa']    ?? '')));
    $modelo   = sanitize_text_field(wp_unslash($_POST['modelo']   ?? ''));
    $ano      = (int) ($_POST['ano']       ?? 0);
    $cap      = (int) ($_POST['capacidade']?? 0);
    $status   = in_array($_POST['status'] ?? '', ['ativo','manutencao','inativo']) ? $_POST['status'] : 'ativo';
    $op_id    = (int) ($_POST['operacao_id'] ?? 0);
    $km       = (int) ($_POST['km_atual']   ?? 0);
    $chassi   = sanitize_text_field(wp_unslash($_POST['chassi']   ?? ''));

    if (!$placa || !$modelo || !$ano || !$cap) {
        wp_send_json_error(['message' => 'Preencha os campos obrigatórios.']);
    }

    $exists = $wpdb->get_var($wpdb->prepare(
        "SELECT id FROM `{$wpdb->prefix}vdv_vehicles` WHERE placa=%s", $placa
    ));
    if ($exists) { wp_send_json_error(['message' => 'Placa já cadastrada.']); }

    $wpdb->insert("{$wpdb->prefix}vdv_vehicles", [
        'placa'       => $placa,
        'modelo'      => $modelo,
        'ano'         => $ano,
        'capacidade'  => $cap,
        'status'      => $status,
        'operacao_id' => $op_id ?: null,
        'km_atual'    => $km,
        'chassi'      => $chassi ?: null,
    ]);
    wp_send_json_success(['id' => $wpdb->insert_id]);
}

add_action('wp_ajax_nopriv_vdv_portal_update_vehicle', 'vdv_ajax_update_vehicle');
add_action('wp_ajax_vdv_portal_update_vehicle',        'vdv_ajax_update_vehicle');
function vdv_ajax_update_vehicle() {
    check_ajax_referer('vdv_portal_nonce', 'nonce');
    if (!vdv_portal_get_investor_id()) { wp_send_json_error(['message' => 'Sessão expirada.']); }
    global $wpdb;

    $veh_id = (int) ($_POST['id'] ?? 0);
    if (!$veh_id) { wp_send_json_error(['message' => 'ID inválido.']); }

    $placa  = strtoupper(sanitize_text_field(wp_unslash($_POST['placa']    ?? '')));
    $modelo = sanitize_text_field(wp_unslash($_POST['modelo']   ?? ''));
    $ano    = (int) ($_POST['ano']       ?? 0);
    $cap    = (int) ($_POST['capacidade']?? 0);
    $status = in_array($_POST['status'] ?? '', ['ativo','manutencao','inativo']) ? $_POST['status'] : 'ativo';
    $op_id  = (int) ($_POST['operacao_id'] ?? 0);
    $km     = (int) ($_POST['km_atual']   ?? 0);
    $chassi = sanitize_text_field(wp_unslash($_POST['chassi']   ?? ''));

    if (!$placa || !$modelo || !$ano || !$cap) {
        wp_send_json_error(['message' => 'Preencha os campos obrigatórios.']);
    }

    $wpdb->update("{$wpdb->prefix}vdv_vehicles", [
        'placa'       => $placa,
        'modelo'      => $modelo,
        'ano'         => $ano,
        'capacidade'  => $cap,
        'status'      => $status,
        'operacao_id' => $op_id ?: null,
        'km_atual'    => $km,
        'chassi'      => $chassi ?: null,
    ], ['id' => $veh_id]);
    wp_send_json_success(['ok' => true]);
}

add_action('wp_ajax_nopriv_vdv_portal_delete_vehicle', 'vdv_ajax_delete_vehicle');
add_action('wp_ajax_vdv_portal_delete_vehicle',        'vdv_ajax_delete_vehicle');
function vdv_ajax_delete_vehicle() {
    check_ajax_referer('vdv_portal_nonce', 'nonce');
    if (!vdv_portal_get_investor_id()) { wp_send_json_error(['message' => 'Sessão expirada.']); }
    global $wpdb;
    $veh_id = (int) ($_POST['id'] ?? 0);
    if (!$veh_id) { wp_send_json_error(['message' => 'ID inválido.']); }
    $wpdb->delete("{$wpdb->prefix}vdv_vehicles", ['id' => $veh_id]);
    wp_send_json_success(['ok' => true]);
}

/* ----------------------------------------------------------------
   6. CRUD — OPERAÇÕES
   ---------------------------------------------------------------- */
add_action('wp_ajax_nopriv_vdv_portal_add_operation', 'vdv_ajax_add_operation');
add_action('wp_ajax_vdv_portal_add_operation',        'vdv_ajax_add_operation');
function vdv_ajax_add_operation() {
    check_ajax_referer('vdv_portal_nonce', 'nonce');
    if (!vdv_portal_get_investor_id()) { wp_send_json_error(['message' => 'Sessão expirada.']); }
    global $wpdb;

    $nome    = sanitize_text_field(wp_unslash($_POST['nome']     ?? ''));
    $cidades = (int) ($_POST['cidades']  ?? 0);
    $estados = (int) ($_POST['estados']  ?? 0);
    $status  = in_array($_POST['status'] ?? '', ['ativo','pausa','encerrado']) ? $_POST['status'] : 'ativo';
    $inicio  = sanitize_text_field(wp_unslash($_POST['iniciado_em'] ?? ''));
    $desc    = sanitize_textarea_field(wp_unslash($_POST['descricao'] ?? ''));

    if (!$nome) { wp_send_json_error(['message' => 'Informe o nome da operação.']); }

    $wpdb->insert("{$wpdb->prefix}vdv_operations", [
        'nome'        => $nome,
        'cidades'     => $cidades,
        'estados'     => $estados,
        'status'      => $status,
        'iniciado_em' => $inicio ?: null,
        'descricao'   => $desc ?: null,
    ]);
    wp_send_json_success(['id' => $wpdb->insert_id]);
}

add_action('wp_ajax_nopriv_vdv_portal_update_operation', 'vdv_ajax_update_operation');
add_action('wp_ajax_vdv_portal_update_operation',        'vdv_ajax_update_operation');
function vdv_ajax_update_operation() {
    check_ajax_referer('vdv_portal_nonce', 'nonce');
    if (!vdv_portal_get_investor_id()) { wp_send_json_error(['message' => 'Sessão expirada.']); }
    global $wpdb;

    $op_id   = (int) ($_POST['id'] ?? 0);
    if (!$op_id) { wp_send_json_error(['message' => 'ID inválido.']); }

    $nome    = sanitize_text_field(wp_unslash($_POST['nome']     ?? ''));
    $cidades = (int) ($_POST['cidades']  ?? 0);
    $estados = (int) ($_POST['estados']  ?? 0);
    $status  = in_array($_POST['status'] ?? '', ['ativo','pausa','encerrado']) ? $_POST['status'] : 'ativo';
    $inicio  = sanitize_text_field(wp_unslash($_POST['iniciado_em'] ?? ''));
    $desc    = sanitize_textarea_field(wp_unslash($_POST['descricao'] ?? ''));

    if (!$nome) { wp_send_json_error(['message' => 'Informe o nome da operação.']); }

    $wpdb->update("{$wpdb->prefix}vdv_operations", [
        'nome'        => $nome,
        'cidades'     => $cidades,
        'estados'     => $estados,
        'status'      => $status,
        'iniciado_em' => $inicio ?: null,
        'descricao'   => $desc ?: null,
    ], ['id' => $op_id]);
    wp_send_json_success(['ok' => true]);
}

add_action('wp_ajax_nopriv_vdv_portal_delete_operation', 'vdv_ajax_delete_operation');
add_action('wp_ajax_vdv_portal_delete_operation',        'vdv_ajax_delete_operation');
function vdv_ajax_delete_operation() {
    check_ajax_referer('vdv_portal_nonce', 'nonce');
    if (!vdv_portal_get_investor_id()) { wp_send_json_error(['message' => 'Sessão expirada.']); }
    global $wpdb;
    $op_id = (int) ($_POST['id'] ?? 0);
    if (!$op_id) { wp_send_json_error(['message' => 'ID inválido.']); }
    $wpdb->delete("{$wpdb->prefix}vdv_operations", ['id' => $op_id]);
    wp_send_json_success(['ok' => true]);
}

/* ----------------------------------------------------------------
   7. PERFIL DO INVESTIDOR
   ---------------------------------------------------------------- */
add_action('wp_ajax_nopriv_vdv_portal_update_profile', 'vdv_ajax_update_profile');
add_action('wp_ajax_vdv_portal_update_profile',        'vdv_ajax_update_profile');
function vdv_ajax_update_profile() {
    check_ajax_referer('vdv_portal_nonce', 'nonce');
    $investor_id = vdv_portal_get_investor_id();
    if (!$investor_id) { wp_send_json_error(['message' => 'Sessão expirada.']); }
    global $wpdb;

    $nome  = sanitize_text_field(wp_unslash($_POST['nome']  ?? ''));
    $email = sanitize_email(wp_unslash($_POST['email'] ?? ''));
    if (!$nome || !is_email($email)) {
        wp_send_json_error(['message' => 'Nome e e-mail válidos são obrigatórios.']);
    }

    /* Verifica se e-mail já existe para outro investidor */
    $conflict = $wpdb->get_var($wpdb->prepare(
        "SELECT id FROM `{$wpdb->prefix}vdv_investors` WHERE email=%s AND id != %d",
        $email, $investor_id
    ));
    if ($conflict) { wp_send_json_error(['message' => 'E-mail já está em uso por outro investidor.']); }

    $wpdb->update("{$wpdb->prefix}vdv_investors", [
        'nome'  => $nome,
        'email' => $email,
    ], ['id' => $investor_id]);
    wp_send_json_success(['ok' => true]);
}

add_action('wp_ajax_nopriv_vdv_portal_change_password', 'vdv_ajax_change_password');
add_action('wp_ajax_vdv_portal_change_password',        'vdv_ajax_change_password');
function vdv_ajax_change_password() {
    check_ajax_referer('vdv_portal_nonce', 'nonce');
    $investor_id = vdv_portal_get_investor_id();
    if (!$investor_id) { wp_send_json_error(['message' => 'Sessão expirada.']); }
    global $wpdb;

    $atual = wp_unslash($_POST['senha_atual'] ?? '');
    $nova  = wp_unslash($_POST['senha_nova']  ?? '');
    if (!$atual || !$nova || strlen($nova) < 6) {
        wp_send_json_error(['message' => 'Preencha corretamente.']);
    }

    $inv = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM `{$wpdb->prefix}vdv_investors` WHERE id=%d LIMIT 1", $investor_id
    ));
    if (!$inv || !password_verify($atual, $inv->senha_hash)) {
        wp_send_json_error(['message' => 'Senha atual incorreta.']);
    }

    $wpdb->update("{$wpdb->prefix}vdv_investors", [
        'senha_hash' => password_hash($nova, PASSWORD_DEFAULT),
    ], ['id' => $investor_id]);
    wp_send_json_success(['ok' => true]);
}
