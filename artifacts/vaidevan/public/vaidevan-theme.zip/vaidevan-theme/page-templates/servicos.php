<?php
/**
 * Template Name: Servicos
 */
get_header();
?>
<section class="page-hero">
    <div class="container">
        <nav aria-label="Breadcrumb">
            <ol style="display:flex;gap:8px;font-size:.78rem;color:rgba(255,255,255,.38);justify-content:center;margin-bottom:18px;list-style:none">
                <li><a href="<?= esc_url(home_url('/')) ?>" style="color:var(--y)">Inicio</a></li>
                <li aria-hidden>/</li><li aria-current="page">Servicos</li>
            </ol>
        </nav>
        <h1>Servicos de Transporte Executivo e Fretamento</h1>
        <p>Solucoes completas de mobilidade premium para empresas e executivos em Sao Paulo e todo o Brasil.</p>
    </div>
</section>

<?php
$servicos = [
    ['🚐','Aluguel de Van Executiva','aluguel-van-executiva',
        'A VaideVan oferece aluguel de van executiva com motorista em Sao Paulo e em mais de 49 cidades do Brasil. Nossa frota Mercedes-Benz Sprinter 415 e 516 e perfeita para transporte corporativo, eventos e turismo executivo.',
        ['Motorista profissional e uniformizado','Mercedes-Benz Sprinter 415 ou 516','Ar-condicionado de ultima geracao','Wi-Fi a bordo (opcional)','Seguro completo e viagem monitorada','Disponivel 24 horas, 7 dias por semana']],
    ['🏢','Fretamento Corporativo','fretamento-corporativo',
        'O fretamento corporativo VaideVan e a solucao ideal para empresas que precisam de transporte regular de colaboradores e executivos. Contratos mensais flexiveis com frota dedicada e gestao completa.',
        ['Contrato mensal com frota dedicada','Roteiros fixos ou variaveis','Relatorios mensais de operacao','Reducao de custos com frota propria','Motoristas treinados e checados','SLA de pontualidade garantido']],
    ['✈️','Transfer Aeroporto SP','transfer-aeroporto',
        'Transfer executivo para Aeroporto de Guarulhos (GRU), Congonhas (CGH) e Viracopos (CPQ). Monitoramos o voo em tempo real e aguardamos no desembarque com placa personalizada.',
        ['Monitoramento de voo em tempo real','Placa de identificacao personalizada','Aguardo no desembarque (up to 60min gratis)','Rota alternativa em caso de transito','Disponivel 24h todos os dias','Aeroporto GRU, CGH e Viracopos']],
    ['🛡️','Van Blindada','van-blindada',
        'Para executivos e VIPs que exigem o maximo nivel de seguranca, a VaideVan disponibiliza vans blindadas Mercedes-Benz Sprinter com blindagem nivel III-A, motorista treinado e, opcionalmente, escolta.',
        ['Blindagem nivel III-A','Motorista treinado em direcao defensiva','Rastreamento GPS em tempo real','Discricao total na operacao','Vidros e carroceria reforçados','Disponivel para contrato ou avulso']],
    ['🎪','Transporte para Eventos','transporte-eventos',
        'Fretamento de vans executivas para congressos, feiras, formaturas, casamentos, shows e eventos corporativos. Coordenamos toda a logistica de deslocamento do seu evento em Sao Paulo e interior.',
        ['Coordenacao completa da logistica','Multiplos veiculos para grandes grupos','Pontualidade comprovada em centenas de eventos','Rotas personalizadas','Suporte durante todo o evento','Orcamento especial para eventos grandes']],
    ['🌍','Turismo Corporativo','turismo-corporativo',
        'Roteiros de turismo executivo para delegacoes empresariais, clientes VIP e visitantes internacionais. Motoristas bilíngues (Ingles/Espanhol), conhecimento da cidade e discrição absoluta.',
        ['Motoristas com ingles e espanhol','Roteiros personalizados','Guia cultural disponivel','City tour executivo','Transfer entre hoteis e pontos turisticos','Atendimento VIP do inicio ao fim']],
];
?>

<?php foreach ($servicos as $i => [$ico, $titulo, $id, $desc, $features]): ?>
<section class="section-pad" id="<?= esc_attr($id) ?>" style="background:<?= $i % 2 === 0 ? 'var(--k)' : 'var(--d)' ?>">
    <div class="container">
        <div style="display:grid;grid-template-columns:<?= $i % 2 === 0 ? '1fr 1fr' : '1fr 1fr' ?>;gap:56px;align-items:center;<?= $i % 2 === 1 ? '' : '' ?>">
            <div class="<?= $i % 2 === 1 ? '' : '' ?> fade-up">
                <span class="sec-label">Servico <?= $i + 1 ?> de 6</span>
                <h2 style="font-size:clamp(1.6rem,3vw,2.3rem);font-weight:800;letter-spacing:-1px;margin-bottom:16px">
                    <?= esc_html($titulo) ?>
                </h2>
                <p style="color:rgba(255,255,255,.6);line-height:1.72;margin-bottom:24px"><?= esc_html($desc) ?></p>
                <a href="https://wa.me/5511999294694?text=Ola%2C%20tenho%20interesse%20no%20servico%20de%20<?= urlencode($titulo) ?>"
                   class="btn-y" target="_blank" rel="noopener noreferrer" style="display:inline-flex">
                   Solicitar Orcamento
                </a>
            </div>
            <div class="fade-up" style="--d:.12s">
                <div style="background:<?= $i % 2 === 0 ? 'var(--d)' : 'var(--m)' ?>;border:1px solid rgba(255,255,255,.07);border-radius:14px;padding:32px">
                    <div style="font-size:2.4rem;margin-bottom:18px" aria-hidden><?= $ico ?></div>
                    <h3 style="font-size:.84rem;font-weight:700;text-transform:uppercase;letter-spacing:1px;color:var(--y);margin-bottom:16px">Inclui</h3>
                    <ul>
                        <?php foreach ($features as $f): ?>
                        <li style="display:flex;align-items:center;gap:10px;padding:9px 0;border-bottom:1px solid rgba(255,255,255,.06);font-size:.88rem;color:rgba(255,255,255,.78)">
                            <span style="color:var(--y);font-weight:700;flex-shrink:0">&#10003;</span>
                            <?= esc_html($f) ?>
                        </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>
<?php endforeach; ?>

<section class="cta-band">
    <div class="container">
        <h2>Pronto para Contratar?</h2>
        <p>Orcamento em menos de 30 minutos. Fale diretamente com nossa equipe pelo WhatsApp.</p>
        <a href="https://wa.me/5511999294694" class="btn-k" target="_blank" rel="noopener noreferrer">Solicitar Orcamento Agora</a>
    </div>
</section>

<?php get_footer(); ?>
