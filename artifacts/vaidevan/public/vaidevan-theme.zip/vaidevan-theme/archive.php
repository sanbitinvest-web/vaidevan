<?php defined('ABSPATH') || exit; get_header(); ?>

<div class="blog-wrap">
  <div class="container">
    <div class="blog-header">
      <h1><?php the_archive_title(); ?></h1>
      <?php the_archive_description('<p>','</p>'); ?>
    </div>

    <?php if ( have_posts() ) : ?>
    <div class="posts-grid">
      <?php while ( have_posts() ) : the_post();
        $thumb = get_the_post_thumbnail_url(null, 'large')
               ?: get_post_meta(get_the_ID(), '_soro_post_image', true)
               ?: 'https://vaidevan.com/wp-content/uploads/2026/05/review-van-mercedes-executiva-vale-a-pena-featured.webp';
        $cat   = get_the_category();
        $cname = $cat ? esc_html($cat[0]->name) : 'Blog';
      ?>
      <div class="post-card post-card-item" data-cat="<?= esc_attr($cat ? $cat[0]->slug : '') ?>">
        <a href="<?php the_permalink(); ?>">
          <div class="post-thumb">
            <img src="<?= esc_url($thumb) ?>" alt="<?php the_title_attribute(); ?>" width="800" height="450" loading="lazy" decoding="async">
            <div class="post-thumb-overlay"></div>
            <span class="post-cat-sm"><?= $cname ?></span>
          </div>
          <div class="post-body">
            <h3><?php the_title(); ?></h3>
            <p class="excerpt-sm"><?php echo wp_trim_words(get_the_excerpt(), 20, '...'); ?></p>
            <div class="post-card-meta">
              <span><?php echo get_the_date('d M Y'); ?></span>
              <span style="color:var(--primary)">Ler →</span>
            </div>
          </div>
        </a>
      </div>
      <?php endwhile; ?>
    </div>
    <div class="load-more"><?php the_posts_pagination(); ?></div>
    <?php else: ?>
    <p style="text-align:center;color:rgba(255,255,255,.5);padding:64px 0">Nenhum post encontrado.</p>
    <?php endif; ?>
  </div>
</div>

<?php get_footer(); ?>
