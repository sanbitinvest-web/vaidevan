/* VaideVan — main.js | defer | sem jQuery */
(function () {
  'use strict';

  /* ================================================================
     UTILITARIO: dataLayer push seguro
     Garante que window.dataLayer existe antes de qualquer push
     ================================================================ */
  function dlPush(obj) {
    window.dataLayer = window.dataLayer || [];
    window.dataLayer.push(obj);
  }

  /* ── Mobile Menu ── */
  var tog = document.getElementById('menuTog');
  var mob = document.getElementById('mobileMenu');
  window.closeMobileMenu = function () {
    if (!mob) return;
    mob.classList.remove('open');
    mob.setAttribute('aria-hidden', 'true');
    if (tog) tog.setAttribute('aria-expanded', 'false');
  };
  if (tog && mob) {
    tog.addEventListener('click', function () {
      var open = mob.classList.toggle('open');
      mob.setAttribute('aria-hidden', String(!open));
      tog.setAttribute('aria-expanded', String(open));
    });
    document.addEventListener('click', function (e) {
      if (!mob.contains(e.target) && !tog.contains(e.target)) closeMobileMenu();
    });
  }

  /* ── Modal overlay dismiss ── */
  document.addEventListener('click', function (e) {
    if (e.target.classList.contains('vdv-modal-overlay')) {
      e.target.classList.remove('open');
    }
  });
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') {
      document.querySelectorAll('.vdv-modal-overlay.open').forEach(function (m) {
        m.classList.remove('open');
      });
    }
  });

  /* ── Hero service chips ── */
  var chips = document.querySelectorAll('.chip');
  var hidSvc = document.getElementById('heroService');
  chips.forEach(function (chip) {
    chip.addEventListener('click', function () {
      chips.forEach(function (c) { c.classList.remove('active'); });
      chip.classList.add('active');
      if (hidSvc) hidSvc.value = chip.dataset.val || chip.textContent.trim();
    });
  });

  /* ================================================================
     AJAX form helper
     Dispara eventos GTM/GA4 em conversoes de formulario
     ================================================================ */
  function sendForm(form, ajaxAction, onSuccess) {
    var data = new FormData(form);
    data.append('action', ajaxAction);
    var btn = form.querySelector('[type=submit]');
    var origLabel = btn ? btn.textContent : '';
    if (btn) { btn.disabled = true; btn.textContent = 'Enviando…'; }
    fetch(vdvData.ajaxUrl, { method: 'POST', body: data })
      .then(function (r) { return r.json(); })
      .then(function (res) {
        if (res.success) {
          /* Abre WhatsApp simultaneamente ao e-mail */
          var wha = res.data && res.data.wha_url;
          if (wha) { window.open(wha, '_blank', 'noopener,noreferrer'); }

          /* ── GTM: evento de conversao de formulario ── */
          var formId   = form.id || 'form';
          var formType = (ajaxAction === 'vdv_orcamento') ? 'orcamento' : 'contato';
          var nameEl   = form.querySelector('[name="vdv_nome"],[name="nome"]');
          var phoneEl  = form.querySelector('[name="vdv_tel"],[name="tel"]');

          dlPush({
            'event':        'form_submit',
            'form_id':      formId,
            'form_type':    formType,
            'has_whatsapp': !!wha
          });

          /* Google Ads — evento de conversao direto */
          if (typeof gtag === 'function') {
            gtag('event', 'conversion', {
              'send_to':   'AW-1526613158',
              'event_category': 'lead',
              'event_label': formType
            });
          }

          onSuccess(res);
        } else {
          alert(res.data || 'Erro ao enviar. Tente novamente.');
        }
      })
      .catch(function () { alert('Erro de rede. Tente novamente.'); })
      .finally(function () {
        if (btn) { btn.disabled = false; btn.textContent = origLabel || 'Solicitar Orçamento Grátis'; }
      });
  }

  /* ── Hero Form ── */
  var heroForm = document.getElementById('heroForm');
  if (heroForm) {
    heroForm.addEventListener('submit', function (e) {
      e.preventDefault();
      sendForm(heroForm, 'vdv_orcamento', function () {
        heroForm.style.display = 'none';
        var s = document.getElementById('heroFormSuccess');
        if (s) s.style.display = 'flex';
      });
    });
  }

  /* ── Contact Form ── */
  var contactForm = document.getElementById('contactForm');
  if (contactForm) {
    contactForm.addEventListener('submit', function (e) {
      e.preventDefault();
      var msgEl = document.getElementById('contactMsg');
      sendForm(contactForm, 'vdv_contato', function () {
        contactForm.reset();
        if (msgEl) {
          msgEl.style.display = 'block';
          msgEl.style.background = 'rgba(245,230,66,.12)';
          msgEl.style.color = '#F5E642';
          msgEl.textContent = '✓ Mensagem enviada! Retornamos em até 2 horas.';
        }
      });
    });
  }

  /* ── Quote Modal Form ── */
  var quoteForm = document.getElementById('quoteForm');
  if (quoteForm) {
    quoteForm.addEventListener('submit', function (e) {
      e.preventDefault();
      sendForm(quoteForm, 'vdv_orcamento', function () {
        quoteForm.style.display = 'none';
        var s = document.getElementById('modalSuccess');
        if (s) s.style.display = 'block';
        setTimeout(function () {
          var modal = document.getElementById('quoteModal');
          if (modal) modal.classList.remove('open');
          quoteForm.style.display = 'block';
          quoteForm.reset();
          if (s) s.style.display = 'none';
        }, 4000);
      });
    });
  }

  /* ================================================================
     RASTREAMENTO DE CLIQUES — WhatsApp, telefone e CTAs
     Dispara eventos GTM para todas as interacoes de alta intencao
     ================================================================ */

  /* Todos os links WhatsApp (wa.me e api.whatsapp.com) */
  document.querySelectorAll('a[href*="wa.me"], a[href*="whatsapp.com"]').forEach(function (el) {
    el.addEventListener('click', function () {
      var source = el.closest('[id]') ? el.closest('[id]').id : 'page';
      dlPush({
        'event':          'whatsapp_click',
        'click_source':   source,
        'click_text':     el.textContent.trim().substring(0, 50)
      });
    });
  });

  /* Cliques em numero de telefone */
  document.querySelectorAll('a[href^="tel:"]').forEach(function (el) {
    el.addEventListener('click', function () {
      dlPush({
        'event':        'phone_click',
        'phone_number': el.getAttribute('href').replace('tel:', '')
      });
    });
  });

  /* Botoes de CTA principais (hero, secao de preco, sticky) */
  document.querySelectorAll('.hero-cta-btn, .cta-btn, .sticky-cta, .btn-cta').forEach(function (el) {
    el.addEventListener('click', function () {
      dlPush({
        'event':      'cta_click',
        'cta_text':   el.textContent.trim().substring(0, 50),
        'cta_location': el.closest('section') ? (el.closest('section').id || 'section') : 'page'
      });
    });
  });

  /* Abertura do modal de orcamento */
  document.querySelectorAll('[data-modal="quoteModal"], [onclick*="quoteModal"]').forEach(function (el) {
    el.addEventListener('click', function () {
      dlPush({
        'event':        'modal_open',
        'modal_id':     'quoteModal',
        'trigger_text': el.textContent.trim().substring(0, 50)
      });
    });
  });

  /* Cliques em posts do blog (rastreia interesse em conteudo) */
  document.querySelectorAll('.post-card a[href], .post-card-item a[href]').forEach(function (el) {
    el.addEventListener('click', function () {
      var card = el.closest('[data-cat]');
      dlPush({
        'event':          'blog_click',
        'post_category':  card ? card.dataset.cat : '',
        'post_url':       el.getAttribute('href')
      });
    });
  });

  /* ── FAQ Accordion ── */
  document.querySelectorAll('.faq-q').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var item = btn.closest('.faq-item');
      var isOpen = item.classList.contains('open');
      document.querySelectorAll('.faq-item.open').forEach(function (i) {
        i.classList.remove('open');
        i.querySelector('.faq-q').setAttribute('aria-expanded', 'false');
      });
      if (!isOpen) {
        item.classList.add('open');
        btn.setAttribute('aria-expanded', 'true');
      }
    });
  });

  /* ── Stats counter animation ── */
  function animateCounters() {
    document.querySelectorAll('.stat-value[data-target]').forEach(function (el) {
      var target = parseInt(el.dataset.target, 10);
      var suffix = el.dataset.suffix || '';
      var duration = 1800;
      var start = null;
      function step(ts) {
        if (!start) start = ts;
        var progress = Math.min((ts - start) / duration, 1);
        var ease = 1 - Math.pow(1 - progress, 3);
        el.textContent = Math.round(ease * target) + suffix;
        if (progress < 1) requestAnimationFrame(step);
      }
      requestAnimationFrame(step);
    });
  }

  /* ── Scroll Reveal (IntersectionObserver) ── */
  function initReveal() {
    var reveals = document.querySelectorAll('.vv-reveal-up, .vv-reveal-left, .vv-reveal-right, .vv-reveal-scale');
    if (!('IntersectionObserver' in window)) {
      reveals.forEach(function (el) { el.classList.add('vv-in'); });
      return;
    }
    var obs = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add('vv-in');
          obs.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12 });
    reveals.forEach(function (el) { obs.observe(el); });
  }

  /* ── Stats reveal (trigger once visible) ── */
  var statsBar = document.getElementById('stats-bar');
  var statsAnimated = false;
  if (statsBar && 'IntersectionObserver' in window) {
    new IntersectionObserver(function (entries) {
      if (entries[0].isIntersecting && !statsAnimated) {
        statsAnimated = true;
        animateCounters();
      }
    }, { threshold: 0.3 }).observe(statsBar);
  }

  /* ── Blog category filter ── */
  var catBtns = document.querySelectorAll('.cat-btn');
  var postCards = document.querySelectorAll('.post-card-item');
  catBtns.forEach(function (btn) {
    btn.addEventListener('click', function () {
      catBtns.forEach(function (b) { b.classList.remove('active'); });
      btn.classList.add('active');
      var cat = btn.dataset.cat || 'all';
      postCards.forEach(function (card) {
        if (cat === 'all' || card.dataset.cat === cat) {
          card.style.display = '';
        } else {
          card.style.display = 'none';
        }
      });
    });
  });

  /* ── Active nav link ── */
  var navLinks = document.querySelectorAll('.main-nav a');
  var sections = document.querySelectorAll('section[id]');
  if ('IntersectionObserver' in window) {
    var secObs = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          var id = entry.target.id;
          navLinks.forEach(function (l) {
            l.classList.toggle('active', l.getAttribute('href').endsWith('#' + id));
          });
        }
      });
    }, { threshold: 0.4 });
    sections.forEach(function (s) { secObs.observe(s); });
  }

  /* ── Partner Form (AJAX) ── */
  var partnerForm = document.getElementById('partnerForm');
  if (partnerForm) {
    partnerForm.addEventListener('submit', function (e) {
      e.preventDefault();
      var btn = document.getElementById('partnerSubmitBtn');
      if (btn) { btn.disabled = true; btn.textContent = 'Enviando...'; }
      var data = new FormData(partnerForm);
      data.append('action', 'vdv_parceiro');
      fetch(typeof vdvAjax !== 'undefined' ? vdvAjax.url : '/wp-admin/admin-ajax.php', {
        method: 'POST',
        body: data
      })
        .then(function (r) { return r.json(); })
        .then(function (res) {
          if (res.success) {
            partnerForm.style.display = 'none';
            var ok = document.getElementById('partnerSuccess');
            if (ok) ok.style.display = 'block';
            if (res.data && res.data.wha_url) {
              setTimeout(function () { window.open(res.data.wha_url, '_blank'); }, 600);
            }
            dlPush({ 'event': 'partner_signup', 'tipo': data.get('tipo') });
          } else {
            alert(res.data || 'Erro ao enviar. Tente novamente.');
            if (btn) { btn.disabled = false; btn.textContent = 'Enviar Cadastro'; }
          }
        })
        .catch(function () {
          alert('Erro de conexão. Tente novamente.');
          if (btn) { btn.disabled = false; btn.textContent = 'Enviar Cadastro'; }
        });
    });
  }

  /* Fechar modais com Escape */
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') {
      document.querySelectorAll('.vdv-modal-overlay.open').forEach(function (m) {
        m.classList.remove('open');
      });
    }
  });

  /* ── Init ── */
  initReveal();

})();
