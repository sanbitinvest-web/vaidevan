<?php
/**
 * Template Name: Portal do Investidor
 */
defined('ABSPATH') || exit;
get_header();
echo do_shortcode('[vdv_portal]');
get_footer();
