<?php
/**
 * Theme Setup — Menus, Features, CPTs, Widgets
 */
defined('ABSPATH') || exit;

add_action('after_setup_theme', function () {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('html5', ['search-form','comment-form','comment-list','gallery','caption','script','style']);
    add_theme_support('responsive-embeds');
    add_theme_support('custom-logo');
    add_theme_support('automatic-feed-links');
    /* Tamanhos de imagem */
    add_image_size('vdv-card',  560, 320, true);
    add_image_size('vdv-hero', 1440, 800, true);
    add_image_size('vdv-thumb', 400, 260, true);
    /* Menus */
    register_nav_menus([
        'primary'  => 'Menu Principal',
        'footer'   => 'Menu Rodape',
        'services' => 'Menu Servicos',
    ]);
});

/* ---- CPT: Frota ---- */
add_action('init', function () {
    register_post_type('vdv_frota', [
        'labels'       => ['name'=>'Frota','singular_name'=>'Veiculo','add_new_item'=>'Adicionar Veiculo','edit_item'=>'Editar Veiculo'],
        'public'       => false,
        'show_ui'      => true,
        'show_in_menu' => true,
        'menu_icon'    => 'dashicons-car',
        'supports'     => ['title','editor','thumbnail','custom-fields'],
        'show_in_rest' => true,
    ]);

    /* CPT: Servicos */
    register_post_type('vdv_servico', [
        'labels'       => ['name'=>'Servicos','singular_name'=>'Servico','add_new_item'=>'Adicionar Servico'],
        'public'       => false,
        'show_ui'      => true,
        'show_in_menu' => true,
        'menu_icon'    => 'dashicons-location-alt',
        'supports'     => ['title','editor','thumbnail','excerpt'],
        'show_in_rest' => true,
    ]);
}, 0);

/* ---- Thumbnail por defeito para posts sem imagem ---- */
add_filter('post_thumbnail_html', function ($html) {
    if (!$html) {
        return '<div style="width:100%;height:100%;background:#1a1a1a;display:flex;align-items:center;justify-content:center;font-size:2rem">🚐</div>';
    }
    return $html;
});

/* ---- Paginas amostra no primeiro acesso ---- */
add_action('after_switch_theme', 'vdv_create_sample_pages');
function vdv_create_sample_pages() {
    $paginas = [
        ['Inicio',   'front-page',                    null],
        ['Sobre',    'page-templates/sobre.php',      'sobre'],
        ['Servicos', 'page-templates/servicos.php',   'servicos'],
        ['Frota',    'page-templates/frota.php',      'frota'],
        ['Contato',  'page-templates/contato.php',    'contato'],
        ['Portal',   'page-templates/portal.php',     'portal'],
        ['Blog',     null,                             'blog'],
    ];
    $front_id = 0;
    $blog_id  = 0;
    foreach ($paginas as [$titulo, $template, $slug]) {
        if (get_page_by_title($titulo)) { continue; }
        $args = ['post_title'=>$titulo,'post_status'=>'publish','post_type'=>'page','post_name'=>$slug ?? sanitize_title($titulo)];
        $id = wp_insert_post($args);
        if (!$id || is_wp_error($id)) { continue; }
        /* wp_insert_post nao salva page_template como meta — fazer manualmente */
        if ($template && $template !== 'front-page') {
            update_post_meta($id, '_wp_page_template', $template);
        }
        if ($titulo === 'Inicio') { $front_id = $id; }
        if ($titulo === 'Blog')   { $blog_id  = $id; }
    }
    if ($front_id) {
        update_option('page_on_front', $front_id);
        update_option('show_on_front', 'page');
    }
    if ($blog_id) { update_option('page_for_posts', $blog_id); }

    /* Posts de blog de amostra */
    vdv_create_sample_posts();
}

function vdv_create_sample_posts() {
    $posts = [
        ['Como escolher a van executiva ideal para sua empresa',
         'Descubra os criterios essenciais para selecionar a melhor van executiva para transporte corporativo em Sao Paulo: capacidade, conforto, custo-beneficio e suporte ao cliente.',
         '<p>Escolher a van executiva certa para sua empresa pode fazer toda a diferenca na experiencia dos seus colaboradores e clientes. Neste guia completo, apresentamos os principais pontos a considerar.</p><h2>1. Capacidade de Passageiros</h2><p>As vans executivas Mercedes-Benz Sprinter estao disponiveis nas versoes 415 (15 lugares) e 516 (19 lugares). Avalie quantos passageiros precisam ser transportados regularmente para escolher o modelo ideal.</p><h2>2. Nivel de Conforto</h2><p>Para executivos e clientes VIP, o conforto e essencial. A VaideVan oferece vans com ar-condicionado, poltronas reclinaveis, iluminacao de LED e WiFi a bordo.</p><h2>3. Seguranca</h2><p>Todos os nossos veiculos passam por revisao periodica e possuem seguro completo. Para maior seguranca, oferecemos tambem a opcao de van blindada.</p><h2>4. Flexibilidade de Contrato</h2><p>Oferecemos contratos mensais de fretamento, alugueis por diaria e servicos avulsos por demanda. Escolha o modelo que melhor se encaixa no orcamento e na rotina da sua empresa.</p>'],
        ['Transfer Aeroporto SP: Como Funciona o Servico VaideVan',
         'Saiba como funciona o servico de transfer executivo para os aeroportos de Guarulhos (GRU) e Congonhas (CGH) com a VaideVan. Pontualidade e conforto garantidos.',
         '<p>O servico de transfer executivo para aeroportos e um dos mais procurados pela VaideVan. Entenda como funciona e por que somos a melhor opcao.</p><h2>Aeroporto de Guarulhos (GRU)</h2><p>Com nosso servico dedicado para o Aeroporto Internacional de Guarulhos, voce garante uma viagem confortavel e pontual, independente do horario do voo. Monitoramos todos os voos em tempo real para nos adaptarmos a eventuais atrasos.</p><h2>Aeroporto de Congonhas (CGH)</h2><p>Para Congonhas, operamos com vans executivas que conhecem os melhores acessos e rotas alternativas para garantir sua chegada no tempo certo.</p><h2>Como Agendar</h2><p>O agendamento e simples: entre em contato pelo WhatsApp, informe data, horario e numero de passageiros. Confirmamos em ate 30 minutos.</p>'],
        ['Vantagens do Fretamento Corporativo de Van Executiva em SP',
         'Entenda por que empresas como a sua estao migrando para o fretamento corporativo de van executiva em Sao Paulo. Economia, eficiencia e imagem profissional.',
         '<p>O fretamento corporativo de van executiva tem crescido exponencialmente entre empresas de medio e grande porte em Sao Paulo. Veja por que essa e a solucao ideal.</p><h2>Reducao de Custos</h2><p>Ao terceirizar o transporte para a VaideVan, sua empresa elimina custos com manutencao de frota propria, seguro, IPVA e depreciacao dos veiculos.</p><h2>Produtividade</h2><p>Colaboradores que chegam ao trabalho sem o estresse do transito chegam mais produtivos. O ambiente confortavel das nossas vans permite que o tempo de deslocamento seja utilizado para trabalho ou descanso.</p><h2>Imagem Corporativa</h2><p>Receber clientes e parceiros em uma van executiva de alto padrao transmite profissionalismo e cuidado com os detalhes, reforçando a imagem da sua empresa.</p>'],
    ];
    $cat = get_category_by_slug('transporte-executivo');
    if (!$cat) {
        $cat_id = wp_insert_term('Transporte Executivo', 'category', ['slug'=>'transporte-executivo']);
        $cat_id = is_wp_error($cat_id) ? 1 : $cat_id['term_id'];
    } else {
        $cat_id = $cat->term_id;
    }
    foreach ($posts as [$titulo, $excerpt, $content]) {
        if (get_page_by_title($titulo, OBJECT, 'post')) { continue; }
        wp_insert_post([
            'post_title'   => $titulo,
            'post_excerpt' => $excerpt,
            'post_content' => $content,
            'post_status'  => 'publish',
            'post_type'    => 'post',
            'post_category'=> [$cat_id],
        ]);
    }
}
