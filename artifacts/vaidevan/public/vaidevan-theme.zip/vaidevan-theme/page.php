<?php get_header(); the_post(); ?>
<section class="page-hero">
    <div class="container">
        <h1><?= get_the_title() ?></h1>
    </div>
</section>
<section class="section-pad" style="background:var(--k)">
    <div class="container" style="max-width:800px">
        <div class="entry-content"><?php the_content(); ?></div>
    </div>
</section>
<?php get_footer(); ?>
