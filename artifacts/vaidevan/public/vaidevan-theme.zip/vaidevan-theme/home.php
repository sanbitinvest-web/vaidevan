<?php
/**
 * home.php — Blog listing page
 * Visual: matches vaidevan.com/blog (React SPA design)
 */
defined('ABSPATH') || exit;
if (is_front_page() && !is_home()) { include get_template_directory().'/front-page.php'; exit; }
get_header();

$WA = 'https://wa.me/5511999294694?text=Ol%C3%A1!%20Gostaria%20de%20solicitar%20um%20or%C3%A7amento.';

/* Collect all categories from published posts */
$all_posts_query = new WP_Query(['posts_per_page'=>-1,'post_status'=>'publish','post_type'=>'post','no_found_rows'=>true,'update_post_meta_cache'=>false]);
$all_cats = [];
if ($all_posts_query->have_posts()) {
    while ($all_posts_query->have_posts()) {
        $all_posts_query->the_post();
        foreach (get_the_category() as $c) $all_cats[$c->slug] = $c->name;
    }
}
wp_reset_postdata();

/* Main query: newest first */
$q = new WP_Query(['posts_per_page'=>50,'post_status'=>'publish','post_type'=>'post','orderby'=>'date','order'=>'DESC']);
?>

<div class="blog-wrap">
  <div class="container">

    <!-- Page header -->
    <div class="blog-header">
      <span class="blog-label">Conteúdo especializado</span>
      <h1>Blog VaideVan — Transporte Executivo</h1>
      <p>Dicas, guias e informações sobre transporte executivo, fretamento corporativo e mobilidade urbana.</p>
    </div>

    <!-- Category filter -->
    <div class="blog-cats">
      <button class="blog-cat-btn active" data-cat="todos" onclick="filterPosts('todos')">
        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" style="vertical-align:-2px;margin-right:4px" aria-hidden="true"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/></svg>
        Todos
      </button>
      <?php foreach ($all_cats as $slug => $name): ?>
      <button class="blog-cat-btn" data-cat="<?= esc_attr($slug) ?>" onclick="filterPosts('<?= esc_js($slug) ?>')"><?= esc_html($name) ?></button>
      <?php endforeach; ?>
    </div>

    <?php if ($q->have_posts()):
      /* ── FEATURED POST ── */
      $q->the_post();
      $f_img   = get_post_meta(get_the_ID(), '_soro_post_image', true)
               ?: (get_the_post_thumbnail_url(null,'large') ?: 'https://vaidevan.com/wp-content/uploads/2026/05/review-van-mercedes-executiva-vale-a-pena-featured.webp');
      $f_cats  = get_the_category();
      $f_cname = $f_cats ? esc_html($f_cats[0]->name) : 'Blog';
      $f_cslug = $f_cats ? esc_attr($f_cats[0]->slug) : 'blog';
      $f_mins  = max(1,(int)round(str_word_count(strip_tags(get_the_content()))/200));
    ?>

    <!-- Featured post -->
    <article class="blog-featured" data-cat="<?= $f_cslug ?>">
      <a href="<?php the_permalink(); ?>" class="featured-card">
        <div class="featured-img-wrap">
          <img src="<?= esc_url($f_img) ?>" alt="<?php the_title_attribute(); ?>" width="1400" height="700" loading="eager">
          <div class="featured-img-overlay"></div>
          <span class="post-cat-badge">
            <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" style="vertical-align:-1px;margin-right:3px" aria-hidden="true"><path d="M20.59 13.41l-7.17 7.17a2 2 0 01-2.83 0L2 12V2h10l8.59 8.59a2 2 0 010 2.82z"/><line x1="7" y1="7" x2="7.01" y2="7"/></svg>
            <?= $f_cname ?>
          </span>
        </div>
        <div class="featured-body">
          <div class="post-meta">
            <span class="post-meta-icon">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
              <?php echo get_the_date('d \d\e F \d\e Y'); ?>
            </span>
            <span class="post-meta-icon">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
              <?= $f_mins ?> min de leitura
            </span>
          </div>
          <h2><?php the_title(); ?></h2>
          <p class="excerpt"><?php echo wp_trim_words(get_the_excerpt(), 35, '...'); ?></p>
          <span class="read-more">
            Ler artigo completo
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
          </span>
        </div>
      </a>
    </article>

    <?php if ($q->have_posts()): ?>
    <!-- Post grid (3 columns) -->
    <div class="posts-grid" id="postsGrid">
      <?php while ($q->have_posts()): $q->the_post();
        $thumb = get_post_meta(get_the_ID(), '_soro_post_image', true)
               ?: (get_the_post_thumbnail_url(null,'medium_large') ?: 'https://vaidevan.com/wp-content/uploads/2026/04/transporte-corporativo-com-padrao-executivo-featured.webp');
        $pcat  = get_the_category();
        $cname = $pcat ? esc_html($pcat[0]->name) : 'Blog';
        $cslug = $pcat ? esc_attr($pcat[0]->slug) : 'blog';
        $mins  = max(1,(int)round(str_word_count(strip_tags(get_the_content()))/200));
      ?>
      <article class="post-card post-card-item" data-cat="<?= $cslug ?>">
        <a href="<?php the_permalink(); ?>">
          <div class="post-thumb">
            <img src="<?= esc_url($thumb) ?>" alt="<?php the_title_attribute(); ?>" width="800" height="450" loading="lazy" decoding="async">
            <div class="post-thumb-overlay"></div>
            <span class="post-cat-sm"><?= $cname ?></span>
          </div>
          <div class="post-body">
            <h3><?php the_title(); ?></h3>
            <p class="excerpt-sm"><?php echo wp_trim_words(get_the_excerpt(), 18, '...'); ?></p>
            <div class="post-card-meta">
              <span class="post-meta-icon">
                <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
                <?php echo get_the_date('d M Y'); ?>
              </span>
              <span class="post-meta-icon" style="color:rgba(255,255,255,.3)">
                <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
                <?= $mins ?> min
              </span>
            </div>
          </div>
        </a>
      </article>
      <?php endwhile; ?>
    </div>
    <?php endif; wp_reset_postdata(); ?>

    <?php else: ?>
    <p style="text-align:center;color:rgba(255,255,255,.5);padding:80px 0">Nenhum artigo encontrado.</p>
    <?php endif; ?>

  </div>
</div>

<script>
(function(){
  function filterPosts(cat){
    document.querySelectorAll('.blog-cat-btn').forEach(function(b){
      b.classList.toggle('active', b.dataset.cat === cat);
    });
    var featured = document.querySelector('.blog-featured');
    var items = document.querySelectorAll('.post-card-item');
    if(cat === 'todos'){
      if(featured) featured.style.display = '';
      items.forEach(function(el){ el.style.display = ''; });
      return;
    }
    if(featured) featured.style.display = featured.dataset.cat === cat ? '' : 'none';
    items.forEach(function(el){ el.style.display = el.dataset.cat === cat ? '' : 'none'; });
  }
  window.filterPosts = filterPosts;
})();
</script>

<?php get_footer(); ?>
