<?php get_header(); ?>
<section class="page-hero" style="min-height:70vh;display:flex;align-items:center;justify-content:center;text-align:center">
    <div class="container">
        <div style="font-size:5rem;font-weight:900;color:var(--y);margin-bottom:8px">404</div>
        <h1 style="font-size:2rem;margin-bottom:14px">Pagina Nao Encontrada</h1>
        <p style="color:rgba(255,255,255,.5);margin-bottom:28px">A pagina que voce procura foi removida ou nao existe.</p>
        <a href="<?= esc_url(home_url('/')) ?>" class="btn-y">Voltar ao Inicio</a>
    </div>
</section>
<?php get_footer(); ?>
