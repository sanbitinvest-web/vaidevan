<?php
/**
 * VaideVan — Google Tag Manager + GA4 + Google Ads
 *
 * GTM Container : GTM-WPS2QGFK
 * GA4 Tag       : GT-NFJ5PLCX
 * Google Ads    : AW-1526613158
 *
 * Estrutura:
 *  1. GTM <head> snippet  (prioridade 1 — o mais alto possivel no <head>)
 *  2. GTM <noscript> iframe  (logo apos <body> via wp_body_open)
 *  3. gtag.js direto  (GA4 + Google Ads, igual ao site atual)
 *  4. dataLayer page context  (tipo de pagina, titulo, URL)
 */
defined('ABSPATH') || exit;

/* ================================================================
   1. GTM — snippet <head>
   Deve ser o primeiro script do <head>, antes de qualquer CSS/JS
   ================================================================ */
add_action('wp_head', function () {
    ?>
<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-WPS2QGFK');</script>
<!-- End Google Tag Manager -->
    <?php
}, 1); /* prioridade 1 = primeiro hook wp_head */

/* ================================================================
   2. GTM — noscript <body>
   Deve ser a primeira tag apos <body> para usuarios sem JavaScript
   ================================================================ */
add_action('wp_body_open', function () {
    ?>
<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-WPS2QGFK"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
    <?php
}, 1);

/* ================================================================
   3. gtag.js — GA4 (GT-NFJ5PLCX) + Google Ads (AW-1526613158)
   Carregado de forma assincrona, nao bloqueia renderizacao
   ================================================================ */
add_action('wp_head', function () {
    ?>
<!-- Google tag (gtag.js) — GA4 + Google Ads -->
<script async src="https://www.googletagmanager.com/gtag/js?id=GT-NFJ5PLCX"></script>
<script>
window.dataLayer = window.dataLayer || [];
function gtag(){dataLayer.push(arguments);}
gtag('js', new Date());
/* GA4 */
gtag('config', 'GT-NFJ5PLCX', {
    'linker': { 'domains': ['vaidevan.com'] },
    'send_page_view': true
});
/* Google Ads — rastreamento de conversoes */
gtag('config', 'AW-1526613158');
</script>
<!-- End Google tag -->
    <?php
}, 2);

/* ================================================================
   4. dataLayer — contexto de pagina (tipo, titulo, URL)
   Empurrado antes de qualquer evento para segmentacao no GTM
   ================================================================ */
add_action('wp_head', function () {
    global $post;

    if (is_front_page())       { $page_type = 'home'; }
    elseif (is_single())       { $page_type = 'blog_post'; }
    elseif (is_home())         { $page_type = 'blog_listing'; }
    elseif (is_page('portal')) { $page_type = 'investor_portal'; }
    elseif (is_page())         { $page_type = 'page'; }
    else                       { $page_type = 'archive'; }

    $post_title    = ($post ? esc_js(get_the_title($post)) : '');
    $post_category = '';
    if (is_single() && $post) {
        $cats = get_the_category($post->ID);
        if ($cats) $post_category = esc_js($cats[0]->name);
    }
    $canonical_url = esc_js(wp_get_canonical_url() ?: home_url(add_query_arg(null, null)));
    ?>
<script>
window.dataLayer = window.dataLayer || [];
dataLayer.push({
    'event':         'page_context',
    'pageType':      '<?= $page_type ?>',
    'pageTitle':     '<?= $post_title ?>',
    'pageCategory':  '<?= $post_category ?>',
    'pageUrl':       '<?= $canonical_url ?>'
});
</script>
    <?php
}, 3);

/* ================================================================
   5. Evento de conversao Google Ads ao enviar formulario (server-side push)
   O JS em main.js tambem dispara eventos client-side via dataLayer
   ================================================================ */
/* Eventos client-side estao em assets/js/main.js (dataLayer.push) */
