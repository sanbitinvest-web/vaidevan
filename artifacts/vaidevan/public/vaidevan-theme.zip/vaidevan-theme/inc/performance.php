<?php
/**
 * Performance — PageSpeed 90+ / GTmetrix A
 * Strategy:
 *   FCP/LCP: preload logo woff2 binary early; fonts never block render
 *   CLS:     font-display:optional — no swap after first paint → zero font CLS
 *   TBT:     already 0ms (no render-blocking JS)
 */
defined('ABSPATH') || exit;

/* ----------------------------------------------------------------
   1. REMOVE BLOAT
   ---------------------------------------------------------------- */
add_action('init', function () {
    remove_action('wp_head', 'print_emoji_detection_script', 7);
    remove_action('wp_print_styles', 'print_emoji_styles');
    remove_action('wp_head', 'wp_oembed_add_discovery_links');
    remove_action('wp_head', 'rest_output_link_wp_head');
    remove_action('wp_head', 'wp_generator');
    remove_action('wp_head', 'wlwmanifest_link');
    remove_action('wp_head', 'rsd_link');
    remove_action('wp_head', 'feed_links_extra', 3);
    add_filter('wp_resource_hints', function ($hints, $relation) {
        if ($relation === 'dns-prefetch') {
            foreach ($hints as $k => $h) {
                $href = $h['href'] ?? '';
                if (strpos($href, 'wp.com') !== false || strpos($href, 's.w.org') !== false) {
                    unset($hints[$k]);
                }
            }
        }
        return $hints;
    }, 10, 2);
});

/* ----------------------------------------------------------------
   2A. PRELOAD LCP IMAGE — absolute first in <head>
   Goal: browser starts fetching logo + hero-bg before anything else
   ---------------------------------------------------------------- */
add_action('wp_head', function () {
    $uri = get_template_directory_uri();
    /* Logo (LCP on all pages) — WebP moderno, JPG fallback via <picture> no HTML */
    echo '<link rel="preload" as="image" href="' . esc_url($uri) . '/assets/images/logo-dark.webp" fetchpriority="high" type="image/webp">' . "\n";
}, 1); /* priority 1 = very first output */

/* ----------------------------------------------------------------
   2B. ALL CSS INLINE — zero network round-trip, zero FOUC
   Inlining both critical + main eliminates the deferred-CSS
   flash-of-unstyled-content that occurs when the user scrolls
   before the external file loads. Total inline cost ~33 KB
   (compressed ~8 KB) vs two separate requests + server RTT.
   ---------------------------------------------------------------- */
add_action('wp_head', function () {
    $dir = get_template_directory();
    $uri = get_template_directory_uri();
    $css = '';
    foreach (['/assets/css/critical.css', '/assets/css/main.css'] as $f) {
        if (file_exists($dir . $f)) {
            $css .= file_get_contents($dir . $f);
        }
    }
    if ($css) {
        $css = str_replace("url('../images/", "url('" . $uri . "/assets/images/", $css);
        echo '<style id="vdv-all-css">' . $css . '</style>' . "\n";
    }
}, 3);

/* ----------------------------------------------------------------
   2C. FONTS — display:optional eliminates CLS from font-swap
   - preconnect lets TLS handshake happen early
   - preload the Bebas Neue woff2 binary directly so it arrives
     within the ~100ms optional window on most connections
   - NO rel="preload" as="style" for the CSS — that competes
     with the LCP image download
   ---------------------------------------------------------------- */
add_action('wp_head', function () {
    /* DNS-prefetch + Preconnect — Google Tag Manager / GA4 / Google Ads */
    echo '<link rel="dns-prefetch" href="https://www.googletagmanager.com">' . "\n";
    echo '<link rel="dns-prefetch" href="https://www.google-analytics.com">' . "\n";
    echo '<link rel="dns-prefetch" href="https://stats.g.doubleclick.net">' . "\n";
    echo '<link rel="preconnect" href="https://www.googletagmanager.com">' . "\n";

    /* Preconnect — Google Fonts */
    echo '<link rel="preconnect" href="https://fonts.googleapis.com">' . "\n";
    echo '<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>' . "\n";

    /* Preload Bebas Neue woff2 binary (Latin subset, ~20 KB)
       This gives it priority = same level as LCP, arrives fast */
    echo '<link rel="preload" as="font" type="font/woff2"
         href="https://fonts.gstatic.com/s/bebasneue/v10/JTUSjIg69CK48gW7PXoo9WlhyyTh89Y.woff2"
         crossorigin>' . "\n";

    /* Deferred font CSS — display=optional means NO swap after paint
       (browser uses font if ready in <100ms, else keeps system font) */
    $font_url = 'https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Inter:wght@400;500;600;700;800;900&family=Playfair+Display:ital@1&family=Syne:wght@700;800;900&display=optional';
    echo '<link rel="stylesheet" href="' . esc_url($font_url) . '" media="print" onload="this.media=\'all\'">' . "\n";
    echo '<noscript><link rel="stylesheet" href="' . esc_url($font_url) . '"></noscript>' . "\n";
}, 4);

/* 2D. main.css is now inlined in 2B — no external request needed */

/* ----------------------------------------------------------------
   3. DEQUEUE UNUSED WP STYLES
   ---------------------------------------------------------------- */
add_action('wp_enqueue_scripts', function () {
    wp_dequeue_style('wp-block-library');
    wp_dequeue_style('wp-block-library-theme');
    wp_dequeue_style('classic-theme-styles');
    wp_dequeue_style('global-styles');
}, 100);

/* ----------------------------------------------------------------
   4. ENQUEUE ONLY WHAT IS NEEDED
   ---------------------------------------------------------------- */
add_action('wp_enqueue_scripts', function () {
    $v   = '2.1.0';
    $uri = get_template_directory_uri();

    /* Portal: CSS + JS only on portal page */
    $is_portal = is_page_template('page-templates/portal.php') || is_page('portal');
    if ($is_portal) {
        wp_enqueue_style('vdv-portal', $uri . '/assets/css/portal.css', [], $v);
        wp_enqueue_script('vdv-portal', $uri . '/assets/js/portal.js', [], $v, true);
        wp_localize_script('vdv-portal', 'vdvPortal', [
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce'   => wp_create_nonce('vdv_portal_nonce'),
        ]);
        return;
    }

    /* i18n — 4 idiomas (PT/EN/ES/ZH) — enqueue no head, antes do DOM montar */
    wp_enqueue_script('vdv-i18n', $uri . '/assets/js/i18n.js', [], $v, false);

    /* Main JS — deferred */
    wp_enqueue_script('vdv-main', $uri . '/assets/js/main.js', [], $v, true);
    wp_script_add_data('vdv-main', 'defer', true);
    wp_localize_script('vdv-main', 'vdvData', [
        'ajaxUrl' => admin_url('admin-ajax.php'),
        'nonce'   => wp_create_nonce('vdv_orcamento'),
    ]);
}, 10);

/* ---- Add defer attribute via filter ---- */
add_filter('script_loader_tag', function ($tag, $handle) {
    if (wp_scripts()->get_data($handle, 'defer') && !is_admin()) {
        return str_replace(' src=', ' defer src=', $tag);
    }
    return $tag;
}, 10, 2);

/* ---- Remove query string from assets (better CDN cache) ---- */
add_filter('style_loader_src',  'vdv_remove_ver', 9999);
add_filter('script_loader_src', 'vdv_remove_ver', 9999);
function vdv_remove_ver($src) {
    if (!is_admin() && strpos($src, 'ver=') !== false) {
        $src = remove_query_arg('ver', $src);
    }
    return $src;
}

/* ---- Kill Gutenberg CSS on front-end ---- */
add_filter('should_load_separate_core_block_assets', '__return_false');
add_filter('styles_for_block_editor', '__return_false');

/* ---- Heartbeat only in admin ---- */
add_filter('heartbeat_settings', function ($settings) {
    if (!is_admin()) { $settings['interval'] = 60; }
    return $settings;
});

/* ----------------------------------------------------------------
   5. OUTPUT BUFFER — lazy images + dimension hints
   ---------------------------------------------------------------- */
add_action('template_redirect', function () {
    if (is_admin() || is_page_template('page-templates/portal.php')) { return; }
    ob_start('vdv_optimize_output');
});

function vdv_optimize_output($html) {
    /* Add lazy/eager loading to images that lack it */
    $html = preg_replace_callback('/<img([^>]+)>/i', function ($m) {
        $tag = $m[0];
        if (strpos($tag, 'loading=') !== false) { return $tag; }
        /* LCP candidates — eager + high priority */
        if (strpos($tag, 'hero-logo') !== false || strpos($tag, 'lcp-') !== false || strpos($tag, 'logo-white') !== false) {
            return str_replace('<img', '<img loading="eager" fetchpriority="high"', $tag);
        }
        return str_replace('<img', '<img loading="lazy" decoding="async"', $tag);
    }, $html);

    /* Inline size-adjust for Bebas Neue fallback — inject once into <head>
       Arial Narrow is the closest system font; size-adjust ~90% compensates
       This ensures system-font layout ≈ Bebas Neue layout → near-zero CLS */
    $size_adjust = '<style id="vdv-font-fallback">
@font-face{font-family:"Bebas Neue";src:local("Arial Narrow Bold"),local("ArialNarrow-Bold");font-style:normal;font-weight:400;size-adjust:82%;ascent-override:115%;descent-override:5%;line-gap-override:0%}
</style>';
    $html = str_replace('</head>', $size_adjust . '</head>', $html);

    return $html;
}

/* ----------------------------------------------------------------
   6. SITEMAP XML
   ---------------------------------------------------------------- */
add_action('init', function () {
    if (!function_exists('wpseo_init') && isset($_SERVER['REQUEST_URI']) &&
        strpos($_SERVER['REQUEST_URI'], '/sitemap.xml') !== false) {
        vdv_output_sitemap();
        exit;
    }
});

function vdv_output_sitemap() {
    header('Content-Type: application/xml; charset=UTF-8');
    $home  = home_url('/');
    $pages = get_pages(['post_status' => 'publish']);
    $posts = get_posts(['numberposts' => 50, 'post_status' => 'publish', 'fields' => 'all']);
    echo '<?xml version="1.0" encoding="UTF-8"?>';
    echo '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"
              xmlns:image="http://www.google.com/schemas/sitemap-image/1.1">';
    echo '<url><loc>' . esc_url($home) . '</loc><changefreq>weekly</changefreq><priority>1.0</priority></url>';
    $excluir = ['portal', 'wp-sitemap'];
    foreach ($pages as $p) {
        if (in_array($p->post_name, $excluir)) { continue; }
        echo '<url><loc>' . esc_url(get_permalink($p->ID)) . '</loc><changefreq>monthly</changefreq><priority>0.8</priority></url>';
    }
    foreach ($posts as $p) {
        $img = get_the_post_thumbnail_url($p->ID, 'large');
        echo '<url><loc>' . esc_url(get_permalink($p->ID)) . '</loc><changefreq>monthly</changefreq><priority>0.6</priority>';
        if ($img) {
            echo '<image:image><image:loc>' . esc_url($img) . '</image:loc>'
               . '<image:title>' . esc_html(get_the_title($p->ID)) . '</image:title></image:image>';
        }
        echo '</url>';
    }
    echo '</urlset>';
}

/* ----------------------------------------------------------------
   7. ROBOTS.TXT
   ---------------------------------------------------------------- */
add_filter('robots_txt', function ($output, $public) {
    $output  = "User-agent: *\n";
    $output .= "Allow: /\n";
    $output .= "Disallow: /wp-admin/\n";
    $output .= "Disallow: /wp-login.php\n";
    $output .= "Disallow: /portal/\n";
    $output .= "Disallow: /?s=\n";
    $output .= "Sitemap: " . home_url('/sitemap.xml') . "\n";
    $output .= "\nUser-agent: GPTBot\nAllow: /\n";
    $output .= "\nUser-agent: Google-Extended\nAllow: /\n";
    $output .= "\nUser-agent: PerplexityBot\nAllow: /\n";
    $output .= "\nUser-agent: ClaudeBot\nAllow: /\n";
    return $output;
}, 10, 2);
