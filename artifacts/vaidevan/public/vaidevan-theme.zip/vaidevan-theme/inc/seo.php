<?php
/**
 * SEO Avancado — Meta tags, Open Graph, Twitter Cards, Canonical
 * Targetando: aluguel van executiva SP, fretamento, blindado, transfer
 */
defined('ABSPATH') || exit;

/* Remove tags de head desnecessarias */
remove_action('wp_head', 'wp_generator');
remove_action('wp_head', 'wlwmanifest_link');
remove_action('wp_head', 'rsd_link');
remove_action('wp_head', 'wp_shortlink_wp_head');
remove_action('wp_head', 'adjacent_posts_rel_link_wp_head');
remove_action('wp_head', 'feed_links_extra', 3);
remove_action('wp_head', 'print_emoji_detection_script', 7);
remove_action('wp_print_styles', 'print_emoji_styles');
/* Remove WordPress built-in site_icon — usamos nossas próprias tags de favicon */
remove_action('wp_head', 'wp_site_icon', 99);

/* ---- SEO por pagina ---- */
function vdv_page_seo() {
    global $post;
    $sep   = ' | ';
    $brand = 'VaideVan Transporte Executivo';
    $home  = home_url('/');
    $img   = get_template_directory_uri() . '/assets/images/og-vaidevan.jpg';

    /* Defaults */
    $title = $brand;
    $desc  = 'Lider em aluguel de van executiva e fretamento corporativo em Sao Paulo. Sprinter 15/19 lugares, motorista profissional, 20+ anos, 49 cidades, 12 estados. Orcamento pelo WhatsApp.';
    $canon = $home;
    $og_img = $img;
    $og_type = 'website';
    $kw = 'aluguel de van executiva Sao Paulo, fretamento van executiva SP, aluguel sprinter executivo, transporte executivo corporativo SP, van blindada aluguel SP, transfer aeroporto Guarulhos, aluguel van 15 lugares SP, fretamento corporativo SP, van para empresa SP, aluguel van executiva';

    if (is_front_page()) {
        $title = 'Aluguel de Van Executiva em Sao Paulo' . $sep . 'Fretamento Corporativo' . $sep . $brand;
        $desc  = 'Aluguel de van executiva em Sao Paulo com motorista profissional. Sprinter 415 e 516, blindada, fretamento corporativo, transfer aeroporto. +20 anos de experiencia, 49 cidades, 12 estados. Orcamento gratis pelo WhatsApp!';
        $kw    = 'aluguel de van executiva Sao Paulo, van executiva SP, fretamento van, aluguel van SP, van blindada SP, transfer aeroporto SP, transporte executivo SP, aluguel sprinter SP, fretamento corporativo Sao Paulo';
    } elseif (is_page()) {
        $slug = $post->post_name ?? '';
        if ($slug === 'servicos') {
            $title = 'Servicos de Transporte Executivo e Fretamento' . $sep . $brand;
            $desc  = 'Veja todos os servicos VaideVan: fretamento corporativo, aluguel de van executiva, transfer aeroporto, van blindada, transporte para eventos e turismo executivo em Sao Paulo e Brasil.';
            $kw    = 'servicos van executiva SP, fretamento corporativo, transfer aeroporto, van blindada, transporte eventos SP';
        } elseif ($slug === 'frota') {
            $title = 'Frota de Vans Executivas Mercedes-Benz Sprinter' . $sep . $brand;
            $desc  = 'Frota VaideVan: Mercedes-Benz Sprinter 415 (15 lugares) e 516 (19 lugares), executivo e blindado. Veiculos novos, seguros e confortaveis para transporte corporativo em Sao Paulo.';
            $kw    = 'frota van executiva SP, Sprinter 415, Sprinter 516, van blindada Mercedes SP';
        } elseif ($slug === 'sobre') {
            $title = 'Sobre a VaideVan — 20 Anos de Transporte Executivo' . $sep . $brand;
            $desc  = 'Conheca a VaideVan: mais de 20 anos liderando o transporte executivo corporativo em Sao Paulo. Atuamos em 49 cidades e 12 estados com frota Mercedes-Benz Sprinter e motoristas treinados.';
            $kw    = 'sobre VaideVan, empresa transporte executivo SP, historia VaideVan, 20 anos transporte corporativo';
        } elseif ($slug === 'contato') {
            $title = 'Contato e Orcamento de Van Executiva' . $sep . $brand;
            $desc  = 'Entre em contato para solicitar orcamento de aluguel de van executiva, fretamento corporativo ou transfer aeroporto. WhatsApp disponivel 24h: +55 11 99929-4694.';
            $kw    = 'orcamento van executiva SP, contato VaideVan, WhatsApp van executiva';
        } elseif ($slug === 'portal') {
            $title = 'Portal do Investidor' . $sep . $brand;
            $desc  = 'Acesso exclusivo para investidores VaideVan. Acompanhe resultados, operacoes e movimentacoes financeiras em tempo real.';
            $kw    = '';
        } else {
            $title = get_the_title() . $sep . $brand;
            $desc  = wp_trim_words(get_the_excerpt() ?: strip_tags($post->post_content ?? ''), 28, '...');
        }
        $canon = get_permalink($post);
    } elseif (is_single() && isset($post)) {
        $title   = get_the_title() . $sep . 'Blog VaideVan' . $sep . $brand;
        $desc    = wp_trim_words(get_the_excerpt() ?: strip_tags($post->post_content), 30, '...');
        $canon   = get_permalink($post);
        $og_type = 'article';
        $thumb   = get_the_post_thumbnail_url($post, 'large');
        if ($thumb) { $og_img = $thumb; }
        $kw = '';
    } elseif (is_category() || is_tag() || is_archive()) {
        $title = get_the_archive_title() . $sep . 'Blog' . $sep . $brand;
        $desc  = get_the_archive_description() ?: 'Artigos, dicas e noticias sobre transporte executivo, aluguel de van e fretamento corporativo em Sao Paulo.';
        $canon = get_term_link(get_queried_object());
        $kw    = '';
    } elseif (is_search()) {
        $title = 'Busca: ' . get_search_query() . $sep . $brand;
        $desc  = 'Resultado da busca por "' . get_search_query() . '" no blog da VaideVan.';
        $canon = '';
        $kw    = '';
    } elseif (is_404()) {
        $title = 'Pagina nao encontrada' . $sep . $brand;
        $desc  = 'A pagina que voce procura nao existe. Navegue pelo site VaideVan para conhecer nossos servicos.';
        $canon = '';
        $kw    = '';
    }

    $title  = esc_attr($title);
    $desc   = esc_attr(wp_strip_all_tags($desc));
    $og_img = esc_url($og_img);
    ?>
<title><?= $title ?></title>
<meta name="description" content="<?= $desc ?>">
<?php if ($kw): ?><meta name="keywords" content="<?= esc_attr($kw) ?>"><?php endif; ?>
<meta name="robots" content="<?= (is_page_template('page-templates/portal.php') || is_search() || is_404()) ? 'noindex,nofollow' : 'index,follow,max-image-preview:large,max-snippet:-1,max-video-preview:-1' ?>">
<meta name="author" content="VaideVan Transporte Executivo">
<meta name="geo.region" content="BR-SP">
<meta name="geo.placename" content="Sao Paulo">
<meta name="geo.position" content="-23.5505;-46.6333">
<meta name="ICBM" content="-23.5505, -46.6333">
<meta name="language" content="pt-BR">
<meta name="revisit-after" content="7 days">
<?php if ($canon): ?><link rel="canonical" href="<?= esc_url($canon) ?>">
<?php endif; ?>
<!-- Open Graph -->
<meta property="og:type" content="<?= esc_attr($og_type) ?>">
<meta property="og:url" content="<?= esc_url($canon ?: $home) ?>">
<meta property="og:title" content="<?= $title ?>">
<meta property="og:description" content="<?= $desc ?>">
<meta property="og:image" content="<?= $og_img ?>">
<meta property="og:image:width" content="1280">
<meta property="og:image:height" content="853">
<meta property="og:image:type" content="image/jpeg">
<meta property="og:image:alt" content="VaideVan — Van Executiva e Fretamento Corporativo em São Paulo">
<meta property="og:site_name" content="VaideVan Transporte Executivo">
<meta property="og:locale" content="pt_BR">
<?php if ($og_type === 'article' && isset($post)): ?>
<meta property="article:published_time" content="<?= get_the_date('c', $post) ?>">
<meta property="article:modified_time" content="<?= get_the_modified_date('c', $post) ?>">
<meta property="article:author" content="VaideVan Transporte Executivo">
<meta property="article:section" content="Transporte Executivo">
<?php endif; ?>
<!-- Twitter Cards -->
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:site" content="@vaidevan">
<meta name="twitter:creator" content="@vaidevan">
<meta name="twitter:title" content="<?= $title ?>">
<meta name="twitter:description" content="<?= $desc ?>">
<meta name="twitter:image" content="<?= $og_img ?>">
<meta name="twitter:image:alt" content="VaideVan — Van Executiva São Paulo">
<!-- Hreflang -->
<link rel="alternate" hreflang="pt-BR" href="<?= esc_url($canon ?: $home) ?>">
<link rel="alternate" hreflang="x-default" href="<?= esc_url($home) ?>">
<!-- RSS Feed -->
<link rel="alternate" type="application/rss+xml" title="Blog VaideVan — Feed" href="<?= esc_url(home_url('/feed/')) ?>">
<!-- Favicon (logo circular VaideVan) -->
<link rel="icon" href="<?= get_template_directory_uri() ?>/assets/images/favicon.ico" sizes="any">
<link rel="icon" type="image/svg+xml" href="<?= get_template_directory_uri() ?>/assets/images/favicon.svg">
<link rel="icon" type="image/png" sizes="96x96" href="<?= get_template_directory_uri() ?>/assets/images/favicon-96.png">
<link rel="icon" type="image/png" sizes="32x32" href="<?= get_template_directory_uri() ?>/assets/images/favicon-32.png">
<link rel="shortcut icon" href="<?= get_template_directory_uri() ?>/assets/images/favicon.ico">
<link rel="apple-touch-icon" href="<?= get_template_directory_uri() ?>/assets/images/apple-touch-icon.png">
<link rel="apple-touch-icon" sizes="180x180" href="<?= get_template_directory_uri() ?>/assets/images/apple-touch-icon.png">
<link rel="mask-icon" href="<?= get_template_directory_uri() ?>/assets/images/favicon.svg" color="#F5E642">
<!-- iOS Splash Screens -->
<link rel="apple-touch-startup-image" media="screen and (device-width:375px) and (device-height:667px) and (-webkit-device-pixel-ratio:2)" href="<?= get_template_directory_uri() ?>/assets/images/splash/splash-750x1334.png">
<link rel="apple-touch-startup-image" media="screen and (device-width:375px) and (device-height:812px) and (-webkit-device-pixel-ratio:3)" href="<?= get_template_directory_uri() ?>/assets/images/splash/splash-1125x2436.png">
<link rel="apple-touch-startup-image" media="screen and (device-width:390px) and (device-height:844px) and (-webkit-device-pixel-ratio:3)" href="<?= get_template_directory_uri() ?>/assets/images/splash/splash-1170x2532.png">
<link rel="apple-touch-startup-image" media="screen and (device-width:393px) and (device-height:852px) and (-webkit-device-pixel-ratio:3)" href="<?= get_template_directory_uri() ?>/assets/images/splash/splash-1179x2556.png">
<link rel="apple-touch-startup-image" media="screen and (device-width:430px) and (device-height:932px) and (-webkit-device-pixel-ratio:3)" href="<?= get_template_directory_uri() ?>/assets/images/splash/splash-1290x2796.png">
<link rel="apple-touch-startup-image" media="screen and (device-width:768px) and (device-height:1024px) and (-webkit-device-pixel-ratio:2)" href="<?= get_template_directory_uri() ?>/assets/images/splash/splash-1536x2048.png">
<link rel="apple-touch-startup-image" media="screen and (device-width:834px) and (device-height:1194px) and (-webkit-device-pixel-ratio:2)" href="<?= get_template_directory_uri() ?>/assets/images/splash/splash-1668x2388.png">
<link rel="apple-touch-startup-image" media="screen and (device-width:1024px) and (device-height:1366px) and (-webkit-device-pixel-ratio:2)" href="<?= get_template_directory_uri() ?>/assets/images/splash/splash-2048x2732.png">
<!-- PWA Manifest -->
<link rel="manifest" href="<?= get_template_directory_uri() ?>/assets/manifest.webmanifest">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="apple-mobile-web-app-title" content="VaideVan">
<meta name="application-name" content="VaideVan">
<meta name="theme-color" content="#0A0A0A">
<!-- AI / Voice Search optimization -->
<meta name="speakable" content="description">
    <?php
}
remove_action('wp_head', '_wp_render_title_tag', 1);
add_action('wp_head', 'vdv_page_seo', 1);
