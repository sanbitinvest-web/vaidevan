<?php
/**
 * single.php — Single post template
 * Visual: matches vaidevan.com/blog/{slug} (React SPA design)
 */
defined('ABSPATH') || exit;
get_header();
the_post();

$cat   = get_the_category();
$cname = $cat ? esc_html($cat[0]->name) : 'Blog';
$date  = get_the_date('d \d\e F \d\e Y');
$mins  = max(1,(int)round(str_word_count(strip_tags(get_the_content()))/200));
$WA    = 'https://wa.me/5511999294694?text=Ol%C3%A1!%20Li%20o%20blog%20da%20VaideVan%20e%20gostaria%20de%20um%20or%C3%A7amento.';
$hero  = get_post_meta(get_the_ID(), '_soro_post_image', true)
       ?: (get_the_post_thumbnail_url(null,'full')
       ?: 'https://vaidevan.com/wp-content/uploads/2026/05/review-van-mercedes-executiva-vale-a-pena-featured.webp');
?>

<div class="single-post-wrap">
  <div class="single-post-inner">

    <!-- Breadcrumb -->
    <nav class="post-breadcrumb" aria-label="Breadcrumb">
      <a href="<?= esc_url(home_url('/')) ?>">Início</a>
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><polyline points="9 18 15 12 9 6"/></svg>
      <a href="<?= esc_url(home_url('/blog/')) ?>">Blog</a>
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><polyline points="9 18 15 12 9 6"/></svg>
      <span><?php the_title(); ?></span>
    </nav>

    <!-- Hero image -->
    <div class="post-hero-img">
      <img src="<?= esc_url($hero) ?>" alt="<?php the_title_attribute(); ?>" width="1400" height="700" loading="eager">
    </div>

    <!-- Meta row -->
    <div class="post-meta-row">
      <span class="post-cat-pill">
        <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" style="margin-right:3px;vertical-align:-1px" aria-hidden="true"><path d="M20.59 13.41l-7.17 7.17a2 2 0 01-2.83 0L2 12V2h10l8.59 8.59a2 2 0 010 2.82z"/><line x1="7" y1="7" x2="7.01" y2="7"/></svg>
        <?= $cname ?>
      </span>
      <span class="post-meta-icon">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
        <?= $date ?>
      </span>
      <span class="post-meta-icon">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
        <?= $mins ?> min de leitura
      </span>
    </div>

    <!-- Title -->
    <h1 class="post-title"><?php the_title(); ?></h1>

    <!-- Lead / excerpt -->
    <?php $ex = get_the_excerpt(); if ($ex): ?>
    <blockquote class="post-lead"><?= wp_kses_post($ex) ?></blockquote>
    <?php endif; ?>

    <!-- Content -->
    <div class="post-content">
      <?php the_content(); ?>
    </div>

    <!-- CTA box -->
    <div class="post-cta-box">
      <h3>Pronto para contratar a <span style="color:var(--primary)">VaideVan</span>?</h3>
      <p>Entre em contato agora pelo WhatsApp e receba uma proposta personalizada em até 2 horas.</p>
      <a href="<?= $WA ?>" target="_blank" rel="noopener noreferrer" class="btn-primary-lg">
        Falar no WhatsApp
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true" style="margin-left:8px"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
      </a>
    </div>

    <!-- Prev / Next -->
    <?php $prev_p = get_previous_post(); $next_p = get_next_post(); ?>
    <?php if ($prev_p || $next_p): ?>
    <nav class="post-nav" aria-label="Navegação entre artigos">
      <?php if ($prev_p): ?>
      <a href="<?= esc_url(get_permalink($prev_p->ID)) ?>" class="post-nav-item" rel="prev">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true"><line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/></svg>
        <div>
          <p class="post-nav-label">Artigo anterior</p>
          <p class="post-nav-title"><?= esc_html(wp_trim_words(get_the_title($prev_p->ID), 8)) ?></p>
        </div>
      </a>
      <?php else: ?><span></span><?php endif; ?>
      <?php if ($next_p): ?>
      <a href="<?= esc_url(get_permalink($next_p->ID)) ?>" class="post-nav-item post-nav-next" rel="next">
        <div>
          <p class="post-nav-label">Próximo artigo</p>
          <p class="post-nav-title"><?= esc_html(wp_trim_words(get_the_title($next_p->ID), 8)) ?></p>
        </div>
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
      </a>
      <?php else: ?><span></span><?php endif; ?>
    </nav>
    <?php endif; ?>

    <!-- Related posts -->
    <?php
    $related = get_posts([
      'numberposts'  => 3,
      'category__in' => wp_get_post_categories(get_the_ID()),
      'post__not_in' => [get_the_ID()],
      'post_status'  => 'publish',
    ]);
    if (count($related) < 3) {
      $extra = get_posts([
        'numberposts'  => 3 - count($related),
        'post__not_in' => array_merge([get_the_ID()], array_column($related,'ID')),
        'post_status'  => 'publish',
        'orderby'      => 'rand',
      ]);
      $related = array_merge($related, $extra);
    }
    if ($related): ?>
    <div class="related-posts">
      <h3 class="related-title">Outros artigos sobre transporte executivo</h3>
      <div class="related-grid">
        <?php foreach ($related as $r):
          $rthumb = get_post_meta($r->ID, '_soro_post_image', true)
                  ?: (get_the_post_thumbnail_url($r->ID,'medium')
                  ?: 'https://vaidevan.com/wp-content/uploads/2026/05/review-van-mercedes-executiva-vale-a-pena-featured.webp');
          $rcat   = get_the_category($r->ID);
          $rcname = $rcat ? esc_html($rcat[0]->name) : 'Blog';
          $rmins  = max(1,(int)round(str_word_count(strip_tags($r->post_content))/200));
        ?>
        <a href="<?= esc_url(get_permalink($r->ID)) ?>" class="related-card">
          <div class="related-img">
            <img src="<?= esc_url($rthumb) ?>" alt="<?= esc_attr(get_the_title($r->ID)) ?>" width="800" height="450" loading="lazy" decoding="async">
            <div class="post-thumb-overlay"></div>
            <span class="post-cat-sm"><?= $rcname ?></span>
          </div>
          <div class="related-body">
            <h4><?= esc_html(get_the_title($r->ID)) ?></h4>
            <span class="post-meta-icon related-read">
              <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
              <?= $rmins ?> min de leitura
            </span>
          </div>
        </a>
        <?php endforeach; ?>
      </div>
    </div>
    <?php endif; ?>

  </div><!-- .single-post-inner -->
</div><!-- .single-post-wrap -->

<?php get_footer(); ?>
