<?php
/**
 * index.php — Fallback template (blog listing ou posts page)
 */
defined('ABSPATH') || exit;

// Se for a homepage sem front-page.php, inclui o conteudo completo
if (is_front_page() && !is_home()) {
    include get_template_directory() . '/front-page.php';
    exit;
}

get_header();
?>
<div class="blog-wrap">
  <div class="container">
    <div class="blog-header">
      <h1>Blog VaideVan</h1>
      <p>Dicas, novidades e guias sobre aluguel de vans executivas, fretamento corporativo e transporte executivo em São Paulo.</p>
    </div>

    <?php if (have_posts()):
      the_post(); // Featured post
      $feat_thumb = get_the_post_thumbnail_url(null, 'large') ?: 'https://vaidevan.com/wp-content/uploads/2026/05/review-van-mercedes-executiva-vale-a-pena-featured.webp';
      $feat_cat   = get_the_category(); $feat_cname = $feat_cat ? esc_html($feat_cat[0]->name) : 'Blog';
    ?>
    <!-- Featured post -->
    <div class="featured-post">
      <a href="<?php the_permalink(); ?>" class="featured-card">
        <div class="featured-img-wrap">
          <img src="<?= esc_url($feat_thumb) ?>" alt="<?php the_title_attribute(); ?>" width="1400" height="700" loading="eager">
          <div class="featured-img-overlay"></div>
          <span class="post-cat-badge"><?= $feat_cname ?></span>
        </div>
        <div class="featured-body">
          <div class="post-meta">
            <span><?php echo get_the_date('d \d\e F \d\e Y'); ?></span>
            <span><?php $w=str_word_count(strip_tags(get_the_content()));echo max(1,(int)round($w/200));?> min</span>
          </div>
          <h2><?php the_title(); ?></h2>
          <p class="excerpt"><?php echo wp_trim_words(get_the_excerpt(), 30, '...'); ?></p>
          <span class="read-more">Ler artigo completo →</span>
        </div>
      </a>
    </div>

    <?php if (have_posts()): ?>
    <!-- Grid de posts -->
    <div class="posts-grid">
      <?php while (have_posts()): the_post();
        $thumb = get_the_post_thumbnail_url(null, 'medium_large') ?: 'https://vaidevan.com/wp-content/uploads/2026/04/transporte-corporativo-com-padrao-executivo-featured.webp';
        $cat   = get_the_category(); $cname = $cat ? esc_html($cat[0]->name) : 'Blog';
      ?>
      <div class="post-card post-card-item" data-cat="<?= esc_attr($cat ? $cat[0]->slug : '') ?>">
        <a href="<?php the_permalink(); ?>">
          <div class="post-thumb">
            <img src="<?= esc_url($thumb) ?>" alt="<?php the_title_attribute(); ?>" width="800" height="450" loading="lazy" decoding="async">
            <div class="post-thumb-overlay"></div>
            <span class="post-cat-sm"><?= $cname ?></span>
          </div>
          <div class="post-body">
            <h3><?php the_title(); ?></h3>
            <p class="excerpt-sm"><?php echo wp_trim_words(get_the_excerpt(), 20, '...'); ?></p>
            <div class="post-card-meta">
              <span><?php echo get_the_date('d M Y'); ?></span>
              <span style="color:var(--primary)">Ler →</span>
            </div>
          </div>
        </a>
      </div>
      <?php endwhile; ?>
    </div>
    <?php endif; ?>

    <div class="load-more"><?php the_posts_pagination(); ?></div>

    <?php else: ?>
    <p style="text-align:center;color:rgba(255,255,255,.5);padding:64px 0">Nenhum post encontrado.</p>
    <?php endif; ?>
  </div>
</div>

<?php get_footer(); ?>
