/* VaideVan — portal.js */
(function () {
'use strict';

/* ---- Helpers ---- */
function brl(v) {
  return 'R$ ' + Number(v).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function ajax(action, data, cb) {
  if (typeof vdvPortal === 'undefined' || !vdvPortal.ajaxUrl) { cb({ success: false }); return; }
  var fd = new FormData();
  fd.append('action', action);
  fd.append('nonce', vdvPortal.nonce);
  if (data) Object.keys(data).forEach(function (k) { fd.append(k, data[k]); });
  var ctrl = typeof AbortController !== 'undefined' ? new AbortController() : null;
  var tid  = ctrl ? setTimeout(function () { ctrl.abort(); }, 15000) : null;
  fetch(vdvPortal.ajaxUrl, { method: 'POST', body: fd, credentials: 'same-origin', signal: ctrl ? ctrl.signal : undefined })
    .then(function (r) { if (tid) clearTimeout(tid); return r.json(); })
    .then(cb)
    .catch(function () { if (tid) clearTimeout(tid); cb({ success: false }); });
}

/* ============================================================
   BLOCO LOGIN — ativa se o formulario PHP estiver na pagina
   ============================================================ */
var loginBtn = document.getElementById('loginBtn');
if (loginBtn) {
  var fb  = document.getElementById('loginFb');
  var em  = document.getElementById('lEmail');
  var pw  = document.getElementById('lSenha');

  function tryLogin() {
    if (!em.value || !pw.value) {
      fb.className = 'form-fb err'; fb.textContent = 'Preencha todos os campos.'; return;
    }
    loginBtn.disabled = true; loginBtn.textContent = 'Aguarde…';
    ajax('vdv_portal_login', { email: em.value, senha: pw.value }, function (r) {
      if (r.success) {
        /* Login ok — recarrega para PHP servir o dashboard */
        window.location.reload();
      } else {
        fb.className = 'form-fb err';
        fb.textContent = (r.data && r.data.message) ? r.data.message : 'Credenciais inválidas.';
        loginBtn.disabled = false; loginBtn.textContent = 'Entrar no Portal';
      }
    });
  }

  loginBtn.addEventListener('click', tryLogin);
  [em, pw].forEach(function (i) {
    i.addEventListener('keydown', function (e) { if (e.key === 'Enter') tryLogin(); });
  });
}

/* ============================================================
   BLOCO DASHBOARD — ativa se o dashWrap PHP estiver na pagina
   ============================================================ */
var dashWrap    = document.getElementById('dashWrap');
var dashSpinner = document.getElementById('dashSpinner');

if (dashWrap) {
  /* Logout via form AJAX (evita reload completo) */
  var logoutForm = document.getElementById('logoutForm');
  if (logoutForm) {
    logoutForm.addEventListener('submit', function (e) {
      e.preventDefault();
      ajax('vdv_portal_logout', {}, function () { window.location.href = window.location.pathname; });
    });
  }

  /* Carrega dados do dashboard */
  ajax('vdv_portal_check', {}, function (r) {
    if (!r.success || !r.data || !r.data.logado) {
      /* Sessao expirou — volta ao login */
      window.location.reload(); return;
    }
    renderDash(r.data);
  });
}

/* ============================================================
   RENDERIZACAO DO DASHBOARD
   ============================================================ */
var PAGE = 1, PER = 10;

function renderDash(dados) {
  var inv     = dados.investidor || {};
  var ops     = dados.operacoes  || [];
  var vehs    = dados.veiculos   || [];
  var movs    = dados.movimentos || [];
  var monthly = dados.mensal     || [];
  var kpis    = dados.kpis       || {};

  /* KPIs */
  set('kRecTotal', brl(kpis.receita_total || 0));
  set('kDespTotal', brl(kpis.despesa_total || 0));
  set('kLucro', brl(kpis.lucro || 0));
  if (kpis.var_pct != null) {
    var sign = kpis.var_pct >= 0 ? '+' : '';
    html('kVar', '<span style="color:' + (kpis.var_pct >= 0 ? '#4ade80' : '#f87171') + '">' +
      sign + Number(kpis.var_pct).toFixed(1) + '% vs mês ant.</span>');
  }
  var lucro = kpis.lucro || 0;
  var pct   = inv.participacao_pct || 0;
  set('kRend', 'Rendimento: ' + brl(lucro * (pct / 100)));

  var ativos = vehs.filter(function (v) { return v.status === 'ativo'; }).length;
  set('kVehs', ativos);
  set('kVehTotal', 'de ' + vehs.length + ' no total');

  /* Gráfico */
  html('chartArea', renderChart(monthly));

  /* Operações */
  html('opsArea', ops.length ? ops.map(function (o) {
    var cls = o.status === 'ativo' ? 'badge-ok' : o.status === 'pausa' ? 'badge-pause' : 'badge-off';
    return '<div class="op-item"><div><div class="op-name">' + esc(o.nome) + '</div>' +
      '<div class="op-loc">' + o.cidades + ' cidades &bull; ' + o.estados + ' estado(s)</div></div>' +
      '<span class="badge ' + cls + '">' + esc(o.status) + '</span></div>';
  }).join('') : '<p style="color:rgba(255,255,255,.38);font-size:.85rem">Nenhuma operação.</p>');

  /* Frota */
  html('vehArea', vehs.length ? vehs.map(function (v) {
    var cls = v.status === 'ativo' ? 'badge-ok' : v.status === 'manutencao' ? 'badge-pause' : 'badge-off';
    return '<div class="veh-item"><span class="veh-plate">' + esc(v.placa) + '</span>' +
      '<div class="veh-info"><div class="veh-model">' + esc(v.modelo) + '</div>' +
      '<div class="veh-year">Ano ' + v.ano + ' &bull; ' + v.capacidade + ' passageiros</div></div>' +
      '<span class="badge ' + cls + '">' + esc(v.status) + '</span></div>';
  }).join('') : '<p style="color:rgba(255,255,255,.38);font-size:.85rem">Nenhum veículo.</p>');

  /* Tabela */
  set('movCount', movs.length + ' registros');
  html('tableWrap', renderTable(movs, PAGE));

  /* Paginação delegada */
  var tw = document.getElementById('tableWrap');
  if (tw) {
    tw.addEventListener('click', function (e) {
      if (e.target.classList.contains('pag-btn')) {
        PAGE = parseInt(e.target.dataset.pg, 10);
        html('tableWrap', renderTable(movs, PAGE));
      }
    });
  }

  /* Mostra dashboard, esconde spinner */
  if (dashSpinner) dashSpinner.style.display = 'none';
  if (dashWrap)    dashWrap.style.display = '';
}

function renderChart(monthly) {
  var maxV = 0;
  monthly.forEach(function (m) { maxV = Math.max(maxV, Number(m.receita), Number(m.despesa)); });
  var meses = ['Jan','Fev','Mar','Abr','Mai','Jun','Jul','Ago','Set','Out','Nov','Dez'];
  var bars = '', lbls = '';
  monthly.forEach(function (m) {
    var h  = 120;
    var hi = maxV > 0 ? Math.round((Number(m.receita) / maxV) * h) : 0;
    var he = maxV > 0 ? Math.round((Number(m.despesa) / maxV) * h) : 0;
    var idx = Number(m.mes) - 1;
    bars += '<div class="chart-bar-g" title="' + meses[idx] + ': Rec ' + brl(m.receita) + ' / Desp ' + brl(m.despesa) + '">' +
      '<div class="bar-inc" style="height:' + hi + 'px"></div>' +
      '<div class="bar-exp" style="height:' + he + 'px"></div></div>';
    lbls += '<div class="chart-lbl">' + meses[idx] + '</div>';
  });
  return '<div class="chart-legend"><span class="leg-inc">Receita</span><span class="leg-exp">Despesa</span></div>' +
    '<div class="chart-wrap"><div class="chart-bars">' + bars + '</div><div class="chart-labels">' + lbls + '</div></div>';
}

function renderTable(movs, page) {
  if (!movs || !movs.length) return '<p style="color:rgba(255,255,255,.38);font-size:.85rem">Nenhuma movimentação.</p>';
  var start = (page - 1) * PER;
  var slice = movs.slice(start, start + PER);
  var rows = slice.map(function (m) {
    var inc = m.tipo === 'receita';
    return '<tr><td class="td-date">' + esc(m.data_formatada) + '</td>' +
      '<td>' + esc(m.descricao) + '</td>' +
      '<td>' + esc(m.operacao_nome) + '</td>' +
      '<td class="' + (inc ? 'td-income' : 'td-expense') + '">' + (inc ? '+' : '-') + brl(Math.abs(m.valor)) + '</td></tr>';
  }).join('');
  var pages = Math.ceil(movs.length / PER);
  var pags  = '';
  if (pages > 1) {
    pags = '<div class="pagination">';
    for (var i = 1; i <= pages; i++) {
      pags += '<button class="pag-btn' + (i === page ? ' active' : '') + '" data-pg="' + i + '">' + i + '</button>';
    }
    pags += '</div>';
  }
  return '<div style="overflow-x:auto"><table class="data-table"><thead><tr>' +
    '<th>Data</th><th>Descrição</th><th>Operação</th><th>Valor</th></tr></thead>' +
    '<tbody>' + rows + '</tbody></table></div>' + pags;
}

/* ---- Micro-utils ---- */
function set(id, txt) { var el = document.getElementById(id); if (el) el.textContent = txt; }
function html(id, h)   { var el = document.getElementById(id); if (el) el.innerHTML  = h; }
function esc(s) {
  return String(s || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

})();
