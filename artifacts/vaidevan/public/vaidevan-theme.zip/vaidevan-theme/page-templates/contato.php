<?php
/**
 * Template Name: Contato
 */
get_header();
?>
<section class="page-hero">
    <div class="container">
        <nav aria-label="Breadcrumb">
            <ol style="display:flex;gap:8px;font-size:.78rem;color:rgba(255,255,255,.38);justify-content:center;margin-bottom:18px;list-style:none">
                <li><a href="<?= esc_url(home_url('/')) ?>" style="color:var(--y)">Inicio</a></li>
                <li aria-hidden>/</li><li aria-current="page">Contato</li>
            </ol>
        </nav>
        <h1>Solicite seu Orcamento de Van Executiva</h1>
        <p>Respondemos em menos de 30 minutos. Nossa equipe esta disponivel 24 horas por dia.</p>
    </div>
</section>

<section class="section-pad" style="background:var(--k)">
    <div class="container">
        <div class="contato-grid">
            <div class="ct-info fade-up">
                <span class="sec-label">Fale Conosco</span>
                <h2>Entre em Contato</h2>
                <p>Atendemos por WhatsApp, telefone, e-mail ou pelo formulario ao lado. Preferimos o WhatsApp pela agilidade, mas todos os canais sao monitorados 24 horas.</p>

                <div class="ct-item">
                    <div class="ct-ico" aria-hidden>📱</div>
                    <div>
                        <div style="font-weight:700;font-size:.92rem">WhatsApp (principal)</div>
                        <a href="https://wa.me/5511999294694" target="_blank" rel="noopener noreferrer"
                           style="color:var(--y);font-size:.88rem">+55 (11) 99929-4694</a>
                    </div>
                </div>
                <div class="ct-item">
                    <div class="ct-ico" aria-hidden>📧</div>
                    <div>
                        <div style="font-weight:700;font-size:.92rem">E-mail</div>
                        <a href="mailto:contato@vaidevan.com" style="color:var(--y);font-size:.88rem">contato@vaidevan.com</a>
                    </div>
                </div>
                <div class="ct-item">
                    <div class="ct-ico" aria-hidden>📍</div>
                    <div>
                        <div style="font-weight:700;font-size:.92rem">Sede</div>
                        <a href="https://maps.app.goo.gl/jBEHwBJxC631QFQr8" target="_blank" rel="noopener noreferrer" style="font-size:.88rem;color:rgba(255,255,255,.6);transition:color .25s ease" onmouseover="this.style.color='#F5E642'" onmouseout="this.style.color='rgba(255,255,255,.6)'">Av. Pres. Juscelino Kubitschek, 2041<br>Itaim Bibi — São Paulo, SP 04543-011</a>
                    </div>
                </div>
                <div class="ct-item">
                    <div class="ct-ico" aria-hidden>🕐</div>
                    <div>
                        <div style="font-weight:700;font-size:.92rem">Atendimento</div>
                        <div style="font-size:.88rem;color:rgba(255,255,255,.6)">24 horas, 7 dias por semana</div>
                    </div>
                </div>

                <div style="margin-top:28px">
                    <a href="https://wa.me/5511999294694?text=Ola%2C%20gostaria%20de%20um%20orcamento%20de%20van%20executiva"
                       class="btn-y" target="_blank" rel="noopener noreferrer" style="display:inline-flex">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor" aria-hidden>
                            <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
                        </svg>
                        Chamar no WhatsApp Agora
                    </a>
                </div>
            </div>

            <div class="fade-up" style="--d:.15s">
                <div class="form-box">
                    <h3>Formulario de Orcamento</h3>
                    <div id="ctFb" class="form-fb" role="alert" aria-live="polite"></div>
                    <form id="ctForm" novalidate>
                        <?php wp_nonce_field('vdv_contato_nonce', 'nonce'); ?>
                        <div class="form-row">
                            <div class="form-g">
                                <label for="ct-nome">Nome *</label>
                                <input type="text" id="ct-nome" name="nome" autocomplete="name" placeholder="Seu nome" required>
                            </div>
                            <div class="form-g">
                                <label for="ct-tel">Telefone</label>
                                <input type="tel" id="ct-tel" name="telefone" autocomplete="tel" placeholder="(11) 9xxxx-xxxx">
                            </div>
                        </div>
                        <div class="form-g">
                            <label for="ct-email">E-mail *</label>
                            <input type="email" id="ct-email" name="email" autocomplete="email" placeholder="seu@empresa.com.br" required>
                        </div>
                        <div class="form-g">
                            <label for="ct-empresa">Empresa</label>
                            <input type="text" id="ct-empresa" name="empresa" placeholder="Nome da sua empresa">
                        </div>
                        <div class="form-g">
                            <label for="ct-servico">Servico de Interesse</label>
                            <select id="ct-servico" name="servico">
                                <option value="">Selecione o servico</option>
                                <option>Aluguel de Van Executiva</option>
                                <option>Fretamento Corporativo</option>
                                <option>Transfer Aeroporto</option>
                                <option>Van Blindada</option>
                                <option>Transporte para Eventos</option>
                                <option>Turismo Corporativo</option>
                                <option>Outro</option>
                            </select>
                        </div>
                        <div class="form-g">
                            <label for="ct-msg">Mensagem *</label>
                            <textarea id="ct-msg" name="mensagem" placeholder="Descreva sua necessidade: destino, data, numero de passageiros, etc." required></textarea>
                        </div>
                        <button type="submit" class="btn-y btn-full" id="ctBtn">Enviar Solicitacao</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="section-pad" style="background:var(--d)">
    <div class="container">
        <div class="sec-head fade-up">
            <span class="sec-label">Perguntas Frequentes</span>
            <h2>Duvidas Sobre Orcamento e Contratacao</h2>
        </div>
        <div style="max-width:700px;margin:0 auto">
            <?php foreach ([
                ['Em quanto tempo recebo o orcamento?','Respondemos em menos de 30 minutos para solicitacoes pelo WhatsApp. Para formulario e e-mail, o prazo e de ate 2 horas em horario comercial.'],
                ['Qual o minimo de horas para contratacao?','Para alugueis avulsos, o minimo e de 4 horas. Para fretamento com contrato mensal, nao ha minimo — personalizamos conforme sua demanda.'],
                ['A VaideVan atende finais de semana e feriados?','Sim. Operamos 24 horas, 7 dias por semana, incluindo feriados. Pode haver variacao de tarifa em datas especiais.'],
                ['Posso cancelar ou alterar o agendamento?','Cancelamentos com mais de 24 horas de antecedencia sao realizados sem custo. Consulte condicoes especificas para seu contrato.'],
            ] as $i => [$q, $a]): ?>
            <details class="fade-up" style="--d:<?= $i*0.08 ?>s;border-bottom:1px solid rgba(255,255,255,.08);margin-bottom:0">
                <summary style="padding:20px 0;font-weight:700;font-size:.97rem;cursor:pointer;list-style:none;display:flex;justify-content:space-between;align-items:center">
                    <?= esc_html($q) ?> <span style="color:var(--y);font-size:1.2rem">&#9660;</span>
                </summary>
                <p style="color:rgba(255,255,255,.6);font-size:.9rem;line-height:1.7;padding-bottom:20px"><?= esc_html($a) ?></p>
            </details>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<script>
(function(){
var f=document.getElementById('ctForm'),fb=document.getElementById('ctFb'),btn=document.getElementById('ctBtn');
if(!f)return;
f.addEventListener('submit',function(e){
    e.preventDefault();
    var nome=f.querySelector('[name=nome]').value,email=f.querySelector('[name=email]').value,msg=f.querySelector('[name=mensagem]').value;
    if(!nome||!email||!msg){fb.className='form-fb err';fb.textContent='Preencha os campos obrigatorios.';return;}
    btn.disabled=true;btn.textContent='Enviando...';
    var fd=new FormData(f);fd.append('action','vdv_contato');
    fetch('<?= admin_url('admin-ajax.php') ?>',{method:'POST',body:fd,credentials:'same-origin'})
        .then(function(r){return r.json();}).then(function(r){
            if(r.success){fb.className='form-fb ok';fb.textContent='Mensagem enviada! Entraremos em contato em breve.';f.reset();}
            else{fb.className='form-fb err';fb.textContent=r.data.message||'Erro ao enviar. Tente via WhatsApp.';}
            btn.disabled=false;btn.textContent='Enviar Solicitacao';
        }).catch(function(){fb.className='form-fb err';fb.textContent='Erro de conexao. Use o WhatsApp.';btn.disabled=false;btn.textContent='Enviar Solicitacao';});
});
})();
</script>

<?php get_footer(); ?>
