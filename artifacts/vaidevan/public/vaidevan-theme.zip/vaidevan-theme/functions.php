<?php
/**
 * VaideVan Premium WordPress Theme — functions.php
 * Performance + SEO + Portal do Investidor
 */
defined('ABSPATH') || exit;

/* ---- Autoload includes ---- */
require_once get_template_directory() . '/inc/setup.php';
require_once get_template_directory() . '/inc/seo.php';
require_once get_template_directory() . '/inc/schema.php';
require_once get_template_directory() . '/inc/performance.php';
require_once get_template_directory() . '/inc/analytics.php';
require_once get_template_directory() . '/inc/portal.php';
require_once get_template_directory() . '/inc/portal-shortcode.php';

/* ---- Criar tabelas na ativacao do tema ---- */
add_action('after_switch_theme', 'vdv_create_tables');
add_action('after_switch_theme', 'vdv_repair_page_templates');

/* Garantia: criar tabelas se ainda nao existirem (usa versao como chave) */
add_action('init', function () {
    if (get_option('vdv_db_ver') !== '2.1') {
        vdv_create_tables();
        update_option('vdv_db_ver', '2.1');
    }
}, 5);

/* ---- Repara pages em instalacoes existentes ---- */
function vdv_repair_page_templates() {
    $map = [
        'portal'        => 'page-templates/portal.php',
        'sobre'         => 'page-templates/sobre.php',
        'servicos'      => 'page-templates/servicos.php',
        'frota'         => 'page-templates/frota.php',
        'contato'       => 'page-templates/contato.php',
        'customizacao'  => 'page-templates/customizacao.php',
    ];
    foreach ($map as $slug => $tpl) {
        $page = get_page_by_path($slug);
        if ($page && $page->post_type === 'page') {
            update_post_meta($page->ID, '_wp_page_template', $tpl);
            if ($slug === 'portal' && strpos($page->post_content, '[vdv_portal]') === false) {
                wp_update_post(['ID' => $page->ID, 'post_content' => '[vdv_portal]']);
            }
        } elseif (!$page && $slug === 'customizacao') {
            /* Cria a página automaticamente se não existir */
            $new_id = wp_insert_post([
                'post_title'   => 'Customização e Transformação de Vans',
                'post_name'    => 'customizacao',
                'post_status'  => 'publish',
                'post_type'    => 'page',
                'post_content' => '',
            ]);
            if ($new_id && !is_wp_error($new_id)) {
                update_post_meta($new_id, '_wp_page_template', $tpl);
            }
        }
    }
    /* Atualiza versao para re-executar quando o tema for atualizado */
    update_option('vdv_tpl_repaired', '5');
}

/* Executa reparo no admin_init (uma vez por versao) */
add_action('admin_init', function () {
    if (get_option('vdv_tpl_repaired') !== '5') {
        vdv_repair_page_templates();
        update_option('vdv_tpl_repaired', '5');
    }
});

/* Tambem na ativacao do tema — sem depender do admin_init */
add_action('after_switch_theme', function () {
    vdv_repair_page_templates();
    update_option('vdv_tpl_repaired', '5');
});

/* Fallback: cria /customizacao/ via template_redirect se nao existir */
add_action('template_redirect', function () {
    if (is_404()) {
        $slug = trim(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH), '/');
        $slug = explode('/', $slug)[0]; // pega apenas o primeiro segmento
        if ($slug === 'customizacao') {
            $page = get_page_by_path('customizacao');
            if (!$page) {
                vdv_repair_page_templates();
            }
        }
    }
});

/* ---- AJAX: orçamento (hero form + modal) ---- */
add_action('wp_ajax_nopriv_vdv_orcamento', 'vdv_ajax_orcamento');
add_action('wp_ajax_vdv_orcamento',        'vdv_ajax_orcamento');
function vdv_ajax_orcamento() {
    $nonce = sanitize_text_field(wp_unslash($_POST['_wpnonce'] ?? $_POST['vdv_nonce'] ?? $_POST['vdv_modal_nonce'] ?? ''));
    if (!wp_verify_nonce($nonce, 'vdv_orcamento')) {
        wp_send_json_error('Nonce invalido.');
    }
    $nome    = sanitize_text_field(wp_unslash($_POST['nome']     ?? ''));
    $tel     = sanitize_text_field(wp_unslash($_POST['telefone'] ?? ''));
    $servico = sanitize_text_field(wp_unslash($_POST['tipo']     ?? $_POST['service'] ?? ''));
    $msg     = sanitize_textarea_field(wp_unslash($_POST['mensagem'] ?? ''));

    if (!$nome || !$tel) {
        wp_send_json_error('Preencha nome e WhatsApp.');
    }

    /* E-mail para contato@vaidevan.com */
    $subject = '[VaideVan] Novo Orcamento: ' . $nome;
    $body    = "Nome: $nome\nWhatsApp: $tel\nServico: $servico\n\nMensagem:\n$msg";
    wp_mail('contato@vaidevan.com', $subject, $body, ['Content-Type: text/plain; charset=UTF-8']);

    /* WhatsApp — URL com dados pre-preenchidos para o JS abrir em nova aba */
    $wa_text = "Ola VaideVan! Meu nome e $nome. Telefone: $tel. Servico: $servico. $msg";
    $wha_url = 'https://wa.me/5511999294694?text=' . rawurlencode($wa_text);

    wp_send_json_success(['msg' => 'Orcamento enviado!', 'wha_url' => $wha_url]);
}

/* ---- AJAX: contato ---- */
add_action('wp_ajax_nopriv_vdv_contato', 'vdv_ajax_contato');
add_action('wp_ajax_vdv_contato',        'vdv_ajax_contato');
function vdv_ajax_contato() {
    $nonce = sanitize_text_field(wp_unslash($_POST['_wpnonce'] ?? $_POST['vdv_nonce'] ?? ''));
    if (!wp_verify_nonce($nonce, 'vdv_contato')) {
        wp_send_json_error('Nonce invalido.');
    }
    $nome    = sanitize_text_field(wp_unslash($_POST['nome']        ?? ''));
    $email   = sanitize_email(wp_unslash($_POST['email']            ?? ''));
    $tel     = sanitize_text_field(wp_unslash($_POST['telefone']    ?? ''));
    $tipo    = sanitize_text_field(wp_unslash($_POST['tipo']        ?? ''));
    $msg     = sanitize_textarea_field(wp_unslash($_POST['mensagem'] ?? ''));

    if (!$nome || !$email || !$msg || !is_email($email)) {
        wp_send_json_error('Preencha os campos obrigatorios.');
    }

    /* E-mail para contato@vaidevan.com */
    $subject = '[VaideVan] Contato de ' . $nome;
    $body    = "Nome: $nome\nE-mail: $email\nTelefone: $tel\nServico: $tipo\n\nMensagem:\n$msg";
    $headers = ['Content-Type: text/plain; charset=UTF-8', 'Reply-To: ' . $nome . ' <' . $email . '>'];
    wp_mail('contato@vaidevan.com', $subject, $body, $headers);

    /* WhatsApp — URL com dados pre-preenchidos para o JS abrir em nova aba */
    $wa_text = "Ola VaideVan! Sou $nome (e-mail: $email, tel: $tel). Servico: $tipo.\n\n$msg";
    $wha_url = 'https://wa.me/5511999294694?text=' . rawurlencode($wa_text);

    wp_send_json_success(['msg' => 'Mensagem enviada com sucesso!', 'wha_url' => $wha_url]);
}

/* ---- AJAX: cadastro de parceiros ---- */
add_action('wp_ajax_nopriv_vdv_parceiro', 'vdv_ajax_parceiro');
add_action('wp_ajax_vdv_parceiro',        'vdv_ajax_parceiro');
function vdv_ajax_parceiro() {
    $nonce = sanitize_text_field(wp_unslash($_POST['_wpnonce'] ?? $_POST['vdv_partner_nonce'] ?? ''));
    if (!wp_verify_nonce($nonce, 'vdv_parceiro')) {
        wp_send_json_error('Nonce invalido.');
    }
    $nome  = sanitize_text_field(wp_unslash($_POST['nome']      ?? ''));
    $email = sanitize_email(wp_unslash($_POST['email']          ?? ''));
    $tel   = sanitize_text_field(wp_unslash($_POST['telefone']  ?? ''));
    $tipo  = sanitize_text_field(wp_unslash($_POST['tipo']      ?? ''));
    $msg   = sanitize_textarea_field(wp_unslash($_POST['mensagem'] ?? ''));

    if (!$nome || !$email || !$tel || !is_email($email)) {
        wp_send_json_error('Preencha nome, e-mail e WhatsApp.');
    }

    /* Armazena como post customizado para histórico no WP Admin */
    wp_insert_post([
        'post_type'   => 'parceiro',
        'post_title'  => sanitize_text_field($nome . ' — ' . $tipo),
        'post_status' => 'private',
        'meta_input'  => [
            '_vdv_email'    => $email,
            '_vdv_telefone' => $tel,
            '_vdv_tipo'     => $tipo,
            '_vdv_mensagem' => $msg,
        ],
    ]);

    /* E-mail de notificação */
    $subject = '[VaideVan] Novo Parceiro: ' . $nome . ' (' . $tipo . ')';
    $body    = "Nome: $nome\nE-mail: $email\nWhatsApp: $tel\nTipo: $tipo\n\nMensagem:\n$msg";
    $headers = ['Content-Type: text/plain; charset=UTF-8', 'Reply-To: ' . $nome . ' <' . $email . '>'];
    wp_mail('contato@vaidevan.com', $subject, $body, $headers);

    $wa_text = "Ola VaideVan! Me cadastrei como parceiro ({$tipo}): $nome, $email, $tel. $msg";
    $wha_url = 'https://wa.me/5511999294694?text=' . rawurlencode($wa_text);

    wp_send_json_success(['msg' => 'Cadastro recebido!', 'wha_url' => $wha_url]);
}

/* Registra CPT parceiro */
add_action('init', function () {
    register_post_type('parceiro', [
        'labels'        => ['name' => 'Parceiros', 'singular_name' => 'Parceiro'],
        'public'        => false,
        'show_ui'       => true,
        'menu_icon'     => 'dashicons-groups',
        'supports'      => ['title', 'custom-fields'],
        'show_in_menu'  => true,
    ]);
});

/* ---- Excerto personalizado ---- */
add_filter('excerpt_length', function () { return 28; });
add_filter('excerpt_more',   function () { return '...'; });

/* ---- Paginacao de posts ---- */
function vdv_pagination() {
    echo paginate_links([
        'type'      => 'list',
        'prev_text' => '&lsaquo;',
        'next_text' => '&rsaquo;',
        'before_page_number' => '',
    ]);
}
