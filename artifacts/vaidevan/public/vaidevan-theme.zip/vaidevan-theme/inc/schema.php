<?php
/**
 * JSON-LD Schema Markup — VaideVan
 * schema.org: LocalBusiness, Organization, Service, FAQPage,
 *             BreadcrumbList, AggregateRating, WebSite
 */
defined('ABSPATH') || exit;

add_action('wp_head', 'vdv_output_schema', 2);
function vdv_output_schema() {
    global $post;
    $home = home_url('/');
    $logo = get_template_directory_uri() . '/assets/images/logo-dark.webp';

    /* ---- WebSite ---- */
    $schemas = [
        [
            '@context'        => 'https://schema.org',
            '@type'           => 'WebSite',
            '@id'             => $home . '#website',
            'url'             => $home,
            'name'            => 'VaideVan Transporte Executivo',
            'inLanguage'      => 'pt-BR',
            'potentialAction' => [
                '@type'       => 'SearchAction',
                'target'      => [
                    '@type'       => 'EntryPoint',
                    'urlTemplate' => $home . '?s={search_term_string}',
                ],
                'query-input' => 'required name=search_term_string',
            ],
        ],

        /* ---- Organization / LocalBusiness ---- */
        [
            '@context'            => 'https://schema.org',
            '@type'               => ['Organization','LocalBusiness','AutoRental'],
            '@id'                 => $home . '#organization',
            'name'                => 'VaideVan Transporte Executivo',
            'legalName'           => 'VaideVan Transporte Executivo Ltda',
            'url'                 => $home,
            'logo'                => [
                '@type' => 'ImageObject',
                'url'   => $logo,
                'width' => 400,
                'height'=> 80,
            ],
            'image'               => $logo,
            'description'         => 'Lider em aluguel de van executiva, fretamento corporativo e transporte executivo em Sao Paulo e mais de 49 cidades em 12 estados do Brasil. Mais de 20 anos de experiencia.',
            'telephone'           => '+55-11-99929-4694',
            'email'               => 'contato@vaidevan.com',
            'foundingDate'        => '2003',
            'numberOfEmployees'   => ['@type' => 'QuantitativeValue', 'value' => 45],
            'address'             => [
                '@type'           => 'PostalAddress',
                'streetAddress'   => 'Av. Pres. Juscelino Kubitschek, 2041',
                'addressLocality' => 'Sao Paulo',
                'addressRegion'   => 'SP',
                'postalCode'      => '04543-011',
                'addressCountry'  => 'BR',
            ],
            'geo'                 => [
                '@type'     => 'GeoCoordinates',
                'latitude'  => -23.591146,
                'longitude' => -46.68934,
            ],
            'openingHoursSpecification' => [
                [
                    '@type'     => 'OpeningHoursSpecification',
                    'dayOfWeek' => ['Monday','Tuesday','Wednesday','Thursday','Friday'],
                    'opens'     => '07:00',
                    'closes'    => '22:00',
                ],
                [
                    '@type'     => 'OpeningHoursSpecification',
                    'dayOfWeek' => ['Saturday','Sunday'],
                    'opens'     => '08:00',
                    'closes'    => '20:00',
                ],
            ],
            'priceRange'          => 'R$R$',
            'currenciesAccepted'  => 'BRL',
            'paymentAccepted'     => 'Dinheiro, Cartao de Credito, PIX, Transferencia Bancaria, Boleto',
            'areaServed'          => [
                ['@type' => 'State', 'name' => 'Sao Paulo'],
                ['@type' => 'State', 'name' => 'Rio de Janeiro'],
                ['@type' => 'State', 'name' => 'Minas Gerais'],
                ['@type' => 'State', 'name' => 'Parana'],
                ['@type' => 'State', 'name' => 'Santa Catarina'],
                ['@type' => 'State', 'name' => 'Rio Grande do Sul'],
                ['@type' => 'State', 'name' => 'Goias'],
                ['@type' => 'State', 'name' => 'Mato Grosso do Sul'],
                ['@type' => 'State', 'name' => 'Bahia'],
                ['@type' => 'State', 'name' => 'Pernambuco'],
                ['@type' => 'State', 'name' => 'Ceara'],
                ['@type' => 'State', 'name' => 'Distrito Federal'],
            ],
            'sameAs'              => [
                'https://wa.me/5511999294694',
                'https://www.instagram.com/vaidevan',
                'https://www.facebook.com/vaidevan',
                'https://www.linkedin.com/company/vaidevan',
            ],
            'aggregateRating'     => [
                '@type'       => 'AggregateRating',
                'ratingValue' => '4.9',
                'reviewCount' => '312',
                'bestRating'  => '5',
                'worstRating' => '1',
            ],
        ],
    ];

    /* ---- Pagina inicial — FAQ + Services ---- */
    if (is_front_page()) {
        $schemas[] = [
            '@context'   => 'https://schema.org',
            '@type'      => 'FAQPage',
            'mainEntity' => [
                vdv_faq('Quais tipos de van a VaideVan aluga?',
                    'Alugamos Mercedes-Benz Sprinter 415 (15 lugares) e 516 (19 lugares), com opcoes executiva, blindada e para eventos. Toda a frota e adaptada para transporte corporativo e confortavel.'),
                vdv_faq('Em quantas cidades a VaideVan atua?',
                    'Atendemos mais de 49 cidades em 12 estados brasileiros, com base principal em Sao Paulo. Realizamos fretamento, transfer aeroporto e transporte executivo em todo o Brasil.'),
                vdv_faq('Como funciona o fretamento de van executiva?',
                    'O fretamento pode ser mensal (frota dedicada), por diaria ou por evento. Entre em contato via WhatsApp ou formulario para receberem uma proposta personalizada conforme sua necessidade.'),
                vdv_faq('A VaideVan oferece van blindada?',
                    'Sim, dispomos de vans blindadas Mercedes-Benz Sprinter para clientes que exigem maximo nivel de segurança no transporte executivo.'),
                vdv_faq('Qual o valor do aluguel de van executiva em Sao Paulo?',
                    'Os precos variam conforme o modelo, duracao e itinerario. Entre em contato via WhatsApp +55 11 99929-4694 para um orcamento personalizado e sem compromisso.'),
                vdv_faq('A VaideVan faz transfer para o Aeroporto de Guarulhos (GRU)?',
                    'Sim, realizamos transfer executivo para o Aeroporto Internacional de Guarulhos, Congonhas e todos os aeroportos do estado de Sao Paulo, com motorista profissional e veiculos de alto padrao.'),
                vdv_faq('Como agendar uma van executiva?',
                    'Voce pode agendar pelo WhatsApp +55 11 99929-4694 (disponivel 24h), pelo formulario do site ou pelo e-mail contato@vaidevan.com.'),
            ],
        ];

        $schemas[] = [
            '@context'    => 'https://schema.org',
            '@type'       => 'ItemList',
            'name'        => 'Servicos VaideVan',
            'description' => 'Lista completa de servicos de transporte executivo e fretamento da VaideVan',
            'itemListElement' => [
                vdv_service_item(1, 'Aluguel de Van Executiva', 'Vans Mercedes-Benz Sprinter 415 e 516 com motorista profissional para transporte executivo em Sao Paulo e todo o Brasil.', $home . 'servicos/'),
                vdv_service_item(2, 'Fretamento Corporativo', 'Frota dedicada para empresas com contratos mensais. Transporte de colaboradores com pontualidade e conforto executivo.', $home . 'servicos/'),
                vdv_service_item(3, 'Transfer Aeroporto', 'Transfer executivo para Aeroporto de Guarulhos (GRU), Congonhas (CGH) e todos os aeroportos do Brasil.', $home . 'servicos/'),
                vdv_service_item(4, 'Van Blindada', 'Transporte com maximo nivel de seguranca em vans blindadas Mercedes-Benz para executivos e dignitarios.', $home . 'servicos/'),
                vdv_service_item(5, 'Transporte para Eventos', 'Vans executivas para congressos, feiras, casamentos e eventos corporativos em Sao Paulo e interior.', $home . 'servicos/'),
                vdv_service_item(6, 'Turismo Corporativo', 'Pacotes de turismo executivo e transfer para visitantes e delegacoes empresariais.', $home . 'servicos/'),
            ],
        ];
    }

    /* ---- BreadcrumbList para paginas internas ---- */
    if (is_page() && !is_front_page()) {
        $schemas[] = [
            '@context'        => 'https://schema.org',
            '@type'           => 'BreadcrumbList',
            'itemListElement' => [
                ['@type'=>'ListItem','position'=>1,'name'=>'Inicio','item'=>$home],
                ['@type'=>'ListItem','position'=>2,'name'=>get_the_title(),'item'=>get_permalink()],
            ],
        ];
    }

    /* ---- Post individual ---- */
    if (is_single() && isset($post)) {
        $thumb_url = get_the_post_thumbnail_url($post, 'large')
            ?: get_template_directory_uri() . '/assets/images/og-vaidevan.jpg';
        $word_count = str_word_count(strip_tags($post->post_content ?? ''));
        $schemas[] = [
            '@context'        => 'https://schema.org',
            '@type'           => 'BlogPosting',
            '@id'             => get_permalink() . '#article',
            'headline'        => get_the_title(),
            'description'     => wp_trim_words(get_the_excerpt() ?: strip_tags($post->post_content ?? ''), 30, '...'),
            'image'           => [
                '@type'  => 'ImageObject',
                'url'    => $thumb_url,
                'width'  => 1200,
                'height' => 630,
            ],
            'datePublished'   => get_the_date('c'),
            'dateModified'    => get_the_modified_date('c'),
            'author'          => [
                '@type' => 'Organization',
                'name'  => 'VaideVan Transporte Executivo',
                'url'   => $home,
                'logo'  => ['@type'=>'ImageObject','url'=>$logo],
            ],
            'publisher'       => ['@id' => $home . '#organization'],
            'mainEntityOfPage'=> ['@type' => 'WebPage', '@id' => get_permalink()],
            'inLanguage'      => 'pt-BR',
            'isPartOf'        => ['@id' => $home . '#website'],
            'wordCount'       => $word_count,
            'articleSection'  => 'Transporte Executivo',
            'speakable'       => [
                '@type'      => 'SpeakableSpecification',
                'cssSelector'=> ['.post-title', '.excerpt', 'h2', '.post-content > p:first-of-type'],
            ],
        ];
        $schemas[] = [
            '@context'        => 'https://schema.org',
            '@type'           => 'BreadcrumbList',
            'itemListElement' => [
                ['@type'=>'ListItem','position'=>1,'name'=>'Inicio','item'=>$home],
                ['@type'=>'ListItem','position'=>2,'name'=>'Blog','item'=>$home.'blog/'],
                ['@type'=>'ListItem','position'=>3,'name'=>get_the_title(),'item'=>get_permalink()],
            ],
        ];
    }

    foreach ($schemas as $schema) {
        echo '<script type="application/ld+json">' . wp_json_encode($schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . '</script>' . "\n";
    }
}

function vdv_faq($q, $a) {
    return ['@type'=>'Question','name'=>$q,'acceptedAnswer'=>['@type'=>'Answer','text'=>$a]];
}
function vdv_service_item($pos, $name, $desc, $url) {
    return ['@type'=>'ListItem','position'=>$pos,'item'=>[
        '@type'=>'Service','name'=>$name,'description'=>$desc,'url'=>$url,
        'provider'=>['@id'=>home_url('/').'#organization'],
    ]];
}
