<?php
/**
 * Template Name: Sobre
 */
get_header();
?>
<section class="page-hero" aria-label="Sobre a VaideVan">
    <div class="container">
        <nav aria-label="Breadcrumb">
            <ol style="display:flex;gap:8px;font-size:.78rem;color:rgba(255,255,255,.38);justify-content:center;margin-bottom:18px;list-style:none">
                <li><a href="<?= esc_url(home_url('/')) ?>" style="color:var(--y)">Inicio</a></li>
                <li aria-hidden>/</li><li aria-current="page">Sobre</li>
            </ol>
        </nav>
        <h1>20+ Anos Liderando o Transporte Executivo no Brasil</h1>
        <p>Nascemos em Sao Paulo e crescemos para atender todo o Brasil com excelencia e profissionalismo.</p>
    </div>
</section>

<section class="section-pad" style="background:var(--k)">
    <div class="container">
        <div class="sobre-intro">
            <div class="sobre-txt fade-up">
                <span class="sec-label">Nossa Historia</span>
                <h2>De Sao Paulo para o Brasil</h2>
                <p>Fundada em 2003 na cidade de Sao Paulo, a VaideVan nasceu com uma missao clara: oferecer transporte executivo de alta qualidade para empresas que nao aceitam menos que o melhor.</p>
                <p>Ao longo de mais de duas decadas, expandimos nossa atuacao para 12 estados e mais de 49 cidades, mantendo o mesmo compromisso com excelencia, pontualidade e seguranca que nos trouxe ate aqui.</p>
                <p>Hoje somos referencia nacional em aluguel de van executiva, fretamento corporativo, transfer aeroporto e transporte de VIPs, com frota exclusiva Mercedes-Benz Sprinter e motoristas altamente treinados.</p>
                <div class="nums-grid" aria-label="Numeros da empresa">
                    <div class="num-item"><div class="num-val">2003</div><div class="num-lbl">Ano de fundacao</div></div>
                    <div class="num-item"><div class="num-val">49+</div><div class="num-lbl">Cidades atendidas</div></div>
                    <div class="num-item"><div class="num-val">12</div><div class="num-lbl">Estados</div></div>
                </div>
            </div>
            <div class="fade-up" style="--d:.15s">
                <div class="frota-img"><div class="placeholder" aria-hidden>🚐</div></div>
            </div>
        </div>
    </div>
</section>

<section class="section-pad" style="background:var(--d)">
    <div class="container">
        <div class="sec-head fade-up">
            <span class="sec-label">Atuacao Nacional</span>
            <h2>Presenca em 12 Estados Brasileiros</h2>
            <p>De Sao Paulo ao Nordeste, a VaideVan cobre as principais regioes do Brasil para o seu fretamento executivo.</p>
        </div>
        <div class="estados-grid fade-up">
            <?php
            $estados = ['Sao Paulo (SP)','Rio de Janeiro (RJ)','Minas Gerais (MG)','Parana (PR)','Santa Catarina (SC)','Rio Grande do Sul (RS)','Goias (GO)','Mato Grosso do Sul (MS)','Bahia (BA)','Pernambuco (PE)','Ceara (CE)','Distrito Federal (DF)'];
            foreach ($estados as $e): ?>
            <div class="estado-item"><?= esc_html($e) ?></div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<section class="section-pad" style="background:var(--k)">
    <div class="container">
        <div class="sec-head fade-up">
            <span class="sec-label">Nossos Valores</span>
            <h2>O que Nos Move</h2>
        </div>
        <div class="dif-grid">
            <?php
            $vals = [
                ['Excelencia','Cada detalhe e pensado para superar as expectativas do cliente.'],
                ['Pontualidade','Respeitar o tempo do cliente e uma questao de principio, nao de opcao.'],
                ['Seguranca','Frota inspecionada, motoristas treinados e seguros completos.'],
                ['Discreticao','Confidencialidade total nas operacoes de transporte de executivos e VIPs.'],
                ['Inovacao','Tecnologia e gestao modernas para operacoes cada vez mais eficientes.'],
                ['Sustentabilidade','Comprometidos com a reducao de emissoes e o transporte consciente.'],
            ];
            foreach ($vals as $i => [$t, $d]): ?>
            <div class="dif-item fade-up" style="--d:<?= $i * 0.06 ?>s">
                <div class="dif-n" aria-hidden>0<?= $i+1 ?></div>
                <div class="dif-t"><h4><?= esc_html($t) ?></h4><p><?= esc_html($d) ?></p></div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<section class="cta-band">
    <div class="container">
        <h2>Conheca Mais — Fale com Nossa Equipe</h2>
        <p>Tire suas duvidas e solicite uma proposta personalizada para sua empresa.</p>
        <a href="https://wa.me/5511999294694" class="btn-k" target="_blank" rel="noopener noreferrer">Falar no WhatsApp</a>
    </div>
</section>

<?php get_footer(); ?>
